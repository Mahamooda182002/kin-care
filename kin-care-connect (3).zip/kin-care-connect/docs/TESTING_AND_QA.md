# 9. Testing and QA (added)

## Automated tests (in this repo)

| Suite | Command | Covers |
|---|---|---|
| Flutter unit | `flutter test test/unit` | form validators, on-device scam engine (risk levels, indicators, URL extraction, disclaimers), reminder recurrence (daily/weekly/monthly, intervals, month-end clamping) |
| Flutter widget | `flutter test test/widget` | KcButton loading/semantics, onboarding flow (Next, Get Started, page indicators, routing), login validation and error display with a fake auth repository, large-text setting |
| Backend unit | `cd functions && npm test` | scam rules parity, AI-can-only-raise risk, medical guardrails (dose, diagnosis, stop-medicine), invented-fact removal, prompt delimiter safety, AI schema validation, server recurrence in IST, rate-limit windows, local-day windows |
| Security rules | `cd rules-tests && npm test` (needs Java 21+, Node 22) | Firestore + Storage rules in the emulators, project `demo-kin-care-connect`; 325 cases, see below |

Results at hand-over: Flutter analyze clean · 29 Flutter tests pass · 21 backend tests pass.

## Security-rules tests (`rules-tests/`)

Separate npm package: TypeScript + mocha + `@firebase/rules-unit-testing` v5 + Firebase JS SDK v12, with `firebase-tools` as a dev dependency. Every test starts from the same seeded world (written with `withSecurityRulesDisabled`): family `fam1` with an admin, an assigned caregiver, an unassigned caregiver, a viewer, an elderly member, a declined and a pending member; family `fam2` with its own admin; an outsider; care profiles with consent on, consent off, and no linked elder.

```bash
cd rules-tests
npm ci
npm test               # = firebase emulators:exec --config ../firebase.json --only firestore,storage --project demo-kin-care-connect "npm run test:run"
npm run typecheck      # compile only
npm run test:firestore # Firestore emulator only
```

| File | Area | Cases |
|---|---|---|
| `users.test.ts` | `users/{uid}` create (consent record, field whitelist, server time, token email, role), read, update (immutable fields, legacy phone removal only, consent re-acceptance), delete; `devices` | 45 |
| `families.test.ts` | `families` (20), `familyMembers` (25: creation only with a new family, reads by status, role changes by admin only, removal/leaving), `invitations` (9: server-managed) | 54 |
| `careProfiles.test.ts` | create with sharing off, reads by role/status, admin details, consent by linked elder (or admin when none), delete | 47 |
| `careData.test.ts` | `activityRecords` (20), `medicalSummaries` (22), `reminders` (19) + `history` (7), `emergencyContacts` (20); includes consent revocation removing caregiver access | 88 + 7 = 95 |
| `personal.test.ts` | `recordings` metadata (11), `scamChecks` (18: only verdict fields, no message text), `notifications` (6) | 35 |
| `serverOnly.test.ts` | `rateLimits` (3), `auditLog` (1), unknown paths (1), unauthenticated read/write/delete on every collection (17), sanity (1) | 23 |
| `storage.test.ts` | `profileImages` (12: owner, size, type, name), `recordings` (12: consent record required, owner, size, type, no overwrite), other paths (2) | 26 |
| **Total** | | **325** |

Results on 5 Nov 2026 (build sandbox, Firestore emulator 1.23.0 on Java 25): **299 Firestore cases passing, 0 failing.** The **26 Storage cases compile (`tsc --noEmit` clean) but were not executed**: the sandbox could not download the Storage emulator's rules runtime. The CI `rules` job runs all 325.

Rule changes made because these tests failed against the documented intent:

1. **`scamChecks`**: the rule only rejected fields named `text` and `message`, so `messageText`, `body`, `content` etc. were accepted. Now a whitelist (`userId`, `inputType`, `riskLevel`, `indicators`, `recommendations`, `aiUsed`, `createdAt`), with `indicators`/`recommendations` required to be lists.
2. **`emergencyContacts` update**: an editor could move a contact into any family (create checked membership, update did not). Now moving it to a different family needs the same role there as creating it.
3. **Storage `recordings`**: audio was accepted without any consent record. The upload now needs the Firestore record `recordings/{id}` to exist, belong to the uploader, name this exact path, carry a consent reference and be active. The app now writes that record **before** uploading (and deletes it if the upload fails): `lib/features/medical/data/medical_repository.dart`. On first deploy of `storage.rules`, accept the prompt that lets Storage rules read Firestore.

## Recommended next tests (need emulators or devices)

1. ~~Security rules tests~~: done, see above.
2. **Callable integration tests** in the Functions emulator (auth context, App Check disabled locally) for invite → accept → role change → remove flows.
3. **Integration tests** (`integration_test/`) on an emulator device: register → verify → create family → add profile → invite → reminders → notifications.

## Manual QA checklist (each release)

**Accessibility**
- [ ] TalkBack reads every button, card and status (monitoring ON/OFF, risk level, recording state).
- [ ] Large text (in-app) and system font at 200%: no clipped text on Dashboard, Reminders, Scam result.
- [ ] Touch targets ≥ 48 dp (buttons are 56 dp).
- [ ] Light and dark themes; colour contrast ≥ 4.5:1 for body text.

**Auth**
- [ ] Register with an existing email shows "account already exists".
- [ ] Weak password and mismatched confirmation are blocked.
- [ ] Forgot password never reveals whether an email exists.
- [ ] Protected routes redirect to login after logout.

**Safety copy**
- [ ] Medical result always shows the disclaimer; a dose question shows the safety notice.
- [ ] Scam result never says "safe"; links are not tappable.
- [ ] Routine Monitor shows limitations before starting.
- [ ] Emergency screen states the app is not an emergency service.

**Privacy**
- [ ] AI features refuse to run until consent is given; turning consent off blocks them server-side.
- [ ] Lock-screen push shows generic text by default.
- [ ] Recording requires the consent dialog; deleting removes audio and transcript.
- [ ] Data export returns JSON; account deletion removes data and signs out.

**Family**
- [ ] Invite requires verified email; wrong-email account cannot accept.
- [ ] Removing a member immediately removes access.
- [ ] Consent toggles are disabled for users who don't control them.

**Reliability**
- [ ] Offline: lists show cached data or clear errors; AI calls show "unavailable" messages.
- [ ] AI secrets unset: app shows "not set up yet", no crash.

## Release checklist

- [ ] `flutterfire configure` done for the production project; App Check Play Integrity enabled.
- [ ] Secrets set in production; budget alerts on.
- [ ] Rules and indexes deployed; functions deployed to the intended region.
- [ ] Signed with the upload key; SHA certificates added to Firebase.
- [ ] Privacy policy URL published; Play Data safety form completed.
- [ ] All `YOUR_…` placeholders in `lib/core/config/business_info.dart` filled; `dart run tool/export_legal.dart` run; About & contact shows no "Setup incomplete" warning.
- [ ] Lawyer review of `docs/legal/` (Privacy Policy, Terms, Cookie & Local Storage Policy, account deletion).
- [ ] Fresh install: Privacy choices appears first; nothing pre-ticked; Decline all → no notification permission prompt anywhere; Accept all → prompt appears once.
- [ ] Registration refuses without the 18+ box and without the Terms box; "I am under 18" shows the explanation; new user doc in Firestore has `consents.*` and no `phone`.
- [ ] `cd rules-tests && npm test` passes (all 325 cases, including the 26 Storage cases).
- [ ] Notification preferences → "All notifications" off: no new notifications arrive; device token removed.
- [ ] Delete a test account that administers a family alone and is a caregiver in another family: check every collection and Storage prefix in `docs/DATA_INVENTORY.md` afterwards.
- [ ] TalkBack pass over Privacy choices, Registration, Dashboard, Scam result; Switch Access / keyboard / D-pad: every control reachable with a visible focus outline, no traps.
- [ ] High contrast on (in-app and Android setting): text readable on every screen.
- [ ] Replace the default launcher icon.
