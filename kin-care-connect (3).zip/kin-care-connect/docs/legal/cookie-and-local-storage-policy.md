# Cookie & Local Storage Policy

> **Template — needs lawyer review. This text describes how the app works today but has not yet been reviewed by a lawyer.**

_Last updated: 3 November 2026 (version 2026-11-03)_

<!-- Generated from lib/features/legal/legal_texts.dart by `dart run tool/export_legal.dart`. Do not edit by hand. -->

## No cookies, no trackers

Kin Care Connect is a native Android app. It does not use browser cookies, advertising IDs, analytics SDKs, ad networks or cross-app tracking, and it does not open web pages inside the app that would set cookies. If you visit our website, any cookies there are covered by the website's own notice.

## What the app stores on your phone

The app needs a small amount of on-device storage to work. This storage is essential and is not used for tracking:

- App settings (Android "shared preferences"): theme, large text, high contrast, whether you have seen the introduction, and your privacy choices with the date and the notice version.
- Sign-in session: Firebase Authentication keeps you signed in until you log out.
- Offline copy: Cloud Firestore keeps a temporary copy of data the app has loaded so it can open quickly and work briefly offline.
- App integrity token: Firebase App Check stores a short-lived token proving requests come from the genuine app.
- Notification token: only if you allow notifications, Firebase Cloud Messaging keeps a token so reminders can reach this phone.
- Recordings in progress: audio is saved in the app's temporary folder while you record and is deleted after it is uploaded or discarded.

## Your choices

- Notifications and AI processing are optional. You choose them on the "Privacy choices" screen when you first open the app, and can change them any time in Settings › Privacy settings and Settings › Notification preferences.
- Logging out removes the sign-in session and this phone's notification token.
- Clearing the app's storage in Android settings, or uninstalling the app, removes everything stored on the phone. It does not delete your account; use Settings › Account › Delete my account for that.

## Contact

Questions: YOUR_SUPPORT_EMAIL.
