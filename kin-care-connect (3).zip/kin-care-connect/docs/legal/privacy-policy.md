# Privacy Policy

> **Template — needs lawyer review. This text describes how the app works today but has not yet been reviewed by a lawyer.**

_Last updated: 3 November 2026 (version 2026-11-03)_

<!-- Generated from lib/features/legal/legal_texts.dart by `dart run tool/export_legal.dart`. Do not edit by hand. -->

## Who we are

Kin Care Connect is provided by YOUR_COMPANY_NAME ("we", "us"). We are the Data Fiduciary for the personal data described here under India's Digital Personal Data Protection Act, 2023 (DPDP Act).

- Operator: YOUR_COMPANY_NAME (YOUR_LEGAL_ENTITY_NAME_AND_REGISTRATION)
- Postal address: YOUR_REGISTERED_POSTAL_ADDRESS
- Support and privacy requests: YOUR_SUPPORT_EMAIL
- Website: YOUR_WEBSITE_URL

## Summary

- The app is free. There are no ads, no in-app purchases and no tracking for advertising.
- We collect only what the features you use need. We never sell your data.
- Nothing is shared with your family unless the elder (or the family administrator when no elder account is linked) approves it, one type of information at a time.
- AI processing is off until you turn it on.
- You can export your data or delete your account at any time.

## What we collect and why

Account
- Full name and email address: to create your account, sign you in, and show family members who you are. Your password is handled by Firebase Authentication and is never stored in our database.
- Account type (elderly member or family caregiver): a label you choose, shown on your profile.
- Profile picture (optional): shown to you and to members of your family groups.
- Settings: accessibility (large text, high contrast), notification preferences, AI and privacy choices.
- Consent records: which version of the Terms and this Policy you accepted, your confirmation that you are 18 or older, and when.

Family care
- Family groups: group name, members' names, emails and roles, and invitations (the invitee's email and the inviter's name).
- Care profiles: the name and optional notes for the person being cared for, which caregivers are assigned, and the sharing approvals.
- Reminders: title, type, schedule, repeat rule, optional notes and completion history (who completed or snoozed, and when).
- Emergency contacts: name, relationship and phone number of people you add. Only add people who are happy for their details to be stored.

Medical Translator
- Text you type or paste, the explanation or summary created, its title and language.
- Recordings (only after everyone present agrees): the audio and its transcript. Deleted automatically after 30 days, or sooner if you delete them.

Scam Shield
- The basic check runs on your phone and sends nothing.
- We store only the result (risk level, warning signs found, advice and message type), never the message text.
- If you choose the optional AI check, the message text is sent to our server and the AI provider to be analysed, and is not saved.

Routine Monitor
- Only while you switch monitoring on and the app is open: simple events such as "monitoring started", "app opened" or "check-in", with times. No location, microphone, camera or sensor data is collected.

Device and service data
- A notification token for this phone, only if you allow notifications.
- Security data: Firebase App Check confirms requests come from the genuine app (using Google Play Integrity); per-account usage counters limit abuse; server logs contain shortened one-way codes of user IDs and event counts, never your content, name or email.

What we do not collect
- No location, contacts list, call logs, SMS inbox, advertising ID, or analytics or advertising trackers. The app uses no cookies.

## Legal basis

We process your data on the basis of your consent (DPDP Act section 6), given when you create an account and, separately, for each optional feature (AI processing, recordings, notifications and family sharing). Where the law allows, we may also process data for certain legitimate uses (section 7), such as responding to a medical emergency or complying with a legal obligation.

You can withdraw consent at any time in the app (Settings › Privacy settings and Settings › Notification preferences) or by emailing us. Withdrawing consent does not affect processing that happened before, and features that depend on it will stop working.

## AI processing

Medical Translator AI and Scam Shield AI are off by default and can be switched on or off separately in Settings › Privacy settings. When switched on, the text you submit (or the transcript of a recording you choose to transcribe) is sent over an encrypted connection to our server and then to our AI provider, YOUR_AI_PROVIDER_NAME, which processes it in YOUR_AI_PROVIDER_PROCESSING_COUNTRY.

We use a provider plan under which your data is not used to train AI models, and we keep provider costs ourselves: AI features never cost you anything. AI explanations can be wrong; they are not medical advice and do not diagnose.

## Who can see your data

- You.
- Members of your family groups: only your name, email, role and profile picture, plus care information that the elder (or the administrator when no elder is linked) has approved for sharing: activity, medical summaries the author chose to share, and reminders. Emergency contacts added to a family are visible to its members.
- Our service providers, who process data on our behalf under contract: Google (Firebase Authentication, Cloud Firestore, Cloud Storage, Cloud Functions, Cloud Messaging and App Check), with data stored in YOUR_FIREBASE_DATA_LOCATION; and YOUR_AI_PROVIDER_NAME for AI features you switch on.
- Authorities, only when the law requires it.

We do not sell or rent personal data and we do not share it with advertisers or data brokers.

## Transfers outside India

Some providers may process data outside India (for example, the AI provider in YOUR_AI_PROVIDER_PROCESSING_COUNTRY, and Google's global infrastructure for notifications). We only use countries that are not restricted by the Government of India under section 16 of the DPDP Act, and we require providers to protect the data.

## How long we keep data

- Audio recordings and transcripts: 30 days, or sooner if you delete them.
- Scam-check results: 180 days.
- Notifications: 90 days.
- Invitations: 30 days.
- Usage counters for abuse prevention: about 2 days after their time window.
- Everything else (profile, reminders, contacts, summaries, activity, family groups): until you delete it or your account.

Automatic deletion runs every day.

## Security

Data is encrypted in transit (TLS) and at rest (Google-managed encryption). Access is limited by server-side security rules, every server request is checked for sign-in and app integrity, AI and speech keys are kept only on the server, and we limit how often each account can call costly features. No system is perfectly secure; if a personal data breach affects you, we will inform you and the Data Protection Board of India as the law requires.

## Your rights

Under the DPDP Act you can:
- get a summary of the personal data we hold about you and how it is processed: Settings › Account › Export my data gives you a full copy (JSON);
- correct or update your data: edit it in the app or ask us;
- erase your data: delete individual items in the app, or delete your account;
- withdraw consent for optional processing at any time;
- nominate another person to exercise these rights if you die or become unable to (email us);
- raise a grievance (see below).

Email YOUR_SUPPORT_EMAIL for any request we cannot handle in the app. We may need to confirm your identity first.

## Deleting your account

Deleting your account (in the app: Settings › Account › Delete my account) removes, from our live database and file storage:

- your profile and settings, consent records and device notification tokens;
- your reminders and their history, emergency contacts, medical summaries, recordings (audio and transcripts), scam-check results, activity records and notifications;
- your family memberships and any invitations sent to or by you;
- family groups you administer alone, together with their care profiles, memberships, invitations and the care-profile reminders and shared emergency contacts kept in them;
- your profile picture and recordings in file storage;
- your sign-in account (Firebase Authentication).

If you are the linked elder on someone else's care profile, the link is removed and all of its sharing approvals are switched off. Your name is removed from caregiver assignments.

What stays: content that other family members created themselves (for example a reminder another caregiver wrote) stays in their accounts; and some records keep an internal user ID (a random code, not your name or email) to show who created or approved something. Any backup copies, if the operator has enabled backups, are deleted when those backups expire. Server logs contain only shortened one-way codes of user IDs, never your name, email or content.

## Requesting deletion without the app

You can ask us to delete your account and data even if you no longer have the app or cannot sign in:

1. Email YOUR_SUPPORT_EMAIL from the email address registered to your account, with the subject "Delete my Kin Care Connect account".
2. Say whether you want the whole account deleted or only some data (for example, only recordings).
3. We may ask you to confirm the request from that email address so that nobody else can delete your account.

We then carry out the same deletion the app performs (described below) and confirm by email. If you cannot use the registered email address, tell us and we will explain how else you can verify that the account is yours.

## Children

Kin Care Connect is for adults aged 18 and over: family caregivers and the elderly people they support. You must confirm that you are 18 or older to create an account, and we do not knowingly collect personal data of children (under 18 under the DPDP Act).

If we learn that a child has created an account, we will delete it. If you believe a child has given us data, email YOUR_SUPPORT_EMAIL.

If the app is ever opened to children, we would first need verifiable consent from a parent or lawful guardian, as section 9 of the DPDP Act requires, and we would not track, behaviourally monitor or target advertising at children.

## Cookies and local storage

The app does not use cookies, advertising IDs or analytics trackers. It stores a small amount of information on your phone so it works properly; see our Cookie & Local Storage Policy for the full list.

## Changes to this policy

We will show you a notice in the app before a material change takes effect, and ask for your agreement again where the law requires. The version and date at the top tell you which text applies.

## Grievance Officer

If you have a concern about how your personal data is handled, contact our Grievance Officer:

- Name: YOUR_GRIEVANCE_OFFICER_NAME
- Email: YOUR_GRIEVANCE_OFFICER_EMAIL
- Post: YOUR_REGISTERED_POSTAL_ADDRESS

We will acknowledge your grievance and respond within YOUR_GRIEVANCE_RESPONSE_TIME. If you are not satisfied with our response, you may complain to the Data Protection Board of India under the Digital Personal Data Protection Act, 2023.
