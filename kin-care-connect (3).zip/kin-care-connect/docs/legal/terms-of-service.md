# Terms of Service

> **Template — needs lawyer review. This text describes how the app works today but has not yet been reviewed by a lawyer.**

_Last updated: 3 November 2026 (version 2026-11-03)_

<!-- Generated from lib/features/legal/legal_texts.dart by `dart run tool/export_legal.dart`. Do not edit by hand. -->

## About these terms

These terms are an agreement between you and YOUR_COMPANY_NAME (YOUR_LEGAL_ENTITY_NAME_AND_REGISTRATION), which provides Kin Care Connect ("the app"). By creating an account you agree to them and to our Privacy Policy.

- Operator: YOUR_COMPANY_NAME (YOUR_LEGAL_ENTITY_NAME_AND_REGISTRATION)
- Postal address: YOUR_REGISTERED_POSTAL_ADDRESS
- Support and privacy requests: YOUR_SUPPORT_EMAIL
- Website: YOUR_WEBSITE_URL

## What the app does

Kin Care Connect helps families coordinate care for elderly relatives: reminders, emergency contacts, plain-language explanations of medical information, warning signs of possible scams, and a simple activity log while the app is open.

## Price: free, with no hidden fees

The app is free to download and use. There are no in-app purchases, subscriptions, advertisements or hidden fees. AI features are paid for by us, the operator; you are never charged for them. To keep the service fair and affordable, each account has usage limits on AI features (for example, a number of explanations per hour).

Your mobile network operator may charge for data you use, as with any app. If we ever decide to introduce a paid feature, we will tell you clearly in advance, it will be optional, and nothing will be charged without your explicit agreement.

## Who can use the app

You must be 18 or older to create an account. Do not create an account for a child or let a child use your account.

## Not medical advice

Explanations and summaries help you understand information; they do not diagnose, prescribe or recommend changes to medicines or doses, and they can contain mistakes. Always follow your doctor or pharmacist, and check anything important with them.

## Not an emergency service

The app does not detect falls or medical emergencies and never contacts emergency services or family automatically. In an emergency, call 112 (India) or your local emergency number.

## Scam checks are advisory

Scam Shield looks for common warning signs. It can miss scams and can flag genuine messages, and it never confirms that a message is safe. Never share OTPs, PINs or passwords, and verify requests through an official number you already know.

## Your responsibilities

- Record conversations only when everyone present agrees.
- Add emergency contacts and care profiles only for people who are happy for their details to be stored.
- Invite to your family group only people you trust, and give them the least access they need.
- Keep your password private and tell us if you think your account has been misused.
- Do not misuse the service: no attempts to break security, overload the service, use it for unlawful purposes, or upload content you have no right to share.

## Your content

You keep ownership of what you add. You allow us to store and process it only to provide the features you use, as described in the Privacy Policy.

## Availability and changes to the service

We work to keep the app available and accurate, but it is provided "as is" and may sometimes be unavailable, for example during maintenance or if a provider has an outage. Reminders depend on your phone, its settings and its connection, so do not rely on the app as the only reminder for critical medicines.

## Liability

To the extent the law allows, we are not liable for indirect or consequential loss, or for loss caused by relying on AI explanations, scam checks or reminders instead of professional advice. Nothing in these terms limits liability that cannot be limited by law, or your rights as a consumer under the Consumer Protection Act, 2019.

## Ending your use

You can stop using the app and delete your account at any time (Settings › Account), or ask us to delete it by email. We may suspend or close an account that seriously or repeatedly breaks these terms, and will tell you why unless the law prevents it.

## Changes to these terms

We will tell you in the app before a material change takes effect. If you do not agree, you can delete your account.

## Governing law

These terms are governed by the laws of India. Courts in YOUR_CITY_FOR_JURISDICTION have jurisdiction, without affecting any right you have to bring a complaint where you live.

## Contact and grievances

If you have a concern about how your personal data is handled, contact our Grievance Officer:

- Name: YOUR_GRIEVANCE_OFFICER_NAME
- Email: YOUR_GRIEVANCE_OFFICER_EMAIL
- Post: YOUR_REGISTERED_POSTAL_ADDRESS

We will acknowledge your grievance and respond within YOUR_GRIEVANCE_RESPONSE_TIME. If you are not satisfied with our response, you may complain to the Data Protection Board of India under the Digital Personal Data Protection Act, 2023.
