# Delete your Kin Care Connect account

> **Template — needs lawyer review. This text describes how the app works today but has not yet been reviewed by a lawyer.**

_Last updated: 3 November 2026 (version 2026-11-03)_

<!-- Generated from lib/features/legal/legal_texts.dart by `dart run tool/export_legal.dart`. Do not edit by hand. -->

## In the app

Open Settings › Account › Delete my account, confirm, and enter your password. Deletion starts immediately.

## Without the app

You can ask us to delete your account and data even if you no longer have the app or cannot sign in:

1. Email YOUR_SUPPORT_EMAIL from the email address registered to your account, with the subject "Delete my Kin Care Connect account".
2. Say whether you want the whole account deleted or only some data (for example, only recordings).
3. We may ask you to confirm the request from that email address so that nobody else can delete your account.

We then carry out the same deletion the app performs (described below) and confirm by email. If you cannot use the registered email address, tell us and we will explain how else you can verify that the account is yours.

## What is deleted

Deleting your account (in the app: Settings › Account › Delete my account) removes, from our live database and file storage:

- your profile and settings, consent records and device notification tokens;
- your reminders and their history, emergency contacts, medical summaries, recordings (audio and transcripts), scam-check results, activity records and notifications;
- your family memberships and any invitations sent to or by you;
- family groups you administer alone, together with their care profiles, memberships, invitations and the care-profile reminders and shared emergency contacts kept in them;
- your profile picture and recordings in file storage;
- your sign-in account (Firebase Authentication).

If you are the linked elder on someone else's care profile, the link is removed and all of its sharing approvals are switched off. Your name is removed from caregiver assignments.

What stays: content that other family members created themselves (for example a reminder another caregiver wrote) stays in their accounts; and some records keep an internal user ID (a random code, not your name or email) to show who created or approved something. Any backup copies, if the operator has enabled backups, are deleted when those backups expire. Server logs contain only shortened one-way codes of user IDs, never your name, email or content.

## Deleting some data only

You can delete individual recordings, summaries, reminders, contacts, notifications and scam-check results in the app at any time, or email YOUR_SUPPORT_EMAIL to ask us to.

## Developer

- Operator: YOUR_COMPANY_NAME (YOUR_LEGAL_ENTITY_NAME_AND_REGISTRATION)
- Postal address: YOUR_REGISTERED_POSTAL_ADDRESS
- Support and privacy requests: YOUR_SUPPORT_EMAIL
- Website: YOUR_WEBSITE_URL
