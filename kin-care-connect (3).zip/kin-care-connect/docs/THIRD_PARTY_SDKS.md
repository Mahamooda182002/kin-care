# Third-party SDK audit

Every direct dependency of the app (`pubspec.yaml`, versions resolved in `pubspec.lock`) and of the backend (`functions/package.json`, versions in `functions/package-lock.json`), what personal data it touches, whether it sends anything off the device, and its licence. Audited 3 November 2026. Licences were read from each package's `LICENSE` / `package.json`.

## Result

- **No analytics, advertising, attribution, crash-reporting or session-replay SDKs.** `firebase_analytics`, `firebase_crashlytics`, `google_mobile_ads`, Facebook, AppsFlyer, Mixpanel, Amplitude, Segment and Sentry are absent from both lock files (checked by `functions/src/test/account.test.ts` against `pubspec.yaml` and `functions/package.json`).
- **Firebase Analytics is not included.** As a belt-and-braces measure `AndroidManifest.xml` also sets `firebase_analytics_collection_deactivated=true`, `firebase_analytics_collection_enabled=false`, `google_analytics_adid_collection_enabled=false` and `google_analytics_default_allow_ad_personalization_signals=false`, so nothing is collected even if a future dependency pulls in measurement code.
- **FCM auto-init is disabled** (`firebase_messaging_auto_init_enabled=false`). The app creates a push token only after the user opts in to notifications, and deletes it (and disables auto-init again) on logout or opt-out.
- All 142 packages in `pubspec.lock` (21 direct, 2 dev, 119 transitive) are Flutter/Dart platform plugins, their per-platform implementations, or pure-Dart utilities. Re-check with `flutter pub deps --style=compact` after any upgrade.

## Flutter app (`pubspec.yaml`)

| Package | Version | What it does here | Personal data it touches | Sends data off device? | Licence |
|---|---|---|---|---|---|
| flutter, flutter_localizations | SDK | UI framework, localisation | Screen content | No | BSD-3-Clause |
| firebase_core | 5.1.0 | Initialises Firebase | Firebase app id; SDK heartbeat (SDK/platform versions) | Yes — Google (Firebase) | BSD-3-Clause |
| firebase_auth | 7.0.1 | Email/password sign-in | Email, password (sent to Firebase Auth, not stored by us), session token | Yes — Google | BSD-3-Clause |
| cloud_firestore | 7.1.0 | Database | All app data in DATA_INVENTORY.md; local offline cache | Yes — Google, in your chosen Firestore location | BSD-3-Clause |
| cloud_functions | 7.0.1 | Calls backend (AI, scam, family, account) | Request payloads (text for AI, invite emails, etc.) | Yes — your Cloud Functions (asia-south1 by default) | BSD-3-Clause |
| firebase_storage | 14.0.1 | Profile pictures, consented recordings | Images, audio | Yes — Google Cloud Storage | BSD-3-Clause |
| firebase_messaging | 17.0.1 | Push notifications (opt-in) | FCM registration token; Firebase installation id | Yes — Google FCM, only after opt-in | BSD-3-Clause |
| firebase_app_check | 0.5.1 | Proves requests come from the genuine app | Play Integrity attestation, App Check token | Yes — Google | BSD-3-Clause |
| provider | 6.1.5+1 | State management | In-memory app state | No | MIT |
| go_router | 18.1.2 | Navigation | Routes | No | BSD-3-Clause |
| shared_preferences | 2.5.6 | Device settings and privacy choices | Theme, text size, contrast, onboarding flag, privacy choices + timestamp | No | BSD-3-Clause |
| intl | 0.20.3 | Date/number formatting | — | No | BSD-3-Clause |
| url_launcher | 6.3.3 | Opens mailto:, tel: and links in other apps | The address/number being opened | Hands off to another app chosen by the user | BSD-3-Clause |
| image_picker | 1.2.4 | Choose/take a profile photo via system apps | Selected image | No (upload is done by firebase_storage) | BSD-3-Clause |
| record | 7.1.2 | Microphone recording (after consent) | Audio to a temp file | No (upload is done by firebase_storage) | BSD-3-Clause |
| audioplayers | 6.8.1 | Plays back recordings | Audio from your Storage URL | Downloads from your Storage only | MIT |
| path_provider | 2.1.6 | Finds the temp folder for recordings | File paths | No | BSD-3-Clause |
| permission_handler | 13.0.2 | Opens app settings when a permission was denied | Permission status | No | MIT |
| share_plus | 13.3.1 | Shares the data-export JSON via the system share sheet | The export (user chooses where it goes) | Only where the user sends it | BSD-3-Clause |
| uuid | 4.6.0 | Local ids | — | No | MIT |
| flutter_lints (dev) | 6.0.0 | Static analysis | — | Not shipped | BSD-3-Clause |
| flutter_test (dev) | SDK | Tests | — | Not shipped | BSD-3-Clause |

Android permissions declared: `INTERNET`, `RECORD_AUDIO` (asked at the moment of recording, after the consent dialog), `POST_NOTIFICATIONS` (asked only after the user opts in). `CAMERA` was removed in this audit.

## Backend (`functions/package.json`)

| Package | Version | What it does here | Personal data it touches | Sends data off server? | Licence |
|---|---|---|---|---|---|
| firebase-admin | 14.5.0 | Firestore, Auth, Storage, Messaging from the server | All server-side data operations | Within Google Cloud / FCM | Apache-2.0 |
| firebase-functions | 7.4.0 | Callable + scheduled functions, logging | Request payloads; logs (hashed ids only) | Within Google Cloud | MIT |
| zod | 4.6.7 | Input validation | Request payloads (in memory) | No | MIT |
| typescript (dev) | 5.9.3 | Compiler | — | Not deployed | Apache-2.0 |
| @types/node (dev) | 22.20.5 | Type definitions | — | Not deployed | MIT |

**AI / speech provider (not an SDK).** `functions/src/ai/provider.ts` calls an OpenAI-compatible HTTPS API with `fetch` — no vendor SDK. It receives text, transcripts or audio only when the user has switched AI on (re-checked server-side). Fill in `BusinessInfo.aiProviderName` / `aiProviderLocation` and sign a data-processing agreement with no training on your data.

**Email.** The backend sends no email. The only emails users receive are Firebase Authentication's own account emails (address verification and password reset), which they trigger themselves. There is no marketing email, so no unsubscribe link is needed; this is checked by a backend test that fails if an email-sending library is added.

## Keeping this current

1. After `flutter pub upgrade` or `npm update`, re-run the grep in `functions/src/test/account.test.ts` (it runs with `npm test`) and update the versions above.
2. Before adding any SDK, record here what data it collects and whether it sends it off the device, then update `docs/DATA_INVENTORY.md`, the Privacy Policy and the Play Data safety form.
