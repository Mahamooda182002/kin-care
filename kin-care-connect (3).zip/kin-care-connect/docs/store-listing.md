# Google Play listing (draft) and Data safety answers

Honest copy written from what the app actually does. No ratings, review counts, testimonials, awards, "#1", "best", "100%", "guaranteed", "clinically proven" or "certified" claims. Replace `YOUR_…` placeholders (same values as `lib/core/config/business_info.dart`). **Have this and the Data safety answers reviewed before submission; Google's form wording changes over time.**

## App name (≤ 30 chars)

Kin Care Connect

## Short description (≤ 80 chars)

Family care for elders: reminders, contacts, plain-language medical notes.

## Full description

Kin Care Connect helps families look after an elderly relative together.

**Family care**
Create a family group, invite relatives by email and choose what each person can do. The elderly person decides what their family can see: activity, medical summaries and reminders are each shared only after they approve it.

**Care reminders**
Set reminders for medicines, appointments and daily tasks, with repeats. Shared reminders show who completed them. Reminders depend on your phone's settings and connection, so keep another reminder for critical medicines.

**Emergency contacts**
Keep important numbers in one place and call them with one tap through your phone's dialler. The app does not call anyone automatically.

**Medical Translator**
Type or paste medical words or doctor's instructions and get a simple explanation. With everyone's agreement you can record a conversation, check the transcript, and get a summary. Explanations can contain mistakes. They do not diagnose, prescribe or change doses — always follow your doctor or pharmacist. AI processing is off until you switch it on.

**Scam Shield**
Paste a suspicious message to see common warning signs, such as requests for OTPs, urgent threats or strange links, with advice on what to do next. The basic check runs on your phone. An optional AI check is available if you choose it. It can miss scams and can flag genuine messages, so never share OTPs or PINs and verify through an official number.

**Routine Monitor**
While the app is open and you switch monitoring on, it keeps a simple log such as "app opened" or "check-in" that you can choose to share with family. It does not detect falls or emergencies and does not run in the background.

**Privacy**
• No ads, no analytics trackers, no cookies.
• Notifications and AI are optional and off until you choose them.
• Export your data or delete your account at any time in the app, or by email.

**Free**
The app is free. There are no in-app purchases, subscriptions or hidden fees. AI costs are paid by us.

For adults aged 18 and over.

Support: YOUR_SUPPORT_EMAIL · Privacy policy: YOUR_PUBLIC_PRIVACY_POLICY_URL

## Store settings

| Field | Answer |
|---|---|
| Category | Medical is likely to trigger stricter review; **Health & Fitness** or **Lifestyle** fit better for a coordination app. Decide with your reviewer. |
| Contains ads | **No** |
| In-app purchases | **No** |
| Target audience | **18 and over** only. Not designed for children; do not opt into the Families programme. |
| Content rating | Complete the IARC questionnaire honestly (no violence, no user-to-public chat; users can share content only with invited family members). |
| Health apps declaration | Declare health features (medication reminders, explanations of medical information). **Not a medical device; does not diagnose or treat.** |
| Privacy policy URL | `YOUR_PUBLIC_PRIVACY_POLICY_URL` (publish `docs/legal/privacy-policy.md`) |
| Account deletion URL | Publish `docs/legal/account-deletion.md` and enter its URL |
| Permissions | `RECORD_AUDIO` (recordings, after consent), `POST_NOTIFICATIONS` (after opt-in), `INTERNET`. No location, contacts, SMS, call log or camera permission. |
| Screenshots | Use real screens from a test account with made-up data. Don't show fake ratings, testimonials or results. |

## Data safety form

"Shared" below follows Google's definition: transfers to service providers that process data on your behalf (Firebase, your AI provider) and transfers the user initiates to people they choose (family members) are **not** "sharing".

**Overview**

| Question | Answer |
|---|---|
| Does your app collect or share any of the required user data types? | Yes |
| Is all user data encrypted in transit? | Yes (TLS to Firebase and the AI provider) |
| Do you provide a way for users to request that their data is deleted? | Yes — in-app (Settings › Account) and by email (public deletion page) |
| Is data shared with third parties? | No |

**Data types**

| Category › type | Collected | Shared | Optional? | Ephemeral? | Purposes |
|---|---|---|---|---|---|
| Personal info › Name | Yes | No | Required | No | App functionality, Account management |
| Personal info › Email address | Yes | No | Required | No | App functionality, Account management |
| Personal info › Other info (emergency contacts' names, relationships and phone numbers; care-profile names and notes) | Yes | No | Optional | No | App functionality |
| Health and fitness › Health info (medical text, explanations, summaries, transcripts; medicine reminders) | Yes | No | Optional | No | App functionality |
| Audio › Voice or sound recordings | Yes | No | Optional | No (stored up to 30 days) | App functionality |
| Photos and videos › Photos (profile picture) | Yes | No | Optional | No | App functionality |
| Messages › Other in-app messages (message text pasted for the optional AI scam check) | Yes | No | Optional | **Yes** (not stored) | App functionality |
| App activity › App interactions (Routine Monitor events while on) | Yes | No | Optional | No | App functionality |
| App activity › Other user-generated content (reminders, family group names) | Yes | No | Optional | No | App functionality |
| Device or other IDs (push token / Firebase installation ID, only after notification opt-in; App Check) | Yes | No | Optional for push; App Check required | No | App functionality, Fraud prevention, security and compliance |
| Location, Financial info, Contacts (address book), Calendar, SMS/call logs, Web browsing, Files and docs, App info and performance (crash logs, diagnostics) | **No** | — | — | — | — |

If you later add crash reporting or analytics, this form, `docs/THIRD_PARTY_SDKS.md`, `docs/DATA_INVENTORY.md` and the Privacy Policy must all change first.
