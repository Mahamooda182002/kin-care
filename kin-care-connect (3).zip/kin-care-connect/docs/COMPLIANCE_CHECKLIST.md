# Compliance, privacy and accessibility checklist

Pass carried out on 3 November 2026 against the code in this repository. Target: India first (Digital Personal Data Protection Act 2023 + DPDP Rules), plus GDPR-style good practice and Google Play policies. **This is an engineering review, not legal advice; the legal texts are templates that need lawyer review.**

Legend: ✅ done in code · 📄 documented · ⚙️ owner action · ⚠️ not verifiable here

## 1. Legal texts
- ✅ Privacy Policy, Terms of Service, Cookie & Local Storage Policy and an account-deletion page: `lib/features/legal/legal_texts.dart`, shown in-app (Settings › About; Privacy settings; registration) and exported to `docs/legal/*.md` by `dart run tool/export_legal.dart`. A test fails if the markdown drifts from the app text.
- ✅ Each text is marked **"Template — needs lawyer review"** on screen and in markdown.
- ✅ Grievance Officer section (name, email, address, response time) in Privacy Policy, Terms and the About & contact screen; mentions the Data Protection Board of India.
- ✅ Content written from the data inventory (what is really collected, retention values match `functions/src/maintenance/purge.ts`).
- ⚙️ Lawyer review; publish `docs/legal/privacy-policy.md` and `account-deletion.md` at public URLs.

## 2. Business details
- ✅ Single source: `lib/core/config/business_info.dart` (placeholders start with `YOUR_`). Legal texts, About & contact, Help, Account and Privacy screens read it.
- ✅ The About & contact screen shows a "Setup incomplete — do not publish" warning while any placeholder remains.
- ⚙️ Fill every placeholder (list in README), then run `dart run tool/export_legal.dart`.

## 3. Consent for storage / optional processing ("cookie consent")
- 📄 The app uses **no cookies, ad IDs or analytics**, so there is **no cookie banner** (adding one would be misleading).
- ✅ First-run **Privacy choices** screen (`lib/features/privacy/privacy_choices_screen.dart`) instead: explains essential on-device storage; asks separately for **notifications** and **AI processing**; both unticked; **"Decline all" and "Accept all" are the same widget, variant and width**; "Save my choices" for a mix; no close button that counts as consent (back is blocked on first run).
- ✅ Stored with **notice version + UTC timestamp** (`SettingsController.savePrivacyChoices`), copied into `users/{uid}.consents.privacyChoices` at sign-up.
- ✅ Changeable any time: Settings › Privacy choices, Privacy settings, Notification preferences.
- ✅ Shown again automatically if `LegalVersions.privacyChoices` changes.

## 4. Form consent
- ✅ Registration has **two separate unticked checkboxes**: "I confirm I am 18 years or older" and "I agree to the Terms of Service and Privacy Policy". Both required; neither pre-checked; links are separate buttons (keyboard-reachable, 48dp).
- ✅ Recorded in the user document: `consents.termsVersion`, `privacyVersion`, `acceptedAt` (server timestamp), `ageConfirmed`, `minimumAge`.
- ✅ Firestore rules: `consents` must be valid on create (version strings, `acceptedAt == request.time`, `ageConfirmed == true`, whitelisted keys); on update it is either unchanged or a fresh valid self-acceptance. `privacy` changes must carry `updatedAt == request.time`.
- ✅ Verified existing consents: recording consent dialog before every session, `consentReference` stored and **re-checked by the server** before transcription (`medical/handlers.ts`); AI consents re-checked server-side (`medical/handlers.ts`, `scam/handler.ts`). Fixed: the medical AI dialog reported consent as given even when saving it failed; it now returns false unless saved.
- ✅ Firestore rules are emulator-tested (`rules-tests/`, 299 cases passing on 5 Nov 2026). ⚠️ The 26 Storage cases compile but could not be executed in the build sandbox (the Storage emulator download was blocked); CI runs them (`rules` job). Run `cd rules-tests && npm test` before release.
- ⚙️ When you bump `LegalVersions.terms`/`privacy`, add a re-acceptance prompt (rules already allow a fresh self-acceptance).

## 5. Data minimisation
- ✅ Full audit in `docs/DATA_INVENTORY.md` (field, purpose, retention, who sees it).
- ✅ Removed the unused account phone number; removed `CAMERA` permission; delete local recording files after upload; "Remove photo"; push token only after opt-in; user-document field whitelist in rules.

## 6. Third-party SDKs
- ✅ `docs/THIRD_PARTY_SDKS.md`: every direct dependency, data touched, off-device transfer, licence.
- ✅ No analytics/ads SDKs; Firebase Analytics not included; manifest flags disable analytics collection, ad-ID collection, ad personalisation signals and FCM auto-init. Backend test asserts all of this.

## 7. Dark patterns — findings and fixes

| # | Where | Finding | Pattern | Fix |
|---|---|---|---|---|
| 1 | `home_shell.dart` | Asked for notification permission the first time the home screen opened, with no explanation | Unexplained / nagging permission prompt | Asks only after the user opts in on Privacy choices or taps "Allow" in Notification preferences. Never re-asks on its own. |
| 2 | `auth_repository.dart` | All notification categories defaulted **on** at sign-up | Pre-ticked opt-in | Categories now start in the state the user chose (all off if they declined). |
| 3 | `register_screen.dart` | One combined checkbox; Terms/Privacy links were tiny inline text spans (not keyboard-reachable) | Bundled consent, small targets | Separate 18+ and Terms checkboxes, both unticked; links are 48dp buttons. |
| 4 | `ai_consent.dart`, `scam_shield_screen.dart`, `recording_screen.dart`, lock-screen dialog | Agree = filled button, decline = small text button; decline label "Not now" implied it would be asked again | Visual interference / hidden decline | `showConfirmDialog(equalWeight: true)`: both answers are identical outlined buttons; "No, thanks" / "Keep private". |
| 5 | `account_screen.dart` | "Removes your data within 30 days. Backups expire within 35 days" — not what the code does, and unverified | Misleading information | Accurate text: deleted from the live database and storage immediately; backups (if enabled) expire on their own schedule. Added deletion-without-app route. |
| 6 | `notification_settings_screen.dart` | Security alerts subtitle "Recommended: keep on" | Mild nudge (kept) | Reworded to a neutral explanation; the switch still works. |
| 7 | Notifications | No single way to stop everything | Obstruction | "All notifications" master switch (one tap off/on); also unregisters the device token. |
| 8 | Onboarding | Title "Scam Protection" overstated what a warning-sign check does | Overclaim | "Scam Warnings", with "It can miss scams". |

Checked and **not found**: confirmshaming copy ("No, I don't want to be safe"), pre-ticked consent boxes elsewhere, forced continuity / subscriptions / trials (the app is free), hidden costs, fake urgency or countdowns, disguised ads, roach-motel account deletion (deletion is two taps + password, plus email route), fake reviews or testimonials, social-proof claims.

## 8. Fees and claims
- ✅ Terms section "Price: free, with no hidden fees" (no IAP, ads, subscriptions; AI costs borne by the operator; usage limits explained). Same statement on onboarding, registration, About & contact and Help.
- ✅ Copy review (grep for best, guarantee, 100%, secure, detects falls, prevents scams, clinical, certified, protection, safest, rating, review, testimonial, stars):
  - "sent securely" → "sent over an encrypted connection" (AI consent dialogs); "Saving securely…" → "Uploading…".
  - "Scam Protection" → "Scam Warnings"; pubspec description reworded.
  - Existing disclaimers kept: Routine Monitor "does NOT detect falls"; scam checks "cannot guarantee a message is safe"; backend strips "definitely safe" AI wording.
  - Kept: tagline "Caring Together. Living Safer." (brand tagline from the brief, aspirational, not a factual claim). ⚙️ Your call; avoid pairing it with specific safety promises in store copy.
- ✅ No ratings, review counts or testimonials anywhere in app, README or store text.
- ✅ `docs/store-listing.md`: honest Play Store copy + Data safety answers.

## 9. Accessibility
- ✅ **Images / avatars:** `UserAvatar` has a label ("Profile picture of …" / "Initials of …"); decorative initial avatars (family members, emergency contacts) and onboarding illustrations are excluded from semantics because the name/title is read next to them; logo is decorative; `onForegroundImageError` keeps initials if a photo fails to load.
- ✅ **Icon-only buttons:** every `IconButton` (14/14) and `PopupMenuButton` (5/5; two generic "Show menu" labels replaced with specific ones) has a tooltip; the dashboard avatar (tap → profile) now has a button label and tooltip; the "★" primary-contact marker is read as "primary contact".
- ✅ **Contrast:** `test/unit/contrast_test.dart` computes WCAG ratios for 13 text colour pairs in light, dark, high-contrast light and high-contrast dark themes (AA 4.5:1; high-contrast held to AAA 7:1), plus risk colours and the splash gradient. Measured minimums: light 6.46:1, dark 7.20:1, HC light 8.94:1, HC dark 11.08:1. Fixed: splash tagline (white70 on teal was 2.8:1 → white on deeper teal 5.3:1); risk/status colours in dark mode (new dark variants + `ensureContrast` for chips and status text); Routine Monitor "on" card used a light teal background under white text in dark mode.
- ✅ **High contrast:** new `AppTheme.highContrastLight/Dark` used when the in-app option is on, and for Android's high-contrast setting (`highContrastTheme`). Previously the option only set a MediaQuery flag that no widget used.
- ✅ **Keyboard / switch / D-pad:** 3dp outline focus indicator on all buttons (filled, outlined, text, icon) and a 3dp focused border on text fields; stronger focus overlay colour; `FocusTraversalGroup` on registration and Privacy choices; inline link spans replaced by focusable buttons; no focus traps found (dialogs are standard modal routes that return focus). Test: Tab reaches every choice and button on Privacy choices.
- ✅ **Targets:** theme minimums 56dp (buttons) / 48dp (text and icon buttons); dialog buttons ≥48dp. Flutter's `androidTapTargetGuideline` and `labeledTapTargetGuideline` pass on Privacy choices and Registration; `textContrastGuideline` passes on Privacy choices in light and both high-contrast themes.
- ✅ Onboarding pages scroll instead of overflowing with large text.
- ⚠️ Not verified on a device with TalkBack / Switch Access / a D-pad (no Android SDK here). Do a manual pass using `docs/TESTING_AND_QA.md`.

## 10. Children / age
- ✅ 18+ only: required unticked confirmation at sign-up; "I am under 18" button explains respectfully that we can't create an account, clears the form, stores nothing. Server copy of `ageConfirmed` enforced by rules.
- ✅ Privacy Policy "Children" section: not knowingly collected; deleted if discovered; verifiable parental consent under DPDP s.9 required before any change; no tracking/behavioural monitoring/targeted ads of children.
- 📄 No DOB collected (minimisation). ⚙️ If you ever need stronger age assurance, add it with legal advice.

## 11. Notifications and email
- ✅ Every category switchable; **"All notifications" one-tap master switch**; lock-screen detail off by default.
- 📄 No marketing email or promotional notifications exist. The backend sends no email at all; Firebase Auth sends only user-triggered verification/password-reset emails. A backend test fails if an email library is added. If you ever add marketing email, it needs separate opt-in consent and an unsubscribe link.

## 12. Asset licences
- ✅ `docs/ASSET_LICENSES.md`. ⚙️ Replace the default Flutter launcher icon (Flutter logo) before publishing.

## 13. Data deletion and export
- ✅ In-app: Settings › Account › Delete my account → confirmation listing what is deleted → password re-authentication → `accountDelete` (server requires sign-in within 10 minutes).
- ✅ Server deletion (`functions/src/account/handlers.ts` + `deletionPlan.ts`) removes: user doc + devices subcollection, all owned docs in 8 collections (incl. reminder history), memberships, invitations sent **and** received, Storage `recordings/{uid}/` and `profileImages/{uid}/`, rate-limit counters, the Auth user; families administered alone with their care profiles, memberships, invitations, reminders and emergency contacts; unlinks the user as elder (sharing reset to off) and removes them from caregiver assignments. Newly added this pass: sent invitations, rate limits, caregiver ids, family-scoped reminders/contacts. A backend test checks every collection in `firestore.rules` is covered.
- ✅ Public route without the app: "Requesting deletion without the app" in the Privacy Policy and `docs/legal/account-deletion.md` (email from `BusinessInfo.supportEmail`). ⚙️ Publish it and enter the URL in Play Console › Data deletion.
- ✅ Export: `accountExportData` returns JSON of profile + all owned collections; now also invitations sent/received and care profiles linked to / cared for by the user.
- ⚠️ Deletion and export were not run against a live Firebase project here.
- 📄 Residual after deletion: pseudonymous user ids in other users' records (e.g. `createdBy`, `consentUpdatedBy`, reminder history `by`) and other members' own content. Stated in the Privacy Policy.
