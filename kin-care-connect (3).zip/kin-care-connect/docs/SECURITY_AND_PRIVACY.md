# 8. Security and Privacy (completed)

The original brief stopped after the first four items of Section 8. This document completes the section with conservative defaults consistent with the rest of the brief. Items marked ✅ are implemented in this repository; ⚙️ need configuration in your Firebase/Google Cloud project; 📋 are operational policies to adopt before launch.

## 8.1 Implemented controls

| Control | Status | Where |
|---|---|---|
| Firebase Authentication (email/password), secure session handling by the Firebase SDK | ✅ | `features/auth` |
| Email verification required before joining a family (server-enforced) | ✅ | `functions/src/family/handlers.ts` |
| Re-authentication before password change and account deletion; server checks `auth_time` ≤ 10 min for deletion | ✅ | `auth_repository.dart`, `account/handlers.ts` |
| Firestore security rules: deny-by-default, ownership, membership, roles, consent | ✅ | `firestore.rules` |
| Storage rules: owner-only recordings, type and size limits | ✅ | `storage.rules` |
| Backend authorization on every callable (membership/role/consent re-checked server-side) | ✅ | `functions/src/**` |
| Firebase App Check (Play Integrity) enforced on all callables | ✅ ⚙️ | `main.dart`, `lib/core.ts` |
| Secrets only in Google Secret Manager (`AI_API_KEY`, `STT_API_KEY`); none in the app or APK | ✅ ⚙️ | `functions/src/ai/provider.ts` |
| Input validation (zod) with length limits on every endpoint | ✅ | `functions/src/**` |
| Per-user, per-endpoint rate limiting | ✅ | `functions/src/lib/rateLimit.ts` |
| Logging without sensitive content (hashed user ids, counts only; never text, emails or transcripts) | ✅ | `lib/core.ts` `anon()`, `logEvent()` |
| Errors mapped to safe messages; internals never returned to clients | ✅ | `guarded()` |
| Prompt-injection hardening: user text delimited and treated as data; delimiter stripping | ✅ | `ai/prompts.ts` |
| AI response validation (schema), facts vs generated text separated, "from your text" verified against input | ✅ | `ai/medicalSchema.ts`, `ai/guardrails.ts` |
| Medical guardrails: diagnosis / prescribing / dose-change sentences removed and the user is told | ✅ | `ai/guardrails.ts` |
| Scam safety: links never opened; AI can raise but not lower the rule-based risk; "safe" guarantees removed | ✅ | `scam/rules.ts`, `scam/handler.ts` |
| No sensitive details on lock screen by default (generic push text, `secret` visibility) | ✅ | `lib/notify.ts` |
| Android: `allowBackup=false`, no cleartext traffic, minimal permissions requested at time of use | ✅ | `AndroidManifest.xml` |
| R8/ProGuard minification for release builds | ✅ | `android/app/build.gradle.kts` |
| No analytics/ads SDKs; manifest disables Firebase Analytics, ad-ID collection, ad personalisation and FCM auto-init | ✅ | `AndroidManifest.xml`, `docs/THIRD_PARTY_SDKS.md` |
| Firestore rules whitelist user-document fields and validate consent records (version, `request.time`, 18+) | ✅ ⚠️ not emulator-tested | `firestore.rules` (`userKeys`, `validConsents`, `validPrivacy`) |

## 8.2 Consent model

- **First-run Privacy choices** (`features/privacy/privacy_choices_screen.dart`): explains essential on-device storage (no cookies) and asks for two optional things — notifications and AI processing. Nothing pre-ticked; "Decline all" and "Accept all" are identical buttons; answer stored on the device with notice version + UTC timestamp and copied to `users/{uid}.consents.privacyChoices` at sign-up. Changeable in Settings › Privacy choices. The notification permission prompt and FCM token only happen after opt-in.
- **Registration:** two separate unticked checkboxes — 18+ confirmation and Terms + Privacy. Stored as `consents.{termsVersion, privacyVersion, acceptedAt (server time), ageConfirmed, minimumAge}`. Under-18s get a respectful explanation and nothing is stored.
- **AI processing** is off by default. Separate opt-ins for Medical Translator AI and Scam Shield AI, stored in `users/{uid}.privacy` with `policyVersion` and `updatedAt` (server time, enforced by rules) and **re-checked on the server** before any provider call. Consent dialogs use equal-weight buttons.
- **Recording consent:** before every recording session the user confirms that everyone present agrees; a consent reference is stored with the recording and the server refuses to transcribe recordings without one.
- **Family sharing:** each care profile has three independent switches (activity, medical, reminders), all **off** when created. Only the linked elderly account holder can change them; an admin can only while no elderly account is linked. Linking an elder resets all switches to off.
- **Monitoring:** off by default, explicit confirmation to start, visible status at all times, one tap to stop.

## 8.3 Data minimisation

Full field-by-field table: `docs/DATA_INVENTORY.md`.

- Passwords are never stored in Firestore (Firebase Auth handles credentials).
- Scam checks store only the verdict and indicator names, **never the message text**.
- **No account phone number** (removed: it was unused); no date of birth (18+ confirmation instead). No location, contacts, camera or call-log access.
- Dialing emergency contacts uses the system dialer intent; the app holds no `CALL_PHONE` permission.
- Recording temp files are deleted from the phone after upload or when abandoned.
- Push token exists only after notification opt-in; deleted on logout / opt-out.

## 8.4 Retention and deletion

| Data | Retention | Mechanism |
|---|---|---|
| Audio recordings (+ transcripts) | 30 days, or sooner on user delete | `purgeExpiredData` (daily) |
| Scam-check results | 180 days | `purgeExpiredData` |
| Notifications | 90 days | `purgeExpiredData` |
| Invitations | 30 days | `purgeExpiredData` |
| Rate-limit counters | ~2 days after window | `purgeExpiredData` |
| Medical summaries, reminders, contacts, activity | Until the user deletes them or the account | user actions / `accountDelete` |
| Account deletion | Immediate deletion of the user doc (+devices), owned docs in 8 collections, invitations sent/received, rate-limit counters, Storage recordings + profile pictures, and the Auth user; families administered alone removed with their care profiles, memberships, invitations, reminders and contacts; unlinked as elder (sharing reset) and removed from caregiver assignments | `accountDelete`, `account/deletionPlan.ts` |

Data export (JSON) is available in Settings › Account (`accountExportData`), including invitations and care profiles that refer to the user. Users who cannot use the app can request deletion by email (public page: `docs/legal/account-deletion.md`; address from `business_info.dart`).

**Email:** the backend sends no email. Firebase Auth sends only user-triggered verification and password-reset emails. There is no marketing email or promotional notification, so no unsubscribe mechanism is required; every notification category can be switched off, or all at once.

## 8.5 Encryption

- In transit: TLS for all Firebase and provider traffic.
- At rest: Google-managed encryption for Firestore and Storage. ⚙️ Consider CMEK if required by your compliance needs.

## 8.6 Operational policies 📋 (before launch)

1. **Least privilege in Google Cloud IAM:** only named people get Owner/Editor; use separate projects for dev / staging / production.
2. **Budget alerts** on the Firebase project and **spend caps** at the AI provider.
3. **Provider due diligence:** a data-processing agreement; no training on customer data; data residency suitable for your users.
4. **Incident response:** a contact for security reports, a 72-hour breach notification process, and key rotation steps (`firebase functions:secrets:set` + redeploy).
5. **Legal:** fill `lib/core/config/business_info.dart`, run `dart run tool/export_legal.dart`, have `docs/legal/` (templates) reviewed for the DPDP Act 2023 + Rules and any other jurisdiction you serve; appoint the Grievance Officer; publish the privacy policy and account-deletion page. See `docs/COMPLIANCE_CHECKLIST.md`.
6. **Google Play:** complete the Data safety and Health apps declarations from `docs/store-listing.md` (no diagnosis claims); set the target audience to 18+; replace the default Flutter launcher icon.
7. **Monitoring:** Cloud Logging alerts on spikes of `*.failed`, `resource-exhausted` and permission-denied events.
8. **Dependency hygiene:** Dependabot (or similar) for `pubspec.yaml` and `functions/package.json`; review advisories monthly.
9. **Penetration test** of rules and callables before public launch (use the Firestore emulator + `@firebase/rules-unit-testing`).

## 8.7 Threats considered

| Threat | Mitigation |
|---|---|
| A user reads another family's data | Membership-based rules with deterministic membership ids; all family queries constrained by `familyId`; server re-checks |
| A caregiver sees data the elder didn't approve | Consent flags checked in rules and functions |
| Invitation hijacking | Invitee email must match the verified token email; invitations expire after 14 days; admins can revoke |
| Leaked API keys | Keys only in Secret Manager; App Check + auth required to reach any AI endpoint; rate limits cap abuse |
| Prompt injection via pasted text | Delimited input, instruction to ignore embedded instructions, schema validation, output guardrails |
| Shoulder-surfing medical info on lock screen | Generic notification text by default |
| Silent tracking by SDKs | No analytics/ads SDKs; manifest kill-switches; backend test fails if one is added |
| Children signing up | 18+ confirmation required (client + rules); under-18 path stores nothing |
| Scraping or abuse of AI endpoints | App Check, per-user rate limits, input size limits |
