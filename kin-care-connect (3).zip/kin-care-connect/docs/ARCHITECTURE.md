# Architecture

## App (Flutter)

```
lib/
  main.dart                 Firebase init, App Check, emulator switch, setup screen if unconfigured
  app.dart                  Providers, MaterialApp.router, accessibility scaling, MonitoringTracker
  core/
    config/                 --dart-define build config (no secrets), business_info.dart (owner details), legal_versions.dart
    router/                 go_router with auth-based route protection + bottom-nav shell
    services/               AuthState, SessionController, SettingsController, FunctionsService
    theme/                  Material 3 design system (calm blue/teal, 56dp targets, light/dark/high-contrast, focus outlines), contrast.dart (WCAG ratio helpers)
    utils/                  validators, formatters, AppException (plain-language errors)
    widgets/                KcButton, KcCard, KcTextField, KcPasswordField, KcNotice, dialogs, states, logo
  features/legal/           legal texts (template) shared by the app and tool/export_legal.dart
  features/privacy/         first-run Privacy choices screen
  features/<module>/
    data/                   repositories (Firestore / Storage / callables)
    domain/                 models + pure logic (scam rules, repeat rules)
    presentation/           screens and widgets
```

State: `provider` (ChangeNotifier for app-level state; StreamBuilder for live Firestore data). Repositories are injected so screens are testable with fakes.

## Data model (Firestore)

| Collection | Key fields | Access |
|---|---|---|
| `users/{uid}` | fullName, email, role, profileImage, accessibilitySettings, notificationPrefs, privacy{…, policyVersion, updatedAt}, monitoring, consents{termsVersion, privacyVersion, acceptedAt, ageConfirmed, minimumAge, privacyChoices} (field whitelist in rules; see DATA_INVENTORY.md) | owner |
| `users/{uid}/devices/{id}` | FCM token | owner + server |
| `families/{familyId}` | familyName, createdBy | members |
| `familyMembers/{familyId}_{uid}` | role (admin/caregiver/viewer/elderly), permissions, invitationStatus | self + members; admin edits |
| `invitations/{id}` | familyId, inviteeEmail, role, profileId?, status, expiresAt | invitee + admins; server writes |
| `careProfiles/{id}` | familyId, displayName, linkedUserId?, caregiverIds[], sharingConsent{activity,medical,reminders} | members; admin edits; consent by elder |
| `activityRecords/{id}` | userId, profileId?, familyId?, activityType, timestamp, source, consentReference | owner; members if consent.activity |
| `medicalSummaries/{id}` | userId, title, originalText, summaryText, language, profileId?, sharedWithFamily, retentionStatus | owner; carers if shared + consent.medical |
| `recordings/{id}` | userId, storageReference, consentReference, durationSeconds, transcript?, deletionStatus | owner |
| `scamChecks/{id}` | userId, inputType, riskLevel, indicators, recommendations, aiUsed | owner (no message text) |
| `reminders/{id}` (+ `history/`) | userId, profileId?, title, reminderType, schedule, repeatRule, nextDueAt, completionStatus, notified | owner; carers if consent.reminders; elder completes |
| `notifications/{id}` | userId, type, title, message, readStatus, link | owner; server writes |
| `emergencyContacts/{id}` | ownerId, contactName, relationship, phoneNumber, isPrimary, profileId?, familyId? | owner; family members |
| `rateLimits/{uid_endpoint}` | windowStart, count, expiresAt | server only |

## Backend (Cloud Functions, TypeScript)

```
functions/src/
  index.ts                  exports
  lib/core.ts               admin init, auth checks, validation, role checks, safe logging, error wrapper
  lib/rateLimit.ts          fixed-window limiter
  lib/notify.ts             in-app + push notifications (generic lock-screen text)
  ai/provider.ts            OpenAI-compatible chat (JSON mode) + speech-to-text, secrets via Secret Manager
  ai/prompts.ts             structured prompts with medical/scam safety rules
  ai/medicalSchema.ts       zod schema for AI output
  ai/guardrails.ts          dose/diagnosis/prescribing removal, fact verification
  medical/handlers.ts       explain, summarize, transcribe
  scam/rules.ts, handler.ts rule engine (mirrors Dart) + optional AI review
  family/handlers.ts        invite, accept/reject, revoke
  activity/handler.ts       daily summary
  reminders/handlers.ts     create, scheduled dispatch
  account/handlers.ts       export, delete
  account/deletionPlan.ts   what export/deletion cover (unit-tested)
  maintenance/purge.ts      retention enforcement
```
