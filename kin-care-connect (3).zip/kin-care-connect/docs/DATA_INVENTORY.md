# Data inventory

Every personal-data field Kin Care Connect stores, why, for how long, and who can see it. This is the source the Privacy Policy (`lib/features/legal/legal_texts.dart`, `docs/legal/privacy-policy.md`) and the Google Play Data safety answers (`docs/store-listing.md`) were written from. Update all three together.

Audit date: 3 November 2026 (code in this repository). "Owner" = the signed-in user the data belongs to. "Server" = Cloud Functions using the Admin SDK. "Family" = accepted members of the same family group, subject to the care profile's sharing approvals.

## Changes made in this audit (data minimisation)

| Change | Why |
|---|---|
| **Removed the account phone number** (`users.phone`) from registration and Edit profile. Existing values are deleted the next time the profile is saved (`FieldValue.delete()`); Firestore rules no longer allow adding one. | It was collected "optionally" but no feature used it (no SMS, no OTP, never shown to family). |
| **Removed the `CAMERA` permission** from `AndroidManifest.xml`. | "Take a photo" uses the system camera app via intent, which needs no permission. |
| **Recording temp files are deleted** from the phone after a successful upload, and when the user leaves the screen without saving. | The audio previously stayed in the app's cache folder after upload. |
| **Added "Remove photo"** for the profile picture (deletes both Storage files and the field). | Users could replace but not remove a picture. |
| **No notification token until opt-in**: FCM auto-init disabled; token created only after the user chooses notifications. Logging out or "turn off all notifications" deletes it. | Previously the app requested permission and registered a token on first entry to the home screen. |
| **Firestore rules now whitelist user-document fields** (`userKeys()`), so no client can add unlisted personal data to a profile. | Enforces this inventory server-side. |
| **Account deletion now also removes** invitations the user sent, rate-limit counters, the user's id from caregiver assignments, and the family-scoped reminders/emergency contacts of families they administered alone. | Gaps found while verifying item 13. |

No date of birth is collected: registration asks for an 18+ confirmation instead (less data than a DOB).

Kept but not strictly required: **account type** (`users.role`, "elderly member" / "caregiver"). It is a label the user chooses and only they see it; no feature depends on it. Low risk, but you may remove it later.

## Inventory

### Account (`users/{uid}`) — owner only

| Field | Purpose | Retention | Who sees it |
|---|---|---|---|
| `uid` | Document id copy | Until account deletion | Owner |
| `fullName` | Greeting; shown to family members (copied into memberships) | Until deletion | Owner, family members |
| `email` | Sign-in (Firebase Auth), invitations, shown to family members | Until deletion | Owner, family members, Firebase Auth |
| `role` | Self-chosen label (elderly member / caregiver) | Until deletion | Owner |
| `profileImage` | URL of optional profile picture | Until removed or deletion | Owner, family members (any signed-in user with the URL) |
| `accessibilitySettings` | Large text / high contrast across devices | Until deletion | Owner |
| `notificationPrefs` | Which notifications to send; lock-screen detail | Until deletion | Owner, server |
| `privacy.aiMedicalConsent`, `privacy.aiScamConsent` | Consent for AI processing; re-checked by server | Until deletion | Owner, server |
| `privacy.recordingConsentAcknowledged`, `privacy.policyVersion`, `privacy.updatedAt` | Consent state, version and time of last change | Until deletion | Owner |
| `consents.termsVersion`, `consents.privacyVersion`, `consents.acceptedAt` | Proof of agreement to Terms + Privacy (server timestamp) | Until deletion | Owner |
| `consents.ageConfirmed`, `consents.minimumAge` | 18+ confirmation at sign-up | Until deletion | Owner |
| `consents.privacyChoices` (`version`, `decidedAt`, `notifications`, `ai`) | First-run privacy-choices answer | Until deletion | Owner |
| `monitoring` (`active`, `startedAt`, `prefs`) | Routine Monitor state | Until deletion | Owner |
| `createdAt`, `updatedAt` | Record keeping | Until deletion | Owner |
| `devices/{id}.token`, `platform`, `updatedAt` | FCM push token (only after opt-in) | Until logout, opt-out, invalid token or deletion | Owner, server |
| Password | Sign-in | Held by Firebase Authentication only (hashed); never in Firestore | Nobody |

### Family care

| Collection / field | Purpose | Retention | Who sees it |
|---|---|---|---|
| `families/{id}`: `familyName`, `createdBy` | Group | Until deleted (with last admin's account) | Members |
| `familyMembers/{fid_uid}`: `role`, `permissions`, `invitationStatus`, `displayName`, `email` | Membership and access control | Until the member leaves/is removed/deletes account | Self, members |
| `invitations/{id}`: `inviteeEmail`, `invitedBy`, `invitedByName`, `familyName`, `role`, `profileId`, `status`, `expiresAt` | Invite flow | 30 days (purge), expires after 14; deleted with inviter or invitee account | Invitee, family admins |
| `careProfiles/{id}`: `displayName`, `notes`, `caregiverIds`, `linkedUserId`, `sharingConsent{activity,medical,reminders}`, `consentUpdatedBy/At` | The person cared for and their sharing approvals | Until an admin deletes it or the family is deleted | Members; consent changed by linked elder (or admin if none) |
| `reminders/{id}`: `title`, `reminderType`, `schedule`, `repeatRule`, `notes`, `nextDueAt`, `completionStatus`, `notified`, `profileId`, `familyId` | Care reminders | Until deleted | Owner; family only if `sharingConsent.reminders` |
| `reminders/{id}/history`: `action`, `by`, `at`, `occurrence`, `minutes` | Completion / snooze log | With the reminder | As the reminder |
| `emergencyContacts/{id}`: `contactName`, `relationship`, `phoneNumber`, `isPrimary`, `ownerId`, `familyId?` | Quick dialling (system dialer; no CALL_PHONE) | Until deleted | Owner; family members if added to a family |

### Medical Translator

| Collection / field | Purpose | Retention | Who sees it |
|---|---|---|---|
| `medicalSummaries/{id}`: `title`, `originalText`, `summaryText`, `language`, `sharedWithFamily`, `profileId`, `retentionStatus` | Saved explanations | Until deleted | Owner; carers only if author shared it and `sharingConsent.medical` |
| `recordings/{id}`: `storageReference`, `consentReference`, `durationSeconds`, `transcript`, `transcriptionStatus`, `deletionStatus` | Consented audio + transcript | **30 days** (purge) or sooner on delete | Owner only |
| Storage `recordings/{uid}/*.m4a` | Audio | 30 days | Owner only |
| Text / audio sent to AI provider | Explanation, summary, transcription | Not stored by us beyond the above; provider retention per your DPA (choose zero/short retention, no training) | AI provider (processor) |

### Scam Shield

| Field | Purpose | Retention | Who sees it |
|---|---|---|---|
| `scamChecks/{id}`: `inputType`, `riskLevel`, `indicators`, `recommendations`, `aiUsed` | History of results. **Never the message text** (rules accept only these verdict fields plus `userId`/`createdAt`, so `text`, `message` or any other field is rejected) | **180 days** | Owner only |
| Message text for AI check | Analysis only when the user asks | Not stored | Server, AI provider |

### Routine Monitor

| Field | Purpose | Retention | Who sees it |
|---|---|---|---|
| `activityRecords/{id}`: `activityType` (monitoringStarted/Stopped, appOpened, checkIn, interaction), `timestamp`, `source='app_foreground'`, `profileId`, `familyId`, `consentReference` | Simple activity log while monitoring is on and app open | Until deleted | Owner; family only if `sharingConsent.activity` |

No location, sensors, microphone, camera, contacts, call logs or SMS are read.

### Notifications and service data

| Field | Purpose | Retention | Who sees it |
|---|---|---|---|
| `notifications/{id}`: `type`, `title`, `message`, `link`, `readStatus` | In-app notification centre | **90 days** | Owner |
| `rateLimits/{uid_endpoint}`: `windowStart`, `count`, `expiresAt` | Abuse / cost control | ~2 days after window; deleted with account | Server only |
| Cloud Logging events | Operations; hashed 10-char user id, counts, error codes — never content, names or emails | Cloud Logging default (30 days) unless you change it | Operator |
| App Check / Play Integrity attestation | Prove requests come from the genuine app | Handled by Google | Google, server |

### On the device (see Cookie & Local Storage Policy)

| Item | Purpose | Retention |
|---|---|---|
| shared_preferences: `themeMode`, `largeText`, `highContrast`, `onboardingComplete`, `privacyChoices.version/decidedAt/notifications/ai` | Settings and privacy choices | Until app data is cleared / uninstall |
| Firebase Auth session | Stay signed in | Until logout |
| Firestore offline cache | Speed / brief offline use | Managed by the SDK; cleared with app data |
| App Check token | Integrity | Short-lived |
| FCM token | Push (opt-in only) | Until opt-out/logout |
| Recording temp file | Recording in progress | Deleted after upload or discard |

## What is not collected

Location, contacts, call logs, SMS inbox, calendar, device identifiers for advertising, analytics events, crash reports, cookies, date of birth, government IDs, payment details, account phone number.
