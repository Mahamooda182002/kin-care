// Family-shared care data: activity records, medical summaries, reminders
// (+ history) and emergency contacts. Owner rules plus consent rules.
import { assertFails, assertSucceeds, RulesTestEnvironment } from "@firebase/rules-unit-testing";
import { as, createEnv, Db, FAM1, FAM2, pastTime, seedWorld, serverTime, U } from "./helpers";

const revoke = (db: Db, profileId: string, kind: "activity" | "medical" | "reminders", by: string) =>
  db.doc(`careProfiles/${profileId}`).update({
    sharingConsent: { activity: kind !== "activity", medical: kind !== "medical", reminders: kind !== "reminders" },
    consentUpdatedBy: by, consentUpdatedAt: serverTime(),
  });

describe("care data", () => {
  let env: RulesTestEnvironment;
  before(async () => { env = await createEnv(); });
  after(async () => { await env?.cleanup(); });
  beforeEach(async () => { await env.clearFirestore(); await seedWorld(env); });

  // ---------------------------------------------------------------------
  describe("activityRecords", () => {
    const rec = (uid: string, extra: Record<string, unknown> = {}) => ({
      userId: uid, profileId: "pLinked", familyId: FAM1, activityType: "checkIn",
      timestamp: serverTime(), source: "app_foreground", consentReference: "careProfiles/pLinked#sharingConsent.activity", ...extra,
    });

    it("allows the owner to read their own record", async () => {
      await assertSucceeds(as(env, U.ellie).doc("activityRecords/actSelf").get());
    });
    for (const uid of [U.alice, U.carol, U.victor]) {
      it(`allows the member '${uid}' to read shared activity when consent is on`, async () => {
        await assertSucceeds(as(env, uid).doc("activityRecords/actShared").get());
      });
    }
    it("denies a caregiver reading activity when consent is off", async () => {
      await assertFails(as(env, U.carol).doc("activityRecords/actNoConsent").get());
    });
    it("denies a caregiver once the elder revokes activity consent", async () => {
      await assertSucceeds(as(env, U.carol).doc("activityRecords/actShared").get());
      await assertSucceeds(revoke(as(env, U.ellie), "pLinked", "activity", U.ellie));
      await assertFails(as(env, U.carol).doc("activityRecords/actShared").get());
    });
    it("denies members reading the elder's personal (non-profile) record", async () => {
      await assertFails(as(env, U.alice).doc("activityRecords/actSelf").get());
    });
    for (const uid of [U.dan, U.oscar, U.mallory]) {
      it(`denies '${uid}' reading shared activity`, async () => {
        await assertFails(as(env, uid).doc("activityRecords/actShared").get());
      });
    }
    it("allows the linked elder to log activity for their profile when consent is on", async () => {
      await assertSucceeds(as(env, U.ellie).collection("activityRecords").add(rec(U.ellie)));
    });
    it("allows anyone to log personal activity without a profile", async () => {
      await assertSucceeds(as(env, U.carol).collection("activityRecords").add(rec(U.carol, { profileId: null, familyId: null, consentReference: "self" })));
    });
    it("denies logging profile activity when consent is off", async () => {
      await assertFails(as(env, U.ellie).collection("activityRecords").add(rec(U.ellie, { profileId: "pNoConsent" })));
    });
    it("denies a caregiver logging activity for a profile they are not linked to", async () => {
      await assertFails(as(env, U.carol).collection("activityRecords").add(rec(U.carol)));
    });
    it("denies logging activity in someone else's name", async () => {
      await assertFails(as(env, U.carol).collection("activityRecords").add(rec(U.ellie)));
    });
    it("denies a mismatched familyId", async () => {
      await assertFails(as(env, U.ellie).collection("activityRecords").add(rec(U.ellie, { familyId: FAM2 })));
    });
    it("denies a client-chosen timestamp", async () => {
      await assertFails(as(env, U.ellie).collection("activityRecords").add(rec(U.ellie, { timestamp: pastTime() })));
    });
    it("denies an unknown activity type or source", async () => {
      await assertFails(as(env, U.ellie).collection("activityRecords").add(rec(U.ellie, { activityType: "location" })));
      await assertFails(as(env, U.ellie).collection("activityRecords").add(rec(U.ellie, { source: "background_sensor" })));
    });
    it("denies updating a record (immutable)", async () => {
      await assertFails(as(env, U.ellie).doc("activityRecords/actSelf").update({ activityType: "checkIn" }));
    });
    it("allows the owner to delete, denies others", async () => {
      await assertFails(as(env, U.alice).doc("activityRecords/actShared").delete());
      await assertSucceeds(as(env, U.ellie).doc("activityRecords/actShared").delete());
    });
  });

  // ---------------------------------------------------------------------
  describe("medicalSummaries", () => {
    const summary = (uid: string, extra: Record<string, unknown> = {}) => ({
      userId: uid, title: "Visit", profileId: null, familyId: null, sharedWithFamily: false,
      originalText: "o", summaryText: "s", language: "en", retentionStatus: "keep", createdAt: serverTime(), updatedAt: serverTime(), ...extra,
    });

    it("allows the author to read their summary", async () => {
      await assertSucceeds(as(env, U.ellie).doc("medicalSummaries/medPrivate").get());
    });
    it("denies anyone else reading a private summary", async () => {
      await assertFails(as(env, U.alice).doc("medicalSummaries/medPrivate").get());
    });
    for (const uid of [U.carol, U.ellie]) {
      it(`allows '${uid}' (assigned caregiver / linked elder) to read a shared summary with medical consent`, async () => {
        await assertSucceeds(as(env, uid).doc("medicalSummaries/medShared").get());
      });
    }
    it("denies a viewer reading a shared summary", async () => {
      await assertFails(as(env, U.victor).doc("medicalSummaries/medShared").get());
    });
    it("denies an unassigned caregiver reading a shared summary", async () => {
      await assertFails(as(env, U.cara).doc("medicalSummaries/medShared").get());
    });
    it("denies reading a summary the author did not share", async () => {
      await assertFails(as(env, U.carol).doc("medicalSummaries/medNotShared").get());
    });
    it("denies reading a shared summary when medical consent is off", async () => {
      await assertFails(as(env, U.carol).doc("medicalSummaries/medNoConsent").get());
    });
    it("denies the caregiver once the elder revokes medical consent", async () => {
      await assertSucceeds(revoke(as(env, U.ellie), "pLinked", "medical", U.ellie));
      await assertFails(as(env, U.carol).doc("medicalSummaries/medShared").get());
    });
    it("denies an assigned caregiver who was demoted to viewer", async () => {
      await assertSucceeds(as(env, U.alice).doc(`familyMembers/${FAM1}_${U.carol}`).update({ role: "viewer" }));
      await assertFails(as(env, U.carol).doc("medicalSummaries/medShared").get());
    });
    for (const uid of [U.oscar, U.mallory]) {
      it(`denies '${uid}' reading a shared summary`, async () => {
        await assertFails(as(env, uid).doc("medicalSummaries/medShared").get());
      });
    }
    it("allows creating a personal summary", async () => {
      await assertSucceeds(as(env, U.victor).collection("medicalSummaries").add(summary(U.victor)));
    });
    it("allows a caregiver to create a summary for a profile in their family", async () => {
      await assertSucceeds(as(env, U.carol).collection("medicalSummaries").add(summary(U.carol, { profileId: "pLinked", familyId: FAM1, sharedWithFamily: true })));
    });
    it("denies a viewer creating a profile summary", async () => {
      await assertFails(as(env, U.victor).collection("medicalSummaries").add(summary(U.victor, { profileId: "pLinked", familyId: FAM1 })));
    });
    it("denies a profile summary with a mismatched familyId", async () => {
      await assertFails(as(env, U.mallory).collection("medicalSummaries").add(summary(U.mallory, { profileId: "pLinked", familyId: FAM2 })));
    });
    it("denies creating a summary in someone else's name", async () => {
      await assertFails(as(env, U.carol).collection("medicalSummaries").add(summary(U.ellie)));
    });
    it("denies an over-long title", async () => {
      await assertFails(as(env, U.carol).collection("medicalSummaries").add(summary(U.carol, { title: "x".repeat(101) })));
    });
    it("allows the author to edit title and summary", async () => {
      await assertSucceeds(as(env, U.ellie).doc("medicalSummaries/medPrivate").update({ title: "New", summaryText: "new", updatedAt: serverTime() }));
    });
    it("denies the author toggling sharedWithFamily after creation", async () => {
      await assertFails(as(env, U.ellie).doc("medicalSummaries/medPrivate").update({ sharedWithFamily: true }));
    });
    it("denies a caregiver editing a shared summary", async () => {
      await assertFails(as(env, U.carol).doc("medicalSummaries/medShared").update({ title: "Edited" }));
    });
    it("allows the author to delete, denies others", async () => {
      await assertFails(as(env, U.carol).doc("medicalSummaries/medShared").delete());
      await assertSucceeds(as(env, U.alice).doc("medicalSummaries/medShared").delete());
    });
  });

  // ---------------------------------------------------------------------
  describe("reminders", () => {
    const own = (uid: string, extra: Record<string, unknown> = {}) => ({
      userId: uid, profileId: null, familyId: null, title: "Water plants", reminderType: "general",
      completionStatus: "pending", notified: false, createdAt: serverTime(), ...extra,
    });

    it("allows the owner to read their own reminder", async () => {
      await assertSucceeds(as(env, U.carol).doc("reminders/remOwn").get());
    });
    it("denies others reading a personal reminder", async () => {
      await assertFails(as(env, U.alice).doc("reminders/remOwn").get());
    });
    for (const uid of [U.alice, U.carol, U.victor, U.ellie]) {
      it(`allows '${uid}' to read a profile reminder with reminders consent`, async () => {
        await assertSucceeds(as(env, uid).doc("reminders/remShared").get());
      });
    }
    it("denies an unassigned caregiver reading a profile reminder", async () => {
      await assertFails(as(env, U.cara).doc("reminders/remShared").get());
    });
    it("denies caregivers and viewers when reminders consent is off", async () => {
      await assertFails(as(env, U.carol).doc("reminders/remNoConsent").get());
      await assertFails(as(env, U.victor).doc("reminders/remNoConsent").get());
    });
    it("still lets the linked elder read their reminder when consent is off", async () => {
      await assertSucceeds(as(env, U.ellie).doc("reminders/remNoConsent").get());
    });
    it("denies the caregiver once the elder revokes reminders consent", async () => {
      await assertSucceeds(revoke(as(env, U.ellie), "pLinked", "reminders", U.ellie));
      await assertFails(as(env, U.carol).doc("reminders/remShared").get());
      await assertFails(as(env, U.victor).doc("reminders/remShared").get());
    });
    for (const uid of [U.dan, U.oscar, U.mallory]) {
      it(`denies '${uid}' reading a profile reminder`, async () => {
        await assertFails(as(env, uid).doc("reminders/remShared").get());
      });
    }
    it("allows creating your own reminder", async () => {
      await assertSucceeds(as(env, U.victor).collection("reminders").add(own(U.victor)));
    });
    it("denies creating a profile reminder directly (must use the function)", async () => {
      await assertFails(as(env, U.alice).collection("reminders").add(own(U.alice, { profileId: "pLinked", familyId: FAM1 })));
    });
    it("denies creating a reminder for someone else", async () => {
      await assertFails(as(env, U.alice).collection("reminders").add(own(U.ellie)));
    });
    it("denies an empty title", async () => {
      await assertFails(as(env, U.victor).collection("reminders").add(own(U.victor, { title: "" })));
    });
    it("allows the assigned caregiver to edit a profile reminder", async () => {
      await assertSucceeds(as(env, U.carol).doc("reminders/remShared").update({ title: "Take tablets after lunch" }));
    });
    it("allows the admin to edit a profile reminder", async () => {
      await assertSucceeds(as(env, U.alice).doc("reminders/remShared").update({ title: "Updated" }));
    });
    it("denies a viewer editing a profile reminder", async () => {
      await assertFails(as(env, U.victor).doc("reminders/remShared").update({ title: "Nope" }));
    });
    it("denies an unassigned caregiver editing a profile reminder", async () => {
      await assertFails(as(env, U.cara).doc("reminders/remShared").update({ title: "Nope" }));
    });
    it("denies the caregiver editing when reminders consent is off", async () => {
      await assertFails(as(env, U.carol).doc("reminders/remNoConsent").update({ title: "Nope" }));
    });
    it("allows the linked elder to complete a reminder", async () => {
      await assertSucceeds(as(env, U.ellie).doc("reminders/remShared").update({ completionStatus: "completed", lastCompletedAt: serverTime(), updatedAt: serverTime() }));
    });
    it("denies the linked elder editing the title", async () => {
      await assertFails(as(env, U.ellie).doc("reminders/remNoConsent").update({ title: "Changed" }));
    });
    it("denies moving a reminder to another owner or profile", async () => {
      await assertFails(as(env, U.carol).doc("reminders/remShared").update({ userId: U.carol }));
      await assertFails(as(env, U.carol).doc("reminders/remOwn").update({ profileId: "pLinked" }));
    });
    it("allows the assigned caregiver to delete; denies a viewer", async () => {
      await assertFails(as(env, U.victor).doc("reminders/remShared").delete());
      await assertSucceeds(as(env, U.carol).doc("reminders/remShared").delete());
    });

    describe("history", () => {
      const entry = (by: string, action = "completed") => ({ action, by, at: serverTime() });
      it("allows the linked elder to log a completion", async () => {
        await assertSucceeds(as(env, U.ellie).collection("reminders/remShared/history").add(entry(U.ellie)));
      });
      it("allows the assigned caregiver to log a snooze", async () => {
        await assertSucceeds(as(env, U.carol).collection("reminders/remShared/history").add({ ...entry(U.carol, "snoozed"), minutes: 10 }));
      });
      it("denies a viewer logging history", async () => {
        await assertFails(as(env, U.victor).collection("reminders/remShared/history").add(entry(U.victor)));
      });
      it("denies logging in someone else's name", async () => {
        await assertFails(as(env, U.carol).collection("reminders/remShared/history").add(entry(U.ellie)));
      });
      it("denies an unknown action", async () => {
        await assertFails(as(env, U.ellie).collection("reminders/remShared/history").add(entry(U.ellie, "deleted")));
      });
      it("allows a viewer to read history with consent; denies an outsider", async () => {
        await assertSucceeds(as(env, U.victor).doc("reminders/remShared/history/h1").get());
        await assertFails(as(env, U.oscar).doc("reminders/remShared/history/h1").get());
      });
      it("denies editing or deleting history", async () => {
        await assertFails(as(env, U.ellie).doc("reminders/remShared/history/h1").update({ action: "snoozed" }));
        await assertFails(as(env, U.alice).doc("reminders/remShared/history/h1").delete());
      });
    });
  });

  // ---------------------------------------------------------------------
  describe("emergencyContacts", () => {
    const contact = (uid: string, extra: Record<string, unknown> = {}) => ({
      ownerId: uid, contactName: "Asha", relationship: "Daughter", phoneNumber: "+91 91234 56789",
      isPrimary: false, profileId: null, familyId: null, createdAt: serverTime(), updatedAt: serverTime(), ...extra,
    });

    it("allows the owner to read their contacts", async () => {
      await assertSucceeds(as(env, U.ellie).doc("emergencyContacts/ecOwn").get());
    });
    for (const uid of [U.alice, U.carol, U.victor]) {
      it(`allows the member '${uid}' to read a family contact`, async () => {
        await assertSucceeds(as(env, uid).doc("emergencyContacts/ecFam").get());
      });
    }
    it("denies members reading a personal (non-family) contact", async () => {
      await assertFails(as(env, U.alice).doc("emergencyContacts/ecOwn").get());
    });
    for (const uid of [U.dan, U.oscar, U.mallory]) {
      it(`denies '${uid}' reading a family contact`, async () => {
        await assertFails(as(env, uid).doc("emergencyContacts/ecFam").get());
      });
    }
    it("allows creating a personal contact", async () => {
      await assertSucceeds(as(env, U.oscar).collection("emergencyContacts").add(contact(U.oscar)));
    });
    it("allows a caregiver to add a family contact", async () => {
      await assertSucceeds(as(env, U.carol).collection("emergencyContacts").add(contact(U.carol, { familyId: FAM1, profileId: "pLinked" })));
    });
    it("denies a viewer adding a family contact", async () => {
      await assertFails(as(env, U.victor).collection("emergencyContacts").add(contact(U.victor, { familyId: FAM1, profileId: "pLinked" })));
    });
    it("denies adding a contact to a family you are not in", async () => {
      await assertFails(as(env, U.mallory).collection("emergencyContacts").add(contact(U.mallory, { familyId: FAM1 })));
    });
    it("denies creating a contact owned by someone else", async () => {
      await assertFails(as(env, U.carol).collection("emergencyContacts").add(contact(U.ellie)));
    });
    it("denies an invalid phone number", async () => {
      await assertFails(as(env, U.oscar).collection("emergencyContacts").add(contact(U.oscar, { phoneNumber: "call me" })));
    });
    it("allows a caregiver to update a family contact", async () => {
      await assertSucceeds(as(env, U.carol).doc("emergencyContacts/ecFam").update({ phoneNumber: "+91 90000 00000" }));
    });
    it("denies a viewer updating a family contact", async () => {
      await assertFails(as(env, U.victor).doc("emergencyContacts/ecFam").update({ phoneNumber: "+91 90000 00000" }));
    });
    it("denies changing ownerId", async () => {
      await assertFails(as(env, U.ellie).doc("emergencyContacts/ecOwn").update({ ownerId: U.carol }));
    });
    it("denies moving a contact into a family the editor is not a member of", async () => {
      await assertFails(as(env, U.ellie).doc("emergencyContacts/ecOwn").update({ familyId: FAM2 }));
      await assertFails(as(env, U.carol).doc("emergencyContacts/ecFam").update({ familyId: FAM2 }));
    });
    it("allows the owner to attach their contact to a family they belong to", async () => {
      await assertSucceeds(as(env, U.ellie).doc("emergencyContacts/ecOwn").update({ familyId: FAM1, profileId: "pLinked" }));
    });
    it("allows the owner and the family admin to delete; denies a caregiver", async () => {
      await assertFails(as(env, U.carol).doc("emergencyContacts/ecFam").delete());
      await assertSucceeds(as(env, U.alice).doc("emergencyContacts/ecFam").delete());
      await assertSucceeds(as(env, U.ellie).doc("emergencyContacts/ecOwn").delete());
    });
  });
});
