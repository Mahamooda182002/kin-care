// Cloud Storage rules: profile photos and consented recordings.
import { assertFails, assertSucceeds, RulesTestEnvironment, RulesTestContext } from "@firebase/rules-unit-testing";
import { createEnv, ctx, seedWorld, U } from "./helpers";

const MB = 1024 * 1024;
const bytes = (n: number) => new Uint8Array(n);

/** Uploads and returns a real Promise (UploadTask is only thenable). */
function put(c: RulesTestContext, path: string, size: number, contentType: string): Promise<unknown> {
  return new Promise((resolve, reject) => {
    c.storage().ref(path).put(bytes(size), { contentType }).then(resolve, reject);
  });
}

describe("Cloud Storage", () => {
  let env: RulesTestEnvironment;
  before(async () => { env = await createEnv(true); });
  after(async () => { await env?.cleanup(); });
  beforeEach(async () => {
    await env.clearFirestore();
    await env.clearStorage();
    // Firestore world includes recordings/rec1 (owner ellie, consented, active).
    await seedWorld(env);
    await env.withSecurityRulesDisabled(async (c) => {
      await put(c, `profileImages/${U.alice}/avatar.jpg`, 1024, "image/jpeg");
      await put(c, `recordings/${U.ellie}/old.m4a`, 1024, "audio/mp4");
      await put(c, "misc/file.txt", 10, "text/plain");
      // Consent records for the upload tests.
      const db = c.firestore();
      const meta = (id: string, owner: string, extra: Record<string, unknown> = {}) =>
        db.doc(`recordings/${id}`).set({
          recordingId: id, userId: owner, storageReference: `recordings/${owner}/${id}.m4a`,
          consentReference: "in-app-consent:2026-11-05T10:00:00Z", transcriptionStatus: "uploaded", deletionStatus: "active", ...extra,
        });
      await meta("recCarol", U.carol);
      await meta("recDeleted", U.ellie, { deletionStatus: "deleted" });
      await meta("recNoConsent", U.ellie, { consentReference: "" });
      await meta("old", U.ellie);
    });
  });

  describe("profileImages/{uid}/{file}", () => {
    it("allows the owner to upload avatar.jpg (image/jpeg, < 5 MB)", async () => {
      await assertSucceeds(put(ctx(env, U.carol), `profileImages/${U.carol}/avatar.jpg`, 200 * 1024, "image/jpeg"));
    });
    it("allows the owner to upload avatar.png (image/png)", async () => {
      await assertSucceeds(put(ctx(env, U.carol), `profileImages/${U.carol}/avatar.png`, 1024, "image/png"));
    });
    it("denies uploading into another user's folder", async () => {
      await assertFails(put(ctx(env, U.carol), `profileImages/${U.alice}/avatar.jpg`, 1024, "image/jpeg"));
    });
    it("denies a file of 5 MB or more", async () => {
      await assertFails(put(ctx(env, U.carol), `profileImages/${U.carol}/avatar.jpg`, 5 * MB, "image/jpeg"));
    });
    for (const type of ["image/gif", "image/svg+xml", "text/html", "application/pdf"]) {
      it(`denies content type ${type}`, async () => {
        await assertFails(put(ctx(env, U.carol), `profileImages/${U.carol}/avatar.jpg`, 1024, type));
      });
    }
    it("denies any file name other than avatar.jpg / avatar.png", async () => {
      await assertFails(put(ctx(env, U.carol), `profileImages/${U.carol}/selfie.jpg`, 1024, "image/jpeg"));
      await assertFails(put(ctx(env, U.carol), `profileImages/${U.carol}/avatar.jpeg`, 1024, "image/jpeg"));
    });
    it("allows any signed-in user to read a profile photo (shown to family)", async () => {
      await assertSucceeds(ctx(env, U.carol).storage().ref(`profileImages/${U.alice}/avatar.jpg`).getMetadata());
    });
    it("denies unauthenticated reads", async () => {
      await assertFails(env.unauthenticatedContext().storage().ref(`profileImages/${U.alice}/avatar.jpg`).getMetadata());
    });
    it("allows the owner to delete; denies others", async () => {
      await assertFails(ctx(env, U.carol).storage().ref(`profileImages/${U.alice}/avatar.jpg`).delete());
      await assertSucceeds(ctx(env, U.alice).storage().ref(`profileImages/${U.alice}/avatar.jpg`).delete());
    });
  });

  describe("recordings/{uid}/{file}", () => {
    it("allows the owner to upload audio that matches a consented recording record", async () => {
      await assertSucceeds(put(ctx(env, U.carol), `recordings/${U.carol}/recCarol.m4a`, 100 * 1024, "audio/mp4"));
    });
    it("denies an upload with no recording/consent record", async () => {
      await assertFails(put(ctx(env, U.carol), `recordings/${U.carol}/recMissing.m4a`, 1024, "audio/mp4"));
    });
    it("denies an upload whose record belongs to another user", async () => {
      // rec1 is ellie's record; carol tries to use its id in her own folder.
      await assertFails(put(ctx(env, U.carol), `recordings/${U.carol}/rec1.m4a`, 1024, "audio/mp4"));
    });
    it("denies an upload whose record is marked deleted", async () => {
      await assertFails(put(ctx(env, U.ellie), `recordings/${U.ellie}/recDeleted.m4a`, 1024, "audio/mp4"));
    });
    it("denies an upload whose record has an empty consent reference", async () => {
      await assertFails(put(ctx(env, U.ellie), `recordings/${U.ellie}/recNoConsent.m4a`, 1024, "audio/mp4"));
    });
    it("denies uploading into another user's folder", async () => {
      await assertFails(put(ctx(env, U.ellie), `recordings/${U.carol}/recCarol.m4a`, 1024, "audio/mp4"));
    });
    it("denies a non-audio content type", async () => {
      await assertFails(put(ctx(env, U.carol), `recordings/${U.carol}/recCarol.m4a`, 1024, "video/mp4"));
    });
    it("denies a file of 25 MB or more", async () => {
      await assertFails(put(ctx(env, U.carol), `recordings/${U.carol}/recCarol.m4a`, 25 * MB, "audio/mp4"));
    });
    it("denies a wrong file name or extension", async () => {
      await assertFails(put(ctx(env, U.carol), `recordings/${U.carol}/recCarol.mp3`, 1024, "audio/mpeg"));
      await assertFails(put(ctx(env, U.carol), `recordings/${U.carol}/rec-Carol.m4a`, 1024, "audio/mp4"));
    });
    it("denies overwriting an existing recording", async () => {
      await assertFails(put(ctx(env, U.ellie), `recordings/${U.ellie}/old.m4a`, 1024, "audio/mp4"));
    });
    it("allows the owner to read; denies family members and others", async () => {
      await assertSucceeds(ctx(env, U.ellie).storage().ref(`recordings/${U.ellie}/old.m4a`).getMetadata());
      for (const uid of [U.alice, U.carol]) {
        await assertFails(ctx(env, uid).storage().ref(`recordings/${U.ellie}/old.m4a`).getMetadata());
      }
      await assertFails(env.unauthenticatedContext().storage().ref(`recordings/${U.ellie}/old.m4a`).getMetadata());
    });
    it("allows the owner to delete; denies others", async () => {
      await assertFails(ctx(env, U.alice).storage().ref(`recordings/${U.ellie}/old.m4a`).delete());
      await assertSucceeds(ctx(env, U.ellie).storage().ref(`recordings/${U.ellie}/old.m4a`).delete());
    });
  });

  describe("other paths", () => {
    it("denies reads and writes outside the two known folders", async () => {
      await assertFails(ctx(env, U.alice).storage().ref("misc/file.txt").getMetadata());
      await assertFails(put(ctx(env, U.alice), `uploads/${U.alice}/x.jpg`, 10, "image/jpeg"));
      await assertFails(put(ctx(env, U.alice), `${U.alice}/avatar.jpg`, 10, "image/jpeg"));
    });
    it("denies unauthenticated uploads anywhere", async () => {
      await assertFails(put(env.unauthenticatedContext(), `profileImages/${U.alice}/avatar.jpg`, 10, "image/jpeg"));
      await assertFails(put(env.unauthenticatedContext(), `recordings/${U.ellie}/rec1.m4a`, 10, "audio/mp4"));
    });
  });
});
