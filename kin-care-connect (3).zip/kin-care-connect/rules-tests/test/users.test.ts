import { assertFails, assertSucceeds, RulesTestEnvironment } from "@firebase/rules-unit-testing";
import { as, createEnv, deleteField, newUserDoc, omit, pastTime, seedWorld, serverTime, U } from "./helpers";

describe("users/{uid}", () => {
  let env: RulesTestEnvironment;
  before(async () => { env = await createEnv(); });
  after(async () => { await env?.cleanup(); });
  beforeEach(async () => { await env.clearFirestore(); await seedWorld(env); });

  const NEW = "newbie"; // has no user doc yet

  describe("create", () => {
    it("allows the owner to create a valid doc with the consent record", async () => {
      await assertSucceeds(as(env, NEW).doc(`users/${NEW}`).set(newUserDoc(NEW)));
    });

    it("allows the optional privacyChoices answer", async () => {
      const d = newUserDoc(NEW);
      (d.consents as Record<string, unknown>).privacyChoices = { version: 1, decidedAt: serverTime(), notifications: false, ai: false };
      await assertSucceeds(as(env, NEW).doc(`users/${NEW}`).set(d));
    });

    it("denies creating someone else's doc", async () => {
      await assertFails(as(env, U.oscar).doc(`users/${NEW}`).set(newUserDoc(NEW)));
    });

    it("denies a doc without the consents record", async () => {
      await assertFails(as(env, NEW).doc(`users/${NEW}`).set(omit(newUserDoc(NEW), "consents")));
    });

    it("denies a doc without the privacy record", async () => {
      await assertFails(as(env, NEW).doc(`users/${NEW}`).set(omit(newUserDoc(NEW), "privacy")));
    });

    const badConsents: Array<[string, (c: Record<string, unknown>) => void]> = [
      ["ageConfirmed false", (c) => { c.ageConfirmed = false; }],
      ["ageConfirmed missing", (c) => { delete c.ageConfirmed; }],
      ["minimumAge 16", (c) => { c.minimumAge = 16; }],
      ["termsVersion missing", (c) => { delete c.termsVersion; }],
      ["privacyVersion missing", (c) => { delete c.privacyVersion; }],
      ["back-dated acceptedAt", (c) => { c.acceptedAt = pastTime(); }],
      ["unknown consent key", (c) => { c.marketing = true; }],
      ["unknown privacyChoices key", (c) => { c.privacyChoices = { version: 1, tracking: true }; }],
    ];
    for (const [name, mutate] of badConsents) {
      it(`denies consents with ${name}`, async () => {
        const d = newUserDoc(NEW);
        mutate(d.consents as Record<string, unknown>);
        await assertFails(as(env, NEW).doc(`users/${NEW}`).set(d));
      });
    }

    it("denies privacy.updatedAt that is not the server time", async () => {
      const d = newUserDoc(NEW);
      (d.privacy as Record<string, unknown>).updatedAt = pastTime();
      await assertFails(as(env, NEW).doc(`users/${NEW}`).set(d));
    });

    it("denies non-boolean AI consent flags", async () => {
      const d = newUserDoc(NEW);
      (d.privacy as Record<string, unknown>).aiMedicalConsent = "yes";
      await assertFails(as(env, NEW).doc(`users/${NEW}`).set(d));
    });

    for (const field of ["phone", "dateOfBirth", "password", "isAdmin", "address"]) {
      it(`denies the unlisted field '${field}' (field whitelist)`, async () => {
        await assertFails(as(env, NEW).doc(`users/${NEW}`).set(newUserDoc(NEW, { [field]: "x" })));
      });
    }

    it("denies an email that differs from the auth token email", async () => {
      await assertFails(as(env, NEW).doc(`users/${NEW}`).set(newUserDoc(NEW, { email: "someone@else.com" })));
    });

    it("denies a uid field that differs from the doc id", async () => {
      await assertFails(as(env, NEW).doc(`users/${NEW}`).set(newUserDoc(NEW, { uid: U.alice })));
    });

    it("denies a self-assigned privileged role", async () => {
      await assertFails(as(env, NEW).doc(`users/${NEW}`).set(newUserDoc(NEW, { role: "admin" })));
    });

    it("denies an empty fullName", async () => {
      await assertFails(as(env, NEW).doc(`users/${NEW}`).set(newUserDoc(NEW, { fullName: "" })));
    });
  });

  describe("read", () => {
    it("allows the owner to read their doc", async () => {
      await assertSucceeds(as(env, U.alice).doc(`users/${U.alice}`).get());
    });
    it("denies reading another user's doc (even a fellow family member)", async () => {
      await assertFails(as(env, U.carol).doc(`users/${U.alice}`).get());
    });
    it("denies listing all users", async () => {
      await assertFails(as(env, U.alice).collection("users").get());
    });
  });

  describe("update", () => {
    it("allows the owner to change fullName", async () => {
      await assertSucceeds(as(env, U.alice).doc(`users/${U.alice}`).update({ fullName: "Alice New", updatedAt: serverTime() }));
    });
    it("allows switching between the elderly and caregiver labels", async () => {
      await assertSucceeds(as(env, U.alice).doc(`users/${U.alice}`).update({ role: "elderly" }));
    });
    it("denies another user updating the doc", async () => {
      await assertFails(as(env, U.carol).doc(`users/${U.alice}`).update({ fullName: "Hacked" }));
    });
    for (const [field, value] of [["uid", "x"], ["email", "x@example.com"], ["createdAt", pastTime()]] as const) {
      it(`denies changing the immutable field '${field}'`, async () => {
        await assertFails(as(env, U.alice).doc(`users/${U.alice}`).update({ [field]: value }));
      });
    }
    it("denies adding an unlisted field", async () => {
      await assertFails(as(env, U.alice).doc(`users/${U.alice}`).update({ isAdmin: true }));
    });
    it("denies adding a phone number", async () => {
      await assertFails(as(env, U.alice).doc(`users/${U.alice}`).update({ phone: "+911234567890" }));
    });
    it("allows removing a legacy phone number", async () => {
      await env.withSecurityRulesDisabled((c) => c.firestore().doc(`users/${U.alice}`).update({ phone: "+911234567890" }));
      await assertSucceeds(as(env, U.alice).doc(`users/${U.alice}`).update({ phone: deleteField() }));
    });
    it("denies changing a legacy phone number", async () => {
      await env.withSecurityRulesDisabled((c) => c.firestore().doc(`users/${U.alice}`).update({ phone: "+911234567890" }));
      await assertFails(as(env, U.alice).doc(`users/${U.alice}`).update({ phone: "+910000000000" }));
    });
    it("allows re-accepting new policy versions with the server time", async () => {
      await assertSucceeds(as(env, U.alice).doc(`users/${U.alice}`).update({
        consents: { termsVersion: "2027-01", privacyVersion: "2027-01", acceptedAt: serverTime(), ageConfirmed: true, minimumAge: 18 },
      }));
    });
    it("denies a back-dated consent re-acceptance", async () => {
      await assertFails(as(env, U.alice).doc(`users/${U.alice}`).update({
        consents: { termsVersion: "2027-01", privacyVersion: "2027-01", acceptedAt: pastTime(), ageConfirmed: true, minimumAge: 18 },
      }));
    });
    it("allows changing AI consent with the server time stamp", async () => {
      await assertSucceeds(as(env, U.alice).doc(`users/${U.alice}`).update({
        privacy: { aiMedicalConsent: true, aiScamConsent: false, policyVersion: "2026-11", updatedAt: serverTime() },
      }));
    });
    it("denies changing AI consent without the server time stamp", async () => {
      await assertFails(as(env, U.alice).doc(`users/${U.alice}`).update({
        privacy: { aiMedicalConsent: true, aiScamConsent: false, policyVersion: "2026-11", updatedAt: pastTime() },
      }));
    });
    it("denies a privileged role on update", async () => {
      await assertFails(as(env, U.alice).doc(`users/${U.alice}`).update({ role: "admin" }));
    });
  });

  describe("delete", () => {
    it("denies the owner deleting their doc (server-side deletion only)", async () => {
      await assertFails(as(env, U.alice).doc(`users/${U.alice}`).delete());
    });
  });

  describe("users/{uid}/devices", () => {
    it("allows the owner to read and write device tokens", async () => {
      await assertSucceeds(as(env, U.alice).doc(`users/${U.alice}/devices/d1`).get());
      await assertSucceeds(as(env, U.alice).doc(`users/${U.alice}/devices/d2`).set({ token: "t2", platform: "android" }));
      await assertSucceeds(as(env, U.alice).doc(`users/${U.alice}/devices/d1`).delete());
    });
    it("denies another user reading or writing device tokens", async () => {
      await assertFails(as(env, U.carol).doc(`users/${U.alice}/devices/d1`).get());
      await assertFails(as(env, U.carol).doc(`users/${U.alice}/devices/d9`).set({ token: "evil" }));
    });
  });
});
