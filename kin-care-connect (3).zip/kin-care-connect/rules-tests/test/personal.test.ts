// Owner-only data: recordings metadata, scam checks, notifications.
import { assertFails, assertSucceeds, RulesTestEnvironment } from "@firebase/rules-unit-testing";
import { as, createEnv, seedWorld, serverTime, U } from "./helpers";

describe("owner-only data", () => {
  let env: RulesTestEnvironment;
  before(async () => { env = await createEnv(); });
  after(async () => { await env?.cleanup(); });
  beforeEach(async () => { await env.clearFirestore(); await seedWorld(env); });

  // ---------------------------------------------------------------------
  describe("recordings (metadata)", () => {
    const rec = (uid: string, id: string, extra: Record<string, unknown> = {}) => ({
      recordingId: id, userId: uid, profileId: null, storageReference: `recordings/${uid}/${id}.m4a`,
      consentReference: "in-app-consent:2026-11-05T10:00:00Z", durationSeconds: 30,
      transcriptionStatus: "uploaded", deletionStatus: "active", createdAt: serverTime(), ...extra,
    });

    it("allows the owner to create metadata with a consent reference", async () => {
      await assertSucceeds(as(env, U.carol).doc("recordings/recNew").set(rec(U.carol, "recNew")));
    });
    it("denies metadata without a consent reference", async () => {
      const { consentReference: _c, ...r } = rec(U.carol, "recNew");
      await assertFails(as(env, U.carol).doc("recordings/recNew").set(r));
    });
    it("denies an empty consent reference", async () => {
      await assertFails(as(env, U.carol).doc("recordings/recNew").set(rec(U.carol, "recNew", { consentReference: "" })));
    });
    it("denies a storageReference that does not match the owner and doc id", async () => {
      await assertFails(as(env, U.carol).doc("recordings/recNew").set(rec(U.carol, "recNew", { storageReference: `recordings/${U.ellie}/recNew.m4a` })));
      await assertFails(as(env, U.carol).doc("recordings/recNew").set(rec(U.carol, "recNew", { storageReference: `recordings/${U.carol}/other.m4a` })));
    });
    it("denies creating metadata in someone else's name", async () => {
      await assertFails(as(env, U.carol).doc("recordings/recNew").set(rec(U.ellie, "recNew")));
    });
    it("denies a non-initial status on create", async () => {
      await assertFails(as(env, U.carol).doc("recordings/recNew").set(rec(U.carol, "recNew", { deletionStatus: "deleted" })));
      await assertFails(as(env, U.carol).doc("recordings/recNew").set(rec(U.carol, "recNew", { transcriptionStatus: "done" })));
    });
    it("allows the owner to read; denies family admin, caregiver and outsiders", async () => {
      await assertSucceeds(as(env, U.ellie).doc("recordings/rec1").get());
      for (const uid of [U.alice, U.carol, U.oscar]) {
        await assertFails(as(env, uid).doc("recordings/rec1").get());
      }
    });
    it("allows the owner to mark a recording deleted", async () => {
      await assertSucceeds(as(env, U.ellie).doc("recordings/rec1").update({ deletionStatus: "deleted", deletedAt: serverTime() }));
    });
    it("denies restoring, re-pointing or re-consenting a recording", async () => {
      await assertFails(as(env, U.ellie).doc("recordings/rec1").update({ deletionStatus: "active" }));
      await assertFails(as(env, U.ellie).doc("recordings/rec1").update({ deletionStatus: "deleted", storageReference: "recordings/x/y.m4a" }));
      await assertFails(as(env, U.ellie).doc("recordings/rec1").update({ deletionStatus: "deleted", consentReference: "changed" }));
    });
    it("denies another user updating or deleting", async () => {
      await assertFails(as(env, U.carol).doc("recordings/rec1").update({ deletionStatus: "deleted" }));
      await assertFails(as(env, U.carol).doc("recordings/rec1").delete());
    });
    it("allows the owner to delete", async () => {
      await assertSucceeds(as(env, U.ellie).doc("recordings/rec1").delete());
    });
  });

  // ---------------------------------------------------------------------
  describe("scamChecks (verdict only)", () => {
    const check = (uid: string, extra: Record<string, unknown> = {}) => ({
      userId: uid, inputType: "sms", riskLevel: "medium",
      indicators: [{ id: "link", title: "Contains a link" }], recommendations: ["Do not tap the link"],
      aiUsed: false, createdAt: serverTime(), ...extra,
    });

    it("allows saving a verdict with only the allowed outcome fields", async () => {
      await assertSucceeds(as(env, U.ellie).collection("scamChecks").add(check(U.ellie)));
    });
    for (const field of ["text", "message", "messageText", "body", "content", "input", "rawText", "url", "sender"]) {
      it(`denies a scam check containing '${field}'`, async () => {
        await assertFails(as(env, U.ellie).collection("scamChecks").add(check(U.ellie, { [field]: "Your parcel is held, pay Rs 25 at http://x.y" })));
      });
    }
    it("denies indicators smuggled in as a free-text string", async () => {
      await assertFails(as(env, U.ellie).collection("scamChecks").add(check(U.ellie, { indicators: "Your parcel is held, pay now" })));
    });
    it("denies a client claiming aiUsed=true (server-only)", async () => {
      await assertFails(as(env, U.ellie).collection("scamChecks").add(check(U.ellie, { aiUsed: true })));
    });
    it("denies an unknown risk level (e.g. 'safe')", async () => {
      await assertFails(as(env, U.ellie).collection("scamChecks").add(check(U.ellie, { riskLevel: "safe" })));
    });
    it("denies an unknown input type", async () => {
      await assertFails(as(env, U.ellie).collection("scamChecks").add(check(U.ellie, { inputType: "phone" })));
    });
    it("denies saving a check in someone else's name", async () => {
      await assertFails(as(env, U.carol).collection("scamChecks").add(check(U.ellie)));
    });
    it("allows the owner to read; denies others", async () => {
      await assertSucceeds(as(env, U.ellie).doc("scamChecks/scam1").get());
      await assertFails(as(env, U.alice).doc("scamChecks/scam1").get());
    });
    it("denies updating a check (even adding text later)", async () => {
      await assertFails(as(env, U.ellie).doc("scamChecks/scam1").update({ riskLevel: "low" }));
      await assertFails(as(env, U.ellie).doc("scamChecks/scam1").update({ text: "added later" }));
    });
    it("allows the owner to delete; denies others", async () => {
      await assertFails(as(env, U.carol).doc("scamChecks/scam1").delete());
      await assertSucceeds(as(env, U.ellie).doc("scamChecks/scam1").delete());
    });
  });

  // ---------------------------------------------------------------------
  describe("notifications (server-created)", () => {
    it("allows the owner to read; denies others", async () => {
      await assertSucceeds(as(env, U.ellie).doc("notifications/n1").get());
      await assertFails(as(env, U.alice).doc("notifications/n1").get());
    });
    it("denies a client creating a notification, even for themselves", async () => {
      await assertFails(as(env, U.ellie).collection("notifications").add({ userId: U.ellie, title: "Fake", readStatus: false }));
      await assertFails(as(env, U.alice).collection("notifications").add({ userId: U.ellie, title: "Phish", readStatus: false }));
    });
    it("allows the owner to mark as read", async () => {
      await assertSucceeds(as(env, U.ellie).doc("notifications/n1").update({ readStatus: true }));
    });
    it("denies changing anything but readStatus", async () => {
      await assertFails(as(env, U.ellie).doc("notifications/n1").update({ title: "Edited" }));
      await assertFails(as(env, U.ellie).doc("notifications/n1").update({ readStatus: true, userId: U.alice }));
    });
    it("denies another user marking it read or deleting it", async () => {
      await assertFails(as(env, U.alice).doc("notifications/n1").update({ readStatus: true }));
      await assertFails(as(env, U.alice).doc("notifications/n1").delete());
    });
    it("allows the owner to delete", async () => {
      await assertSucceeds(as(env, U.ellie).doc("notifications/n1").delete());
    });
  });
});
