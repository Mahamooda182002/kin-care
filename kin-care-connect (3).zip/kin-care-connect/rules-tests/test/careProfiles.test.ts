import { assertFails, assertSucceeds, RulesTestEnvironment } from "@firebase/rules-unit-testing";
import { as, createEnv, FAM1, FAM2, seedWorld, serverTime, U } from "./helpers";

describe("careProfiles", () => {
  let env: RulesTestEnvironment;
  before(async () => { env = await createEnv(); });
  after(async () => { await env?.cleanup(); });
  beforeEach(async () => { await env.clearFirestore(); await seedWorld(env); });

  const newProfile = (fid: string, by: string, extra: Record<string, unknown> = {}) => ({
    profileId: "pNew", familyId: fid, displayName: "Grandma", notes: null, createdBy: by,
    linkedUserId: null, caregiverIds: [], sharingConsent: { activity: false, medical: false, reminders: false },
    createdAt: serverTime(), ...extra,
  });
  const consent = (v: boolean, by: string) => ({
    sharingConsent: { activity: v, medical: v, reminders: v }, consentUpdatedBy: by, consentUpdatedAt: serverTime(),
  });

  describe("create (sharing off by default)", () => {
    it("allows the admin to create a profile with every sharing category off", async () => {
      await assertSucceeds(as(env, U.alice).doc("careProfiles/pNew").set(newProfile(FAM1, U.alice)));
    });
    for (const kind of ["activity", "medical", "reminders"]) {
      it(`denies creating a profile with '${kind}' sharing already on`, async () => {
        const p = newProfile(FAM1, U.alice);
        (p.sharingConsent as Record<string, boolean>)[kind] = true;
        await assertFails(as(env, U.alice).doc("careProfiles/pNew").set(p));
      });
    }
    it("denies creating a profile with no sharingConsent map", async () => {
      const { sharingConsent: _s, ...p } = newProfile(FAM1, U.alice);
      await assertFails(as(env, U.alice).doc("careProfiles/pNew").set(p));
    });
    it("denies creating a profile already linked to an elder account", async () => {
      await assertFails(as(env, U.alice).doc("careProfiles/pNew").set(newProfile(FAM1, U.alice, { linkedUserId: U.ellie })));
    });
    for (const uid of [U.carol, U.victor, U.ellie, U.oscar]) {
      it(`denies the non-admin '${uid}' creating a profile`, async () => {
        await assertFails(as(env, uid).doc("careProfiles/pNew").set(newProfile(FAM1, uid)));
      });
    }
    it("denies an admin creating a profile in another family", async () => {
      await assertFails(as(env, U.mallory).doc("careProfiles/pNew").set(newProfile(FAM1, U.mallory)));
    });
    it("denies createdBy naming someone else", async () => {
      await assertFails(as(env, U.alice).doc("careProfiles/pNew").set(newProfile(FAM1, U.carol)));
    });
  });

  describe("read", () => {
    for (const uid of [U.alice, U.carol, U.cara, U.victor, U.ellie]) {
      it(`allows the accepted member '${uid}' to read a profile`, async () => {
        await assertSucceeds(as(env, uid).doc("careProfiles/pLinked").get());
      });
    }
    it("allows the linked elder to read their profile even without membership", async () => {
      await env.withSecurityRulesDisabled((c) => c.firestore().doc(`familyMembers/${FAM1}_${U.ellie}`).delete());
      await assertSucceeds(as(env, U.ellie).doc("careProfiles/pLinked").get());
    });
    for (const uid of [U.dan, U.pete, U.oscar, U.mallory]) {
      it(`denies '${uid}' (declined / pending / outsider / other family)`, async () => {
        await assertFails(as(env, uid).doc("careProfiles/pLinked").get());
      });
    }
    it("denies a fam1 member reading a fam2 profile", async () => {
      await assertFails(as(env, U.alice).doc("careProfiles/pFam2").get());
    });
  });

  describe("update: details and caregiver assignment", () => {
    it("allows the admin to edit displayName, notes and caregiverIds", async () => {
      await assertSucceeds(as(env, U.alice).doc("careProfiles/pLinked").update({ displayName: "Nani", notes: "Diabetic", caregiverIds: [U.carol, U.cara] }));
    });
    for (const uid of [U.carol, U.victor, U.ellie]) {
      it(`denies '${uid}' editing profile details`, async () => {
        await assertFails(as(env, uid).doc("careProfiles/pLinked").update({ displayName: "Changed" }));
      });
    }
    it("denies a caregiver assigning themselves", async () => {
      await assertFails(as(env, U.cara).doc("careProfiles/pLinked").update({ caregiverIds: [U.carol, U.cara] }));
    });
    for (const [field, value] of [["familyId", FAM2], ["createdBy", U.carol], ["linkedUserId", U.victor]] as const) {
      it(`denies the admin changing '${field}'`, async () => {
        await assertFails(as(env, U.alice).doc("careProfiles/pUnlinked").update({ [field]: value }));
      });
    }
  });

  describe("update: consent", () => {
    it("allows the linked elder to turn sharing on and off", async () => {
      await assertSucceeds(as(env, U.ellie).doc("careProfiles/pNoConsent").update(consent(true, U.ellie)));
      await assertSucceeds(as(env, U.ellie).doc("careProfiles/pLinked").update(consent(false, U.ellie)));
    });
    it("denies the admin changing consent when an elder is linked", async () => {
      await assertFails(as(env, U.alice).doc("careProfiles/pNoConsent").update(consent(true, U.alice)));
    });
    it("allows the admin to change consent when no elder is linked", async () => {
      await assertSucceeds(as(env, U.alice).doc("careProfiles/pUnlinked").update(consent(true, U.alice)));
    });
    for (const uid of [U.carol, U.victor]) {
      it(`denies '${uid}' changing consent on an unlinked profile`, async () => {
        await assertFails(as(env, uid).doc("careProfiles/pUnlinked").update(consent(true, uid)));
      });
      it(`denies '${uid}' changing consent on a linked profile`, async () => {
        await assertFails(as(env, uid).doc("careProfiles/pNoConsent").update(consent(true, uid)));
      });
    }
    it("denies the elder recording someone else as consentUpdatedBy", async () => {
      await assertFails(as(env, U.ellie).doc("careProfiles/pNoConsent").update(consent(true, U.alice)));
    });
    it("denies the elder changing consent together with other fields", async () => {
      await assertFails(as(env, U.ellie).doc("careProfiles/pNoConsent").update({ ...consent(true, U.ellie), displayName: "Me" }));
    });
    it("denies the elder changing profile details", async () => {
      await assertFails(as(env, U.ellie).doc("careProfiles/pLinked").update({ displayName: "Me" }));
    });
    it("denies the admin of another family changing consent", async () => {
      await assertFails(as(env, U.mallory).doc("careProfiles/pUnlinked").update(consent(true, U.mallory)));
    });
  });

  describe("delete", () => {
    it("allows the admin to delete a profile", async () => {
      await assertSucceeds(as(env, U.alice).doc("careProfiles/pUnlinked").delete());
    });
    for (const uid of [U.carol, U.victor, U.ellie, U.mallory]) {
      it(`denies '${uid}' deleting a profile`, async () => {
        await assertFails(as(env, uid).doc("careProfiles/pUnlinked").delete());
      });
    }
  });
});
