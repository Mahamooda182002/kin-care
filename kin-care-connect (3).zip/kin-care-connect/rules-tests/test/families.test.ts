import { assertFails, assertSucceeds, RulesTestEnvironment } from "@firebase/rules-unit-testing";
import { as, createEnv, email, FAM1, FAM2, memberId, seedWorld, serverTime, U } from "./helpers";

describe("families, familyMembers, invitations", () => {
  let env: RulesTestEnvironment;
  before(async () => { env = await createEnv(); });
  after(async () => { await env?.cleanup(); });
  beforeEach(async () => { await env.clearFirestore(); await seedWorld(env); });

  const adminMembership = (fid: string, uid: string) => ({
    membershipId: memberId(fid, uid), familyId: fid, userId: uid, role: "admin",
    permissions: { manageFamily: true, editCare: true }, invitationStatus: "accepted",
    displayName: `User ${uid}`, email: email(uid), createdAt: serverTime(),
  });

  describe("families: create", () => {
    it("allows creating a family together with the creator's admin membership (one batch)", async () => {
      const db = as(env, U.oscar);
      const b = db.batch();
      b.set(db.doc("families/famNew"), { familyId: "famNew", familyName: "New", createdBy: U.oscar, createdAt: serverTime() });
      b.set(db.doc(`familyMembers/${memberId("famNew", U.oscar)}`), adminMembership("famNew", U.oscar));
      await assertSucceeds(b.commit());
    });
    it("denies creating a family without the admin membership", async () => {
      await assertFails(as(env, U.oscar).doc("families/famNew").set({ familyId: "famNew", familyName: "New", createdBy: U.oscar }));
    });
    it("denies creating a family on behalf of someone else", async () => {
      const db = as(env, U.oscar);
      const b = db.batch();
      b.set(db.doc("families/famNew"), { familyId: "famNew", familyName: "New", createdBy: U.alice });
      b.set(db.doc(`familyMembers/${memberId("famNew", U.oscar)}`), adminMembership("famNew", U.oscar));
      await assertFails(b.commit());
    });
    it("denies an empty family name", async () => {
      const db = as(env, U.oscar);
      const b = db.batch();
      b.set(db.doc("families/famNew"), { familyId: "famNew", familyName: "", createdBy: U.oscar });
      b.set(db.doc(`familyMembers/${memberId("famNew", U.oscar)}`), adminMembership("famNew", U.oscar));
      await assertFails(b.commit());
    });
  });

  describe("families: read by role", () => {
    for (const uid of [U.alice, U.carol, U.victor, U.ellie]) {
      it(`allows the accepted member '${uid}' to read the family`, async () => {
        await assertSucceeds(as(env, uid).doc(`families/${FAM1}`).get());
      });
    }
    it("denies a declined member", async () => {
      await assertFails(as(env, U.dan).doc(`families/${FAM1}`).get());
    });
    it("denies a pending (not yet accepted) invitee", async () => {
      await assertFails(as(env, U.pete).doc(`families/${FAM1}`).get());
    });
    it("denies a non-member", async () => {
      await assertFails(as(env, U.oscar).doc(`families/${FAM1}`).get());
    });
    it("denies cross-family access (admin of fam2 reading fam1)", async () => {
      await assertFails(as(env, U.mallory).doc(`families/${FAM1}`).get());
    });
    it("denies a removed member after the admin deletes their membership", async () => {
      await assertSucceeds(as(env, U.alice).doc(`familyMembers/${memberId(FAM1, U.carol)}`).delete());
      await assertFails(as(env, U.carol).doc(`families/${FAM1}`).get());
      await assertFails(as(env, U.carol).doc("careProfiles/pLinked").get());
    });
  });

  describe("families: update / delete", () => {
    it("allows the admin to rename the family", async () => {
      await assertSucceeds(as(env, U.alice).doc(`families/${FAM1}`).update({ familyName: "Renamed" }));
    });
    for (const uid of [U.carol, U.victor, U.ellie]) {
      it(`denies the non-admin '${uid}' renaming the family`, async () => {
        await assertFails(as(env, uid).doc(`families/${FAM1}`).update({ familyName: "Renamed" }));
      });
    }
    it("denies the admin changing createdBy", async () => {
      await assertFails(as(env, U.alice).doc(`families/${FAM1}`).update({ createdBy: U.carol }));
    });
    it("denies the admin of another family renaming it", async () => {
      await assertFails(as(env, U.mallory).doc(`families/${FAM1}`).update({ familyName: "Mine" }));
    });
    it("denies deleting a family even as admin", async () => {
      await assertFails(as(env, U.alice).doc(`families/${FAM1}`).delete());
    });
  });

  describe("familyMembers: create", () => {
    it("denies joining an existing family as admin", async () => {
      await assertFails(as(env, U.oscar).doc(`familyMembers/${memberId(FAM1, U.oscar)}`).set(adminMembership(FAM1, U.oscar)));
    });
    it("denies self-adding as caregiver to an existing family", async () => {
      await assertFails(as(env, U.oscar).doc(`familyMembers/${memberId(FAM1, U.oscar)}`).set({ ...adminMembership(FAM1, U.oscar), role: "caregiver" }));
    });
    it("denies a membership for a family that is not created in the same batch", async () => {
      await assertFails(as(env, U.oscar).doc(`familyMembers/${memberId("ghost", U.oscar)}`).set(adminMembership("ghost", U.oscar)));
    });
    it("denies an admin adding someone else directly (must go through invitations)", async () => {
      await assertFails(as(env, U.alice).doc(`familyMembers/${memberId(FAM1, U.oscar)}`).set({ ...adminMembership(FAM1, U.oscar), role: "viewer" }));
    });
    it("denies a pending invitee accepting their own invitation client-side", async () => {
      await assertFails(as(env, U.pete).doc(`familyMembers/${memberId(FAM1, U.pete)}`).update({ invitationStatus: "accepted" }));
    });
  });

  describe("familyMembers: read", () => {
    it("allows an accepted member to read another member's membership", async () => {
      await assertSucceeds(as(env, U.victor).doc(`familyMembers/${memberId(FAM1, U.alice)}`).get());
    });
    it("allows a pending invitee to read their own membership", async () => {
      await assertSucceeds(as(env, U.pete).doc(`familyMembers/${memberId(FAM1, U.pete)}`).get());
    });
    it("denies a pending invitee reading other memberships", async () => {
      await assertFails(as(env, U.pete).doc(`familyMembers/${memberId(FAM1, U.alice)}`).get());
    });
    it("denies a declined member reading other memberships", async () => {
      await assertFails(as(env, U.dan).doc(`familyMembers/${memberId(FAM1, U.alice)}`).get());
    });
    it("denies cross-family membership reads", async () => {
      await assertFails(as(env, U.mallory).doc(`familyMembers/${memberId(FAM1, U.alice)}`).get());
      await assertFails(as(env, U.alice).doc(`familyMembers/${memberId(FAM2, U.mallory)}`).get());
    });
    it("allows a member to list their family's memberships", async () => {
      await assertSucceeds(as(env, U.carol).collection("familyMembers").where("familyId", "==", FAM1).get());
    });
    it("denies an outsider listing a family's memberships", async () => {
      await assertFails(as(env, U.oscar).collection("familyMembers").where("familyId", "==", FAM1).get());
    });
  });

  describe("familyMembers: update (roles)", () => {
    it("allows the admin to change another member's role and permissions", async () => {
      await assertSucceeds(as(env, U.alice).doc(`familyMembers/${memberId(FAM1, U.victor)}`).update({ role: "caregiver", permissions: { manageFamily: false, editCare: true } }));
    });
    it("denies the admin changing their own role", async () => {
      await assertFails(as(env, U.alice).doc(`familyMembers/${memberId(FAM1, U.alice)}`).update({ role: "viewer" }));
    });
    it("denies an unknown role", async () => {
      await assertFails(as(env, U.alice).doc(`familyMembers/${memberId(FAM1, U.victor)}`).update({ role: "owner" }));
    });
    it("denies the admin changing invitationStatus", async () => {
      await assertFails(as(env, U.alice).doc(`familyMembers/${memberId(FAM1, U.pete)}`).update({ invitationStatus: "accepted" }));
    });
    for (const uid of [U.carol, U.victor, U.ellie]) {
      it(`denies the non-admin '${uid}' promoting themselves to admin`, async () => {
        await assertFails(as(env, uid).doc(`familyMembers/${memberId(FAM1, uid)}`).update({ role: "admin" }));
      });
    }
    it("denies a caregiver changing another member's role", async () => {
      await assertFails(as(env, U.carol).doc(`familyMembers/${memberId(FAM1, U.victor)}`).update({ role: "caregiver" }));
    });
    it("denies the admin of another family changing roles", async () => {
      await assertFails(as(env, U.mallory).doc(`familyMembers/${memberId(FAM1, U.victor)}`).update({ role: "admin" }));
    });
  });

  describe("familyMembers: delete", () => {
    it("allows the admin to remove a member", async () => {
      await assertSucceeds(as(env, U.alice).doc(`familyMembers/${memberId(FAM1, U.victor)}`).delete());
    });
    it("allows a member to leave", async () => {
      await assertSucceeds(as(env, U.victor).doc(`familyMembers/${memberId(FAM1, U.victor)}`).delete());
    });
    it("denies a caregiver removing another member", async () => {
      await assertFails(as(env, U.carol).doc(`familyMembers/${memberId(FAM1, U.victor)}`).delete());
    });
    it("denies a viewer removing another member", async () => {
      await assertFails(as(env, U.victor).doc(`familyMembers/${memberId(FAM1, U.carol)}`).delete());
    });
  });

  describe("invitations (server-managed)", () => {
    it("allows the invitee (matching token email) to read the invitation", async () => {
      await assertSucceeds(as(env, U.pete).doc("invitations/inv1").get());
    });
    it("allows a family admin to read the invitation", async () => {
      await assertSucceeds(as(env, U.alice).doc("invitations/inv1").get());
    });
    for (const uid of [U.carol, U.victor, U.oscar, U.mallory]) {
      it(`denies '${uid}' reading the invitation`, async () => {
        await assertFails(as(env, uid).doc("invitations/inv1").get());
      });
    }
    it("denies an admin creating an invitation client-side", async () => {
      await assertFails(as(env, U.alice).doc("invitations/inv2").set({ familyId: FAM1, inviteeEmail: email(U.oscar), role: "admin", status: "pending" }));
    });
    it("denies the invitee accepting by editing the invitation", async () => {
      await assertFails(as(env, U.pete).doc("invitations/inv1").update({ status: "accepted" }));
    });
    it("denies the admin deleting an invitation client-side", async () => {
      await assertFails(as(env, U.alice).doc("invitations/inv1").delete());
    });
  });
});
