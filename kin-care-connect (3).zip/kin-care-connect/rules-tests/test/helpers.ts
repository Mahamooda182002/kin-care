// Shared set-up for the Kin Care Connect security-rules tests.
//
// Every test starts from the same seeded "world" (see seedWorld), written
// with security rules disabled. Tests then act as one of the users below and
// assert that the rules allow (assertSucceeds) or deny (assertFails).
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import {
  initializeTestEnvironment,
  RulesTestEnvironment,
  RulesTestContext,
} from "@firebase/rules-unit-testing";
import firebase from "firebase/compat/app";
import "firebase/compat/firestore";

export const PROJECT_ID = "demo-kin-care-connect";

// Compiled tests live in rules-tests/lib, the rules in the repo root.
const repoRoot = resolve(__dirname, "..", "..");

export async function createEnv(withStorage = false): Promise<RulesTestEnvironment> {
  return initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: { rules: readFileSync(resolve(repoRoot, "firestore.rules"), "utf8") },
    ...(withStorage
      ? { storage: { rules: readFileSync(resolve(repoRoot, "storage.rules"), "utf8") } }
      : {}),
  });
}

export type Db = firebase.firestore.Firestore;

export const serverTime = () => firebase.firestore.FieldValue.serverTimestamp();
export const deleteField = () => firebase.firestore.FieldValue.delete();
export const pastTime = () => firebase.firestore.Timestamp.fromDate(new Date("2020-01-01T00:00:00Z"));

// ---------- cast ----------
// fam1: alice (admin), carol (caregiver, assigned to pLinked/pNoConsent/pUnlinked),
//       cara (caregiver, assigned to nothing), victor (viewer), ellie (elderly,
//       linked to pLinked), dan (declined), pete (pending invite).
// fam2: mallory (admin). outsider: oscar (member of nothing).
export const U = {
  alice: "alice",
  carol: "carol",
  cara: "cara",
  victor: "victor",
  ellie: "ellie",
  dan: "dan",
  pete: "pete",
  mallory: "mallory",
  oscar: "oscar",
} as const;

export const email = (uid: string) => `${uid}@example.com`;

export const FAM1 = "fam1";
export const FAM2 = "fam2";
export const memberId = (fid: string, uid: string) => `${fid}_${uid}`;

/** Firestore client acting as a signed-in user (with a verified-looking email). */
export function as(env: RulesTestEnvironment, uid: string): Db {
  return env.authenticatedContext(uid, { email: email(uid), email_verified: true }).firestore() as unknown as Db;
}
export function anon(env: RulesTestEnvironment): Db {
  return env.unauthenticatedContext().firestore() as unknown as Db;
}
export function ctx(env: RulesTestEnvironment, uid: string): RulesTestContext {
  return env.authenticatedContext(uid, { email: email(uid), email_verified: true });
}

/** Removes keys from a plain object (Firestore rejects `undefined`). */
export function omit<T extends Record<string, unknown>>(o: T, ...keys: string[]): Record<string, unknown> {
  const c: Record<string, unknown> = { ...o };
  for (const k of keys) delete c[k];
  return c;
}

/** A user document exactly as the app's registration writes it. */
export function newUserDoc(uid: string, extra: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    uid,
    fullName: `User ${uid}`,
    email: email(uid),
    role: "caregiver",
    profileImage: null,
    accessibilitySettings: { largeText: false, highContrast: false },
    notificationPrefs: {
      reminders: false,
      familyInvitations: false,
      activityUpdates: false,
      reminderCompletion: false,
      securityEvents: false,
      showDetailsOnLockScreen: false,
    },
    privacy: {
      aiMedicalConsent: false,
      aiScamConsent: false,
      recordingConsentAcknowledged: false,
      policyVersion: "2026-11",
      updatedAt: serverTime(),
    },
    consents: {
      termsVersion: "2026-11",
      privacyVersion: "2026-11",
      acceptedAt: serverTime(),
      ageConfirmed: true,
      minimumAge: 18,
    },
    createdAt: serverTime(),
    updatedAt: serverTime(),
    ...extra,
  };
}

const consentAll = (v: boolean) => ({ activity: v, medical: v, reminders: v });

/** Seeds the shared world with rules disabled. */
export async function seedWorld(env: RulesTestEnvironment): Promise<void> {
  await env.withSecurityRulesDisabled(async (c) => {
    const db = c.firestore() as unknown as Db;
    const set = (path: string, data: Record<string, unknown>) => db.doc(path).set(data);
    const t = firebase.firestore.Timestamp.now();

    // Users (stored docs; creation is tested separately).
    for (const uid of Object.values(U)) {
      await set(`users/${uid}`, {
        uid, fullName: `User ${uid}`, email: email(uid), role: "caregiver", profileImage: null,
        privacy: { aiMedicalConsent: false, aiScamConsent: false, policyVersion: "2026-11", updatedAt: t },
        consents: { termsVersion: "2026-11", privacyVersion: "2026-11", acceptedAt: t, ageConfirmed: true, minimumAge: 18 },
        createdAt: t, updatedAt: t,
      });
    }
    await set(`users/${U.alice}/devices/d1`, { token: "tok", platform: "android", updatedAt: t });

    // Families and memberships.
    await set(`families/${FAM1}`, { familyId: FAM1, familyName: "Family One", createdBy: U.alice, createdAt: t });
    await set(`families/${FAM2}`, { familyId: FAM2, familyName: "Family Two", createdBy: U.mallory, createdAt: t });
    const mem = (fid: string, uid: string, role: string, status = "accepted") =>
      set(`familyMembers/${memberId(fid, uid)}`, {
        membershipId: memberId(fid, uid), familyId: fid, userId: uid, role,
        permissions: { manageFamily: role === "admin", editCare: role === "admin" || role === "caregiver" },
        invitationStatus: status, displayName: `User ${uid}`, email: email(uid), createdAt: t,
      });
    await mem(FAM1, U.alice, "admin");
    await mem(FAM1, U.carol, "caregiver");
    await mem(FAM1, U.cara, "caregiver");
    await mem(FAM1, U.victor, "viewer");
    await mem(FAM1, U.ellie, "elderly");
    await mem(FAM1, U.dan, "caregiver", "declined");
    await mem(FAM1, U.pete, "caregiver", "pending");
    await mem(FAM2, U.mallory, "admin");

    // Invitations (server-managed).
    await set("invitations/inv1", {
      familyId: FAM1, inviteeEmail: email(U.pete), invitedBy: U.alice, invitedByName: "User alice",
      familyName: "Family One", role: "caregiver", status: "pending", expiresAt: t,
    });

    // Care profiles.
    const prof = (id: string, fid: string, linked: string | null, caregivers: string[], consent: boolean) =>
      set(`careProfiles/${id}`, {
        profileId: id, familyId: fid, displayName: `Profile ${id}`, notes: null, createdBy: fid === FAM1 ? U.alice : U.mallory,
        linkedUserId: linked, caregiverIds: caregivers, sharingConsent: consentAll(consent), createdAt: t,
      });
    await prof("pLinked", FAM1, U.ellie, [U.carol], true); // ellie linked, everything shared
    await prof("pNoConsent", FAM1, U.ellie, [U.carol], false); // ellie linked, nothing shared
    await prof("pUnlinked", FAM1, null, [U.carol], false); // no elder linked: admin controls consent
    await prof("pFam2", FAM2, null, [], true);

    // Activity records.
    await set("activityRecords/actShared", { userId: U.ellie, profileId: "pLinked", familyId: FAM1, activityType: "checkIn", source: "app_foreground", timestamp: t });
    await set("activityRecords/actNoConsent", { userId: U.ellie, profileId: "pNoConsent", familyId: FAM1, activityType: "checkIn", source: "app_foreground", timestamp: t });
    await set("activityRecords/actSelf", { userId: U.ellie, profileId: null, familyId: null, activityType: "appOpened", source: "app_foreground", timestamp: t });

    // Medical summaries.
    const med = (id: string, owner: string, profileId: string | null, shared: boolean) =>
      set(`medicalSummaries/${id}`, {
        summaryId: id, userId: owner, title: "Visit", profileId, familyId: profileId ? FAM1 : null,
        sharedWithFamily: shared, originalText: "orig", summaryText: "sum", language: "en", retentionStatus: "keep", createdAt: t, updatedAt: t,
      });
    await med("medShared", U.alice, "pLinked", true);
    await med("medNotShared", U.alice, "pLinked", false);
    await med("medNoConsent", U.alice, "pNoConsent", true);
    await med("medPrivate", U.ellie, null, false);

    // Recordings metadata.
    await set("recordings/rec1", {
      recordingId: "rec1", userId: U.ellie, profileId: null, storageReference: `recordings/${U.ellie}/rec1.m4a`,
      consentReference: "in-app-consent:2026-11-05T10:00:00Z", durationSeconds: 60, transcriptionStatus: "uploaded", deletionStatus: "active", createdAt: t,
    });

    // Scam checks.
    await set("scamChecks/scam1", { userId: U.ellie, inputType: "sms", riskLevel: "high", indicators: [{ id: "urgent", title: "Urgency" }], recommendations: ["Do not reply"], aiUsed: false, createdAt: t });

    // Reminders.
    const rem = (id: string, owner: string, profileId: string | null) =>
      set(`reminders/${id}`, {
        reminderId: id, userId: owner, profileId, familyId: profileId ? FAM1 : null, title: "Take tablets", reminderType: "medication",
        completionStatus: "pending", notified: false, nextDueAt: t, createdAt: t, updatedAt: t,
      });
    await rem("remOwn", U.carol, null);
    await rem("remShared", U.alice, "pLinked");
    await rem("remNoConsent", U.alice, "pNoConsent");
    await set("reminders/remShared/history/h1", { action: "completed", by: U.ellie, at: t });

    // Notifications (server-created).
    await set("notifications/n1", { userId: U.ellie, type: "reminder", title: "Reminder", message: "Take tablets", link: "/reminders", readStatus: false, createdAt: t });

    // Emergency contacts.
    const ec = (id: string, owner: string, familyId: string | null, profileId: string | null) =>
      set(`emergencyContacts/${id}`, {
        contactId: id, ownerId: owner, contactName: "Dr Rao", relationship: "Doctor", phoneNumber: "+91 98765 43210",
        isPrimary: true, profileId, familyId, createdAt: t, updatedAt: t,
      });
    await ec("ecOwn", U.ellie, null, null);
    await ec("ecFam", U.ellie, FAM1, "pLinked");

    // Server-only.
    await set(`rateLimits/${U.ellie}_scamAnalyze`, { windowStart: t, count: 1, expiresAt: t });
    await set("auditLog/a1", { event: "x", at: t });
  });
}
