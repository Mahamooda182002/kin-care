// Server-only collections, unknown paths, and unauthenticated access.
import { assertFails, assertSucceeds, RulesTestEnvironment } from "@firebase/rules-unit-testing";
import { anon, as, createEnv, FAM1, memberId, seedWorld, U } from "./helpers";

describe("server-only and unauthenticated access", () => {
  let env: RulesTestEnvironment;
  before(async () => { env = await createEnv(); });
  after(async () => { await env?.cleanup(); });
  beforeEach(async () => { await env.clearFirestore(); await seedWorld(env); });

  describe("rateLimits", () => {
    const id = `${U.ellie}_scamAnalyze`;
    it("denies the owner reading their own rate-limit counter", async () => {
      await assertFails(as(env, U.ellie).doc(`rateLimits/${id}`).get());
    });
    it("denies the owner resetting their counter", async () => {
      await assertFails(as(env, U.ellie).doc(`rateLimits/${id}`).set({ count: 0 }));
      await assertFails(as(env, U.ellie).doc(`rateLimits/${id}`).delete());
    });
    it("denies creating a counter", async () => {
      await assertFails(as(env, U.carol).doc(`rateLimits/${U.carol}_medicalExplain`).set({ count: 0 }));
    });
  });

  describe("auditLog", () => {
    it("denies reading and writing", async () => {
      await assertFails(as(env, U.alice).doc("auditLog/a1").get());
      await assertFails(as(env, U.alice).collection("auditLog").add({ event: "fake" }));
    });
  });

  describe("unknown collections", () => {
    it("denies reading and writing a collection not in the rules", async () => {
      await assertFails(as(env, U.alice).doc("admin/config").get());
      await assertFails(as(env, U.alice).doc("admin/config").set({ x: 1 }));
      await assertFails(as(env, U.alice).doc(`users/${U.alice}/secrets/s1`).set({ x: 1 }));
    });
  });

  describe("unauthenticated users are denied everywhere", () => {
    const docs = [
      `users/${U.alice}`, `users/${U.alice}/devices/d1`, `families/${FAM1}`, `familyMembers/${memberId(FAM1, U.alice)}`,
      "invitations/inv1", "careProfiles/pLinked", "activityRecords/actShared", "medicalSummaries/medShared",
      "recordings/rec1", "scamChecks/scam1", "reminders/remShared", "reminders/remShared/history/h1",
      "notifications/n1", "emergencyContacts/ecFam", `rateLimits/${U.ellie}_scamAnalyze`, "auditLog/a1",
    ];
    for (const path of docs) {
      it(`denies read and write of ${path}`, async () => {
        const db = anon(env);
        await assertFails(db.doc(path).get());
        await assertFails(db.doc(path).set({ userId: "x", ownerId: "x" }));
        await assertFails(db.doc(path).delete());
      });
    }
    it("denies unauthenticated collection queries", async () => {
      await assertFails(anon(env).collection("careProfiles").where("familyId", "==", FAM1).get());
    });
  });

  it("sanity: the seeded data is readable by its owner (the denials above are real)", async () => {
    await assertSucceeds(as(env, U.alice).doc(`users/${U.alice}`).get());
  });
});
