/**
 * Server copy of the on-device warning-sign engine
 * (lib/features/scam/domain/scam_rules.dart). Keep both in sync.
 * Pure TypeScript — no network, links are never opened.
 */
export type RiskLevel = "low" | "medium" | "high";

export interface Indicator {
  id: string;
  title: string;
  explanation: string;
  weight: number;
  matches: string[];
}

export interface ScamResult {
  riskLevel: RiskLevel;
  score: number;
  indicators: Indicator[];
  suspiciousPhrases: string[];
  urls: string[];
  explanation: string;
  recommendedAction: string;
  verificationAdvice: string[];
}

interface Rule { id: string; title: string; explanation: string; weight: number; patterns: RegExp[] }

const r = (p: string) => new RegExp(p, "gi");

const RULES: Rule[] = [
  { id: "credentials", title: "Asks for OTP, PIN or password", weight: 40,
    explanation: "Banks, government offices and real companies never ask you to share a one-time code, PIN or password.",
    patterns: [r("\\b(otp|one[\\s-]?time\\s?(pass(word|code)?|code)|verification code|security code)\\b"), r("\\b(pin|cvv|cvc|upi pin|atm pin)\\b"), r("\\b(password|passcode|login details|net ?banking)\\b"), r("\\bshare (the|your) code\\b")] },
  { id: "urgency", title: "Creates urgency or pressure", weight: 15,
    explanation: "Scammers rush you so you act before thinking or checking with someone.",
    patterns: [r("\\b(urgent(ly)?|immediately|right away|asap|act now|final (notice|warning)|last chance)\\b"), r("\\bwithin \\d+\\s?(minutes?|mins?|hours?|hrs?)\\b"), r("\\b(today only|expires? (today|soon|in))\\b")] },
  { id: "threat", title: "Threatens penalties, arrest or account closure", weight: 20,
    explanation: "Threats of arrest, fines, legal action or blocked accounts are a common pressure tactic.",
    patterns: [r("\\b(arrest(ed)?|police|warrant|legal action|court|lawsuit|jail)\\b"), r("\\b(account|card|sim|number|kyc)\\b.{0,30}\\b(block(ed)?|suspend(ed)?|deactivat(ed|e)|clos(ed|e)|frozen)\\b"), r("\\b(penalty|fine) of\\b")] },
  { id: "payment", title: "Requests money or unusual payment", weight: 25,
    explanation: "Requests to pay by gift card, crypto, wire transfer or a payment link are strong warning signs.",
    patterns: [r("\\b(gift ?cards?|google play cards?|itunes cards?|steam cards?|amazon pay voucher)\\b"), r("\\b(send|share|scratch)\\b.{0,15}\\bcodes?\\b"), r("\\b(bitcoin|crypto(currency)?|usdt|wallet address)\\b"), r("\\b(wire|bank) transfer\\b|\\bwestern union\\b|\\bmoneygram\\b"), r("\\b(pay|send|transfer)\\b.{0,25}(\\$|₹|rs\\.?|inr|usd|£|€)\\s?\\d"), r("\\b(processing|registration|release|customs|delivery) fee\\b"), r("\\b(scan (the|this) qr|collect request|approve the request)\\b")] },
  { id: "prize", title: "Too-good-to-be-true offer", weight: 15,
    explanation: "Unexpected prizes, lotteries, refunds or job offers are often used to lure people in.",
    patterns: [r("\\b(you (have )?won|winner|lottery|jackpot|lucky draw|prize|reward points)\\b"), r("\\b(cash ?back|refund) (of|is) (pending|approved)\\b"), r("\\b(work from home|earn \\d+|part[\\s-]?time job)\\b")] },
  { id: "impersonation", title: "Claims to be a bank, government or family member", weight: 15,
    explanation: 'Scammers pretend to be trusted organisations or relatives (for example "Hi Mum, new number").',
    patterns: [r("\\b(bank|income tax|irs|hmrc|customs|courier|fedex|dhl|amazon|microsoft|apple support|tech support)\\b"), r("\\b(hi|hello) (mum|mom|dad|grandma|grandpa)\\b|\\bnew number\\b|\\bi lost my phone\\b")] },
  { id: "secrecy", title: "Asks you to keep it secret", weight: 20,
    explanation: "Being told not to tell family or the bank is a classic sign of a scam.",
    patterns: [r("\\b(don'?t|do not) (tell|inform|share with) (anyone|your family|the bank|dad|mum|mom|your (son|daughter|husband|wife))\\b"), r("\\bkeep (this|it) (confidential|secret|between us)\\b")] },
  { id: "remote_access", title: "Asks you to install an app or give remote access", weight: 30,
    explanation: "Screen-sharing or remote-control apps let scammers see and control your phone.",
    patterns: [r("\\b(anydesk|teamviewer|quick ?support|rustdesk|screen ?shar(e|ing)|remote access)\\b"), r("\\b(download|install) (this|the) (app|apk)\\b|\\.apk\\b")] },
];

const URL_RE = /((https?:\/\/)?(www\.)?[a-z0-9-]+(\.[a-z0-9-]+)*\.(com|net|org|in|co|info|xyz|top|link|click|ly|io|me|app|site|online|shop|ru|cn|tk|ml|ga|cf|gq|live|biz)(\/[^\s<>"']*)?)/gi;
const RISKY_URL = [/\b(bit\.ly|tinyurl|t\.co|goo\.gl|cutt\.ly|is\.gd|rb\.gy|shorturl)\b/i, /\.(xyz|top|click|tk|ml|ga|cf|gq|zip|mov)\b/i, /https?:\/\/\d{1,3}(\.\d{1,3}){3}/, /(paypa1|amaz0n|g00gle|faceb00k|micr0soft|app1e|sbi-|hdfc-|icici-|kyc-?update|secure-?login|verify-?account)/i, /xn--/i];

export const SCAM_DISCLAIMER =
  "This check is advisory only. It can miss scams or flag genuine messages, and it cannot guarantee a message is safe.";

export function extractUrls(text: string): string[] {
  return [...new Set([...text.matchAll(URL_RE)].map((m) => m[0]))];
}

export function analyzeRules(input: string): ScamResult {
  const text = input.trim();
  const indicators: Indicator[] = [];
  const phrases = new Set<string>();
  let score = 0;

  for (const rule of RULES) {
    const matches = new Set<string>();
    for (const p of rule.patterns) for (const m of text.matchAll(p)) matches.add(m[0].trim());
    if (matches.size) {
      const list = [...matches].slice(0, 5);
      indicators.push({ id: rule.id, title: rule.title, explanation: rule.explanation, weight: rule.weight, matches: list });
      list.forEach((x) => phrases.add(x));
      score += rule.weight;
    }
  }

  const urls = extractUrls(text);
  if (urls.length) {
    const risky = urls.filter((u) => RISKY_URL.some((re) => re.test(u)));
    if (risky.length) {
      indicators.push({ id: "risky_link", title: "Contains a suspicious-looking link", weight: 25, matches: risky.slice(0, 5),
        explanation: "Shortened links, unusual endings or look-alike names can hide fake websites. The link was not opened." });
      risky.slice(0, 5).forEach((x) => phrases.add(x));
      score += 25;
    } else {
      indicators.push({ id: "link", title: "Contains a link", weight: 10, matches: urls.slice(0, 5),
        explanation: "Links in unexpected messages can lead to fake websites. Type the official address yourself instead of tapping it. The link was not opened." });
      score += 10;
    }
  }

  const ids = new Set(indicators.map((i) => i.id));
  if ((ids.has("credentials") || ids.has("payment")) && (ids.has("urgency") || ids.has("threat"))) score += 15;

  const riskLevel: RiskLevel = score >= 50 ? "high" : score >= 20 ? "medium" : "low";
  return {
    riskLevel,
    score: Math.min(score, 100),
    indicators,
    suspiciousPhrases: [...phrases],
    urls,
    explanation: explain(riskLevel, indicators),
    recommendedAction: action(riskLevel),
    verificationAdvice: advice(ids),
  };
}

function explain(level: RiskLevel, ind: Indicator[]): string {
  if (!ind.length) return "We did not find common warning signs. That does not mean the message is safe. Scams can look normal.";
  const names = ind.slice(0, 3).map((i) => i.title.toLowerCase()).join("; ");
  if (level === "high") return `This message shows several strong warning signs of a scam: ${names}.`;
  if (level === "medium") return `This message shows some warning signs: ${names}. Be careful.`;
  return `We found a minor warning sign: ${names}. Stay cautious.`;
}

function action(level: RiskLevel): string {
  if (level === "high") return "Do not reply, do not tap any links, and do not share codes or send money. Talk to a family member or call the organisation using a number you already trust.";
  if (level === "medium") return "Pause before acting. Verify the sender through an official channel before replying, paying or tapping links.";
  return "No strong warning signs found, but stay alert. If anything feels off, check with someone you trust.";
}

function advice(ids: Set<string>): string[] {
  const a = ["Contact the organisation using the phone number on your card, bill or their official website. Not the number in the message."];
  if (ids.has("credentials")) a.push("Never share OTPs, PINs or passwords with anyone, even if they say they are from your bank.");
  if (ids.has("payment")) a.push("Real organisations do not ask for payment by gift card, crypto or an unexpected payment link.");
  if (ids.has("impersonation")) a.push("If it claims to be a relative, call them on their old, known number to check.");
  if (ids.has("remote_access")) a.push("Do not install apps or share your screen at the request of someone who contacted you.");
  if (ids.has("link") || ids.has("risky_link")) a.push("Do not tap the link. Type the official website address yourself.");
  a.push("If you already shared details or money, contact your bank immediately and report it to your local cybercrime helpline.");
  return a;
}

const ORDER: RiskLevel[] = ["low", "medium", "high"];

/** Combines rule and AI verdicts. The AI can raise the risk, never lower it below the rules. */
export function mergeRisk(rules: RiskLevel, ai: RiskLevel | undefined): RiskLevel {
  if (!ai) return rules;
  return ORDER[Math.max(ORDER.indexOf(rules), ORDER.indexOf(ai))];
}
