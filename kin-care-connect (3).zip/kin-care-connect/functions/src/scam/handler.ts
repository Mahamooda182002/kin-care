import { HttpsError, onCall } from "firebase-functions/v2/https";
import { z } from "zod";
import { AI_API_KEY, chatJson } from "../ai/provider";
import { SCAM_PROMPT, wrapUserText } from "../ai/prompts";
import { callableOptions, db, FieldValue, guarded, logEvent, anon, parse, requireAuth } from "../lib/core";
import { enforceRateLimit } from "../lib/rateLimit";
import { analyzeRules, mergeRisk, SCAM_DISCLAIMER } from "./rules";

const Input = z.object({
  text: z.string().trim().min(1).max(5000),
  inputType: z.enum(["sms", "whatsapp", "email", "url", "payment"]),
  useAi: z.boolean().default(false),
});

const AiOut = z.object({
  riskLevel: z.enum(["low", "medium", "high"]),
  suspiciousPhrases: z.array(z.string().max(200)).max(10).default([]),
  explanation: z.string().max(800).default(""),
  recommendedAction: z.string().max(400).default(""),
  verificationAdvice: z.array(z.string().max(300)).max(6).default([]),
});

/**
 * POST /api/scam/analyze
 * Rules always run. AI runs only when the user asked for it AND has given
 * explicit consent in their privacy settings (checked server-side). The
 * message text is never stored or logged; only the verdict is saved.
 */
export const scamAnalyze = onCall({ ...callableOptions, secrets: [AI_API_KEY] }, async (req) => {
  const caller = requireAuth(req);
  return guarded("scamAnalyze", caller.uid, async () => {
    const input = parse(Input, req.data);
    await enforceRateLimit(caller.uid, "scamAnalyze");

    const rules = analyzeRules(input.text);
    let aiUsed = false;
    let aiNote: string | undefined;
    let riskLevel = rules.riskLevel;
    let phrases = rules.suspiciousPhrases;
    let advice = rules.verificationAdvice;

    if (input.useAi) {
      const user = await db.doc(`users/${caller.uid}`).get();
      if (user.get("privacy.aiScamConsent") !== true) {
        throw new HttpsError("failed-precondition", "Please allow AI checks in Settings › Privacy first.");
      }
      try {
        const raw = await chatJson(SCAM_PROMPT, `Message type: ${input.inputType}\n${wrapUserText(input.text)}`, { maxTokens: 700 });
        const ai = AiOut.safeParse(raw);
        if (ai.success) {
          aiUsed = true;
          riskLevel = mergeRisk(rules.riskLevel, ai.data.riskLevel);
          // Only keep AI "quotes" that really appear in the message.
          const lower = input.text.toLowerCase();
          const realQuotes = ai.data.suspiciousPhrases.filter((p) => p && lower.includes(p.toLowerCase()));
          phrases = [...new Set([...phrases, ...realQuotes])];
          advice = [...new Set([...advice, ...ai.data.verificationAdvice])].slice(0, 8);
          aiNote = [ai.data.explanation, ai.data.recommendedAction].filter(Boolean).join(" ");
          if (/\b(definitely|certainly|100%|completely)\s+safe\b/i.test(aiNote)) {
            aiNote = "The AI review did not find extra warning signs, but no check can guarantee a message is safe.";
          }
        } else {
          aiNote = "The AI review could not be completed, so this result uses warning-sign rules only.";
        }
      } catch (e) {
        if (e instanceof HttpsError && e.code === "failed-precondition") throw e;
        aiNote = "The AI service is unavailable right now, so this result uses warning-sign rules only.";
      }
    }

    await db.collection("scamChecks").add({
      userId: caller.uid,
      inputType: input.inputType,
      riskLevel,
      indicators: rules.indicators.map((i) => ({ id: i.id, title: i.title })),
      recommendations: [rules.recommendedAction],
      aiUsed,
      createdAt: FieldValue.serverTimestamp(),
    });

    logEvent("scamAnalyze.done", { user: anon(caller.uid), risk: riskLevel, aiUsed, type: input.inputType });

    const final = riskLevel === rules.riskLevel ? rules : { ...rules, ...analyzeRulesWithLevel(rules, riskLevel) };
    return {
      ...final,
      riskLevel,
      suspiciousPhrases: phrases,
      verificationAdvice: advice,
      aiUsed,
      aiNote: aiNote ?? null,
      disclaimer: SCAM_DISCLAIMER,
    };
  });
});

function analyzeRulesWithLevel(rules: ReturnType<typeof analyzeRules>, level: "low" | "medium" | "high") {
  if (level === "high") {
    return {
      explanation: `${rules.explanation} An AI review also rated this message as high risk.`,
      recommendedAction: "Do not reply, do not tap any links, and do not share codes or send money. Talk to a family member or call the organisation using a number you already trust.",
    };
  }
  return {
    explanation: `${rules.explanation} An AI review suggests extra caution.`,
    recommendedAction: "Pause before acting. Verify the sender through an official channel before replying, paying or tapping links.",
  };
}
