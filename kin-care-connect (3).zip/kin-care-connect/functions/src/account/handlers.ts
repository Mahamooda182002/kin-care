import { HttpsError, onCall } from "firebase-functions/v2/https";
import { z } from "zod";
import { anon, auth, callableOptions, db, FieldValue, guarded, logEvent, parse, requireAuth, storage } from "../lib/core";
import { enforceRateLimit } from "../lib/rateLimit";
import { FAMILY_SCOPED, OWNED, rateLimitDocIds, storagePrefixes } from "./deletionPlan";

function serialise(v: unknown): unknown {
  if (v && typeof v === "object") {
    if (typeof (v as { toDate?: unknown }).toDate === "function") return (v as { toDate: () => Date }).toDate().toISOString();
    if (Array.isArray(v)) return v.map(serialise);
    return Object.fromEntries(Object.entries(v as Record<string, unknown>).map(([k, x]) => [k, serialise(x)]));
  }
  return v;
}

/** Data export (Module M): everything the user owns, as JSON. */
export const accountExportData = onCall({ ...callableOptions, timeoutSeconds: 120 }, async (req) => {
  const caller = requireAuth(req);
  return guarded("accountExportData", caller.uid, async () => {
    await enforceRateLimit(caller.uid, "accountExportData");
    const out: Record<string, unknown> = { exportedAt: new Date().toISOString(), app: "Kin Care Connect" };
    const user = await db.doc(`users/${caller.uid}`).get();
    out.profile = serialise(user.data() ?? {});
    const dump = (snap: FirebaseFirestore.QuerySnapshot) =>
      snap.docs.map((d) => ({ id: d.id, ...(serialise(d.data()) as object) }));
    for (const { collection, field } of OWNED) {
      out[collection] = dump(await db.collection(collection).where(field, "==", caller.uid).limit(5000).get());
    }
    // Data about the user held in shared documents.
    out.invitationsSent = dump(await db.collection("invitations").where("invitedBy", "==", caller.uid).limit(1000).get());
    if (caller.email) {
      out.invitationsReceived = dump(await db.collection("invitations").where("inviteeEmail", "==", caller.email).limit(1000).get());
    }
    out.careProfilesLinkedToYou = dump(await db.collection("careProfiles").where("linkedUserId", "==", caller.uid).limit(500).get());
    out.careProfilesYouCareFor = dump(await db.collection("careProfiles").where("caregiverIds", "array-contains", caller.uid).limit(500).get());
    const devices = await db.collection(`users/${caller.uid}/devices`).get();
    out.notificationDevices = devices.size; // tokens themselves are not useful to export
    logEvent("accountExportData.done", { user: anon(caller.uid) });
    return { json: JSON.stringify(out, null, 2) };
  });
});

async function deleteQuery(q: FirebaseFirestore.Query): Promise<number> {
  let total = 0;
  for (;;) {
    const snap = await q.limit(400).get();
    if (snap.empty) return total;
    const batch = db.batch();
    for (const d of snap.docs) {
      // Remove subcollections we know about (reminder history).
      if (d.ref.parent.id === "reminders") {
        const hist = await d.ref.collection("history").listDocuments();
        hist.forEach((h) => batch.delete(h));
      }
      batch.delete(d.ref);
    }
    await batch.commit();
    total += snap.size;
  }
}

/**
 * Deletes the caller's account and data. The app re-authenticates the user
 * (password) before calling this. Families where the user is the only admin
 * are deleted with their care profiles and memberships.
 */
export const accountDelete = onCall({ ...callableOptions, timeoutSeconds: 300 }, async (req) => {
  const caller = requireAuth(req);
  return guarded("accountDelete", caller.uid, async () => {
    parse(z.object({ confirm: z.literal(true) }), req.data);
    await enforceRateLimit(caller.uid, "accountDelete");
    const authTime = Number(req.auth?.token.auth_time ?? 0) * 1000;
    if (Date.now() - authTime > 10 * 60_000) {
      throw new HttpsError("failed-precondition", "For your security, please enter your password again and retry.");
    }
    const uid = caller.uid;

    // Families administered solely by this user: delete the family and the
    // care information kept in it.
    const adminOf = await db.collection("familyMembers").where("userId", "==", uid).where("role", "==", "admin").get();
    for (const m of adminOf.docs) {
      const familyId = String(m.get("familyId"));
      const otherAdmins = await db.collection("familyMembers")
        .where("familyId", "==", familyId).where("role", "==", "admin").where("invitationStatus", "==", "accepted").get();
      if (otherAdmins.docs.every((d) => d.get("userId") === uid)) {
        for (const collection of FAMILY_SCOPED) {
          await deleteQuery(db.collection(collection).where("familyId", "==", familyId));
        }
        await db.doc(`families/${familyId}`).delete();
      }
    }
    // Unlink from care profiles where this user is the elder (sharing off).
    const linked = await db.collection("careProfiles").where("linkedUserId", "==", uid).get();
    for (const p of linked.docs) {
      await p.ref.update({ linkedUserId: null, sharingConsent: { activity: false, medical: false, reminders: false } });
    }
    // Remove the user from caregiver assignments in other families.
    const caring = await db.collection("careProfiles").where("caregiverIds", "array-contains", uid).get();
    for (const p of caring.docs) {
      await p.ref.update({ caregiverIds: FieldValue.arrayRemove(uid) });
    }

    for (const { collection, field } of OWNED) {
      await deleteQuery(db.collection(collection).where(field, "==", uid));
    }
    // Invitations sent to or by this user.
    await deleteQuery(db.collection("invitations").where("invitedBy", "==", uid));
    if (caller.email) await deleteQuery(db.collection("invitations").where("inviteeEmail", "==", caller.email));
    // Abuse-prevention counters.
    await Promise.all(rateLimitDocIds(uid).map((id) => db.doc(`rateLimits/${id}`).delete()));
    // Profile document with its devices subcollection (FCM tokens).
    await db.recursiveDelete(db.doc(`users/${uid}`));
    for (const prefix of storagePrefixes(uid)) {
      await storage.bucket().deleteFiles({ prefix }).catch(() => undefined);
    }
    // Finally the sign-in account itself.
    await auth.deleteUser(uid);
    logEvent("accountDelete.done", { user: anon(uid) });
    return { ok: true };
  });
});
