/**
 * What account export and account deletion cover. Kept free of Firebase
 * calls so it can be unit-tested (see test/account.test.ts) and kept in sync
 * with docs/DATA_INVENTORY.md and the Privacy Policy.
 */
import { LIMITS } from "../lib/rateLimit";

/** Top-level collections holding documents owned by one user. */
export const OWNED: ReadonlyArray<{ collection: string; field: string }> = [
  { collection: "medicalSummaries", field: "userId" },
  { collection: "recordings", field: "userId" },
  { collection: "scamChecks", field: "userId" },
  { collection: "reminders", field: "userId" },
  { collection: "notifications", field: "userId" },
  { collection: "activityRecords", field: "userId" },
  { collection: "emergencyContacts", field: "ownerId" },
  { collection: "familyMembers", field: "userId" },
];

/**
 * Family-scoped collections removed together with a family that the deleted
 * user administered alone (care information about a care profile that no
 * longer exists). `families/{id}` itself is deleted last.
 */
export const FAMILY_SCOPED: ReadonlyArray<string> = [
  "careProfiles",
  "familyMembers",
  "invitations",
  "reminders",
  "emergencyContacts",
];

/** Storage prefixes that belong to a user. */
export function storagePrefixes(uid: string): string[] {
  return [`recordings/${uid}/`, `profileImages/${uid}/`];
}

/** Rate-limit counters (`rateLimits/{uid}_{endpoint}`) for a user. */
export function rateLimitDocIds(uid: string): string[] {
  return Object.keys(LIMITS).map((endpoint) => `${uid}_${endpoint}`);
}
