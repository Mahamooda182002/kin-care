import { HttpsError, onCall } from "firebase-functions/v2/https";
import { z } from "zod";
import { anon, auth, callableOptions, db, FieldValue, guarded, logEvent, parse, requireAuth, requireRole, requireVerifiedEmail } from "../lib/core";
import { notifyUser } from "../lib/notify";
import { enforceRateLimit } from "../lib/rateLimit";

const ROLES = ["admin", "caregiver", "viewer", "elderly"] as const;
const id = z.string().regex(/^[A-Za-z0-9_-]{6,64}$/);

const InviteInput = z.object({
  familyId: id,
  email: z.string().trim().toLowerCase().email().max(254),
  role: z.enum(ROLES),
  profileId: id.optional(),
});

/** POST /api/family/invite — admins only. */
export const familyInvite = onCall(callableOptions, async (req) => {
  const caller = requireAuth(req);
  return guarded("familyInvite", caller.uid, async () => {
    const input = parse(InviteInput, req.data);
    requireVerifiedEmail(caller);
    await enforceRateLimit(caller.uid, "familyInvite");
    await requireRole(input.familyId, caller.uid, ["admin"]);

    if (input.email === caller.email) throw new HttpsError("invalid-argument", "You are already in this family.");

    const family = await db.doc(`families/${input.familyId}`).get();
    if (!family.exists) throw new HttpsError("not-found", "Family not found.");

    if (input.profileId) {
      if (input.role !== "elderly") throw new HttpsError("invalid-argument", "Only elderly account holders can be linked to a care profile.");
      const p = await db.doc(`careProfiles/${input.profileId}`).get();
      if (!p.exists || p.get("familyId") !== input.familyId || p.get("linkedUserId")) {
        throw new HttpsError("failed-precondition", "That care profile can't be linked.");
      }
    }

    // Already a member?
    try {
      const existingUser = await auth.getUserByEmail(input.email);
      const m = await db.doc(`familyMembers/${input.familyId}_${existingUser.uid}`).get();
      if (m.exists && m.get("invitationStatus") === "accepted") throw new HttpsError("already-exists", "This person is already a member.");
    } catch (e) {
      if (e instanceof HttpsError) throw e;
      // user-not-found: they can accept after signing up with this email.
    }

    const dup = await db.collection("invitations")
      .where("familyId", "==", input.familyId).where("inviteeEmail", "==", input.email).where("status", "==", "pending").limit(1).get();
    if (!dup.empty) throw new HttpsError("already-exists", "An invitation is already pending for this email.");

    const inviter = await db.doc(`users/${caller.uid}`).get();
    const invitedByName = String(inviter.get("fullName") ?? "A family member").slice(0, 80);
    const ref = await db.collection("invitations").add({
      familyId: input.familyId,
      familyName: family.get("familyName"),
      inviteeEmail: input.email,
      role: input.role,
      profileId: input.profileId ?? null,
      invitedBy: caller.uid,
      invitedByName,
      status: "pending",
      createdAt: FieldValue.serverTimestamp(),
      expiresAt: new Date(Date.now() + 14 * 24 * 3600 * 1000),
    });

    try {
      const invitee = await auth.getUserByEmail(input.email);
      await notifyUser(invitee.uid, "familyInvitation", {
        title: "Family invitation",
        message: `${invitedByName} invited you to join ${family.get("familyName")}.`,
        link: "/family",
      });
    } catch {
      // Not registered yet. They will see it after signing up.
    }

    logEvent("familyInvite.created", { user: anon(caller.uid), role: input.role });
    return { invitationId: ref.id };
  });
});

const AcceptInput = z.object({ invitationId: id, accept: z.boolean() });

/** POST /api/family/accept-invitation — invitee only, verified email required. */
export const familyAcceptInvitation = onCall(callableOptions, async (req) => {
  const caller = requireAuth(req);
  return guarded("familyAcceptInvitation", caller.uid, async () => {
    const input = parse(AcceptInput, req.data);
    requireVerifiedEmail(caller);
    await enforceRateLimit(caller.uid, "familyAcceptInvitation");

    const invRef = db.doc(`invitations/${input.invitationId}`);
    const result = await db.runTransaction(async (tx) => {
      const inv = await tx.get(invRef);
      if (!inv.exists) throw new HttpsError("not-found", "Invitation not found.");
      const d = inv.data()!;
      if (d.inviteeEmail !== caller.email) throw new HttpsError("permission-denied", "This invitation was sent to a different email.");
      if (d.status !== "pending") throw new HttpsError("failed-precondition", "This invitation is no longer active.");
      const exp = d.expiresAt?.toDate?.() as Date | undefined;
      if (exp && exp.getTime() < Date.now()) {
        tx.update(invRef, { status: "expired" });
        throw new HttpsError("failed-precondition", "This invitation has expired. Ask for a new one.");
      }

      if (!input.accept) {
        tx.update(invRef, { status: "rejected", respondedAt: FieldValue.serverTimestamp() });
        return { familyId: d.familyId as string, invitedBy: d.invitedBy as string, accepted: false };
      }

      const user = await tx.get(db.doc(`users/${caller.uid}`));
      let profileRef: FirebaseFirestore.DocumentReference | null = null;
      if (d.profileId && d.role === "elderly") {
        profileRef = db.doc(`careProfiles/${d.profileId}`);
        const p = await tx.get(profileRef);
        if (!p.exists || p.get("familyId") !== d.familyId || p.get("linkedUserId")) profileRef = null;
      }

      const memberId = `${d.familyId}_${caller.uid}`;
      tx.set(db.doc(`familyMembers/${memberId}`), {
        membershipId: memberId,
        familyId: d.familyId,
        userId: caller.uid,
        role: d.role,
        permissions: { manageFamily: d.role === "admin", editCare: d.role === "admin" || d.role === "caregiver" },
        invitationStatus: "accepted",
        displayName: user.get("fullName") ?? null,
        email: caller.email,
        invitationId: inv.id,
        createdAt: FieldValue.serverTimestamp(),
      });
      if (profileRef) {
        // The elder now controls consent; everything stays private until they choose.
        tx.update(profileRef, {
          linkedUserId: caller.uid,
          sharingConsent: { activity: false, medical: false, reminders: false },
          consentUpdatedBy: caller.uid,
          consentUpdatedAt: FieldValue.serverTimestamp(),
        });
      }
      tx.update(invRef, { status: "accepted", respondedAt: FieldValue.serverTimestamp(), acceptedBy: caller.uid });
      return { familyId: d.familyId as string, invitedBy: d.invitedBy as string, accepted: true };
    });

    if (result.accepted) {
      await notifyUser(result.invitedBy, "familyInvitation", {
        title: "Invitation accepted",
        message: "A family member accepted your invitation.",
        link: `/family/${result.familyId}`,
      }).catch(() => undefined);
    }
    logEvent("familyAcceptInvitation.done", { user: anon(caller.uid), accepted: result.accepted });
    return { familyId: result.familyId, accepted: result.accepted };
  });
});

const RevokeInput = z.object({ invitationId: id });

/** Admin revokes a pending invitation. */
export const familyRevokeInvitation = onCall(callableOptions, async (req) => {
  const caller = requireAuth(req);
  return guarded("familyRevokeInvitation", caller.uid, async () => {
    const input = parse(RevokeInput, req.data);
    await enforceRateLimit(caller.uid, "familyRevokeInvitation");
    const ref = db.doc(`invitations/${input.invitationId}`);
    const inv = await ref.get();
    if (!inv.exists) throw new HttpsError("not-found", "Invitation not found.");
    await requireRole(String(inv.get("familyId")), caller.uid, ["admin"]);
    if (inv.get("status") !== "pending") throw new HttpsError("failed-precondition", "This invitation is no longer active.");
    await ref.update({ status: "revoked", revokedBy: caller.uid, respondedAt: FieldValue.serverTimestamp() });
    return { ok: true };
  });
});
