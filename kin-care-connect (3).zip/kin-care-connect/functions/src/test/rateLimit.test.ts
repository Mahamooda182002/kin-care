import { strict as assert } from "node:assert";
import { describe, it } from "node:test";
import { dayWindow } from "../activity/handler";
import { evaluateWindow } from "../lib/rateLimit";

describe("rate limit window", () => {
  const limit = { max: 2, windowSeconds: 60 };
  it("allows first call and counts", () => {
    const a = evaluateWindow(undefined, 1000, limit);
    assert.deepEqual(a, { allowed: true, windowStart: 1000, count: 1 });
    const b = evaluateWindow({ windowStart: 1000, count: 1 }, 2000, limit);
    assert.equal(b.count, 2);
  });
  it("blocks over the limit", () => {
    assert.equal(evaluateWindow({ windowStart: 1000, count: 2 }, 3000, limit).allowed, false);
  });
  it("resets after the window", () => {
    assert.deepEqual(evaluateWindow({ windowStart: 1000, count: 2 }, 61_000, limit), { allowed: true, windowStart: 61_000, count: 1 });
  });
});

describe("activity day window", () => {
  it("computes IST local day in UTC", () => {
    const { start, end } = dayWindow("2026-11-03", 330);
    assert.equal(start.toISOString(), "2026-11-02T18:30:00.000Z");
    assert.equal(end.getTime() - start.getTime(), 86_400_000);
  });
});
