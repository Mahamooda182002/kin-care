import { strict as assert } from "node:assert";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, it } from "node:test";
import { FAMILY_SCOPED, OWNED, rateLimitDocIds, storagePrefixes } from "../account/deletionPlan";
import { LIMITS } from "../lib/rateLimit";

// Repo root, from functions/lib/test/ at runtime.
const ROOT = join(__dirname, "..", "..", "..");

describe("account deletion plan", () => {
  it("covers every collection that holds a user's own documents", () => {
    const owned = new Set(OWNED.map((o) => o.collection));
    for (const c of ["medicalSummaries", "recordings", "scamChecks", "reminders", "notifications",
      "activityRecords", "emergencyContacts", "familyMembers"]) {
      assert.ok(owned.has(c), `missing ${c}`);
    }
  });

  it("every top-level collection in firestore.rules is handled by deletion", () => {
    const rules = readFileSync(join(ROOT, "firestore.rules"), "utf8");
    const collections = [...rules.matchAll(/^ {4}match \/(\w+)\/\{/gm)].map((m) => m[1]);
    const handled = new Set<string>([
      ...OWNED.map((o) => o.collection),
      ...FAMILY_SCOPED,
      "users", // recursiveDelete (incl. devices)
      "families", // deleted when administered alone
      "invitations", // invitedBy / inviteeEmail
      "careProfiles", // unlinked / caregiverIds cleaned / family-scoped
      "rateLimits", // rateLimitDocIds
      "auditLog", // not written by this codebase
    ]);
    assert.ok(collections.length >= 10, "rules parsing found too few collections");
    for (const c of collections) assert.ok(handled.has(c), `collection ${c} is not covered by account deletion`);
  });

  it("removes every rate-limit counter", () => {
    const ids = rateLimitDocIds("u1");
    assert.equal(ids.length, Object.keys(LIMITS).length);
    assert.ok(ids.every((id) => id.startsWith("u1_")));
  });

  it("removes recordings and profile pictures from Storage", () => {
    assert.deepEqual(storagePrefixes("u1"), ["recordings/u1/", "profileImages/u1/"]);
  });
});

describe("no marketing email", () => {
  it("the backend has no email-sending code (only Firebase Auth's own account emails)", () => {
    const pkg = JSON.parse(readFileSync(join(ROOT, "functions", "package.json"), "utf8"));
    const deps = Object.keys({ ...pkg.dependencies, ...pkg.devDependencies });
    for (const banned of ["nodemailer", "@sendgrid/mail", "mailgun.js", "postmark", "@mailchimp/mailchimp_marketing"]) {
      assert.ok(!deps.includes(banned), `${banned} found`);
    }
  });
});

describe("no analytics or ads SDKs", () => {
  it("pubspec.yaml and functions/package.json contain no analytics/ads packages", () => {
    const pubspec = readFileSync(join(ROOT, "pubspec.yaml"), "utf8");
    const pkg = readFileSync(join(ROOT, "functions", "package.json"), "utf8");
    for (const text of [pubspec, pkg]) {
      assert.doesNotMatch(text, /firebase_analytics|firebase_crashlytics|google_mobile_ads|facebook|appsflyer|mixpanel|amplitude|segment|sentry/i);
    }
  });
  it("AndroidManifest disables analytics, ad ID and FCM auto-init", () => {
    const manifest = readFileSync(join(ROOT, "android", "app", "src", "main", "AndroidManifest.xml"), "utf8");
    assert.match(manifest, /firebase_analytics_collection_deactivated"\s+android:value="true"/);
    assert.match(manifest, /google_analytics_adid_collection_enabled"\s+android:value="false"/);
    assert.match(manifest, /firebase_messaging_auto_init_enabled"\s+android:value="false"/);
    assert.doesNotMatch(manifest, /android\.permission\.CAMERA/);
  });
});
