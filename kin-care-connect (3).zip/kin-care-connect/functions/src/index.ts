/**
 * Kin Care Connect backend — Firebase Cloud Functions (2nd gen, TypeScript).
 *
 * Callable functions (Firebase Auth ID token + App Check verified automatically):
 *   medicalTranscribe       POST /api/medical/transcribe
 *   medicalSummarize        POST /api/medical/summarize
 *   medicalExplain          POST /api/medical/explain
 *   scamAnalyze             POST /api/scam/analyze
 *   familyInvite            POST /api/family/invite
 *   familyAcceptInvitation  POST /api/family/accept-invitation
 *   familyRevokeInvitation  (admin helper)
 *   activitySummary         GET  /api/activity/summary
 *   remindersCreate         POST /api/reminders
 *   accountExportData / accountDelete (Settings › Data export / Delete account)
 *
 * Scheduled:
 *   dispatchDueReminders    every 5 minutes
 *   purgeExpiredData        daily retention enforcement
 */
export { medicalExplain, medicalSummarize, medicalTranscribe } from "./medical/handlers";
export { scamAnalyze } from "./scam/handler";
export { familyInvite, familyAcceptInvitation, familyRevokeInvitation } from "./family/handlers";
export { activitySummary } from "./activity/handler";
export { remindersCreate, dispatchDueReminders } from "./reminders/handlers";
export { accountExportData, accountDelete } from "./account/handlers";
export { purgeExpiredData } from "./maintenance/purge";
