import { createHash } from "node:crypto";
import { getApps, initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { FieldValue, getFirestore, Timestamp } from "firebase-admin/firestore";
import { getMessaging } from "firebase-admin/messaging";
import { getStorage } from "firebase-admin/storage";
import { logger } from "firebase-functions";
import { CallableRequest, HttpsError } from "firebase-functions/v2/https";
import { z } from "zod";

if (getApps().length === 0) initializeApp();

export const db = getFirestore();
export const auth = getAuth();
export const messaging = getMessaging();
export const storage = getStorage();
export { FieldValue, Timestamp };

/** Region close to India; change in one place if needed (also AppConfig.functionsRegion). */
export const REGION = process.env.FUNCTIONS_REGION || "asia-south1";

/**
 * App Check enforcement for callables. Set ENFORCE_APP_CHECK=false in
 * functions/.env.local for emulator testing only.
 */
export const ENFORCE_APP_CHECK = process.env.ENFORCE_APP_CHECK !== "false";

export const callableOptions = {
  region: REGION,
  enforceAppCheck: ENFORCE_APP_CHECK,
  cors: false,
  memory: "256MiB" as const,
  timeoutSeconds: 60,
};

/** Short, non-reversible id for logs. Never log raw uids, emails or content. */
export function anon(id: string | undefined | null): string {
  if (!id) return "anon";
  return createHash("sha256").update(id).digest("hex").slice(0, 10);
}

/** Structured logging that never includes user content. */
export function logEvent(event: string, data: Record<string, string | number | boolean | undefined> = {}): void {
  logger.info(event, data);
}

export interface Caller {
  uid: string;
  email?: string;
  emailVerified: boolean;
}

/** Authentication verification for every callable. */
export function requireAuth(req: CallableRequest<unknown>): Caller {
  if (!req.auth) throw new HttpsError("unauthenticated", "Please sign in again.");
  return {
    uid: req.auth.uid,
    email: (req.auth.token.email as string | undefined)?.toLowerCase(),
    emailVerified: req.auth.token.email_verified === true,
  };
}

export function requireVerifiedEmail(c: Caller): void {
  if (!c.email || !c.emailVerified) {
    throw new HttpsError("failed-precondition", "Please verify your email address first, then try again.");
  }
}

/** Input validation with plain-language errors (no echo of user content). */
export function parse<T extends z.ZodType>(schema: T, data: unknown): z.infer<T> {
  const r = schema.safeParse(data);
  if (!r.success) {
    const field = r.error.issues[0]?.path.join(".") || "input";
    throw new HttpsError("invalid-argument", `Some information is missing or invalid (${field}).`);
  }
  return r.data;
}

/** Family membership/role lookup used for backend authorization. */
export async function getMembership(familyId: string, uid: string): Promise<{ role: string; status: string } | null> {
  const snap = await db.doc(`familyMembers/${familyId}_${uid}`).get();
  if (!snap.exists) return null;
  const d = snap.data()!;
  return { role: String(d.role), status: String(d.invitationStatus) };
}

export async function requireRole(familyId: string, uid: string, roles: string[]): Promise<string> {
  const m = await getMembership(familyId, uid);
  if (!m || m.status !== "accepted" || !roles.includes(m.role)) {
    throw new HttpsError("permission-denied", "You don't have permission to do that.");
  }
  return m.role;
}

/** Wraps unexpected errors so internals never leak to the client. */
export async function guarded<T>(name: string, uid: string | undefined, fn: () => Promise<T>): Promise<T> {
  try {
    return await fn();
  } catch (e) {
    if (e instanceof HttpsError) {
      logEvent(`${name}.rejected`, { user: anon(uid), code: e.code });
      throw e;
    }
    logger.error(`${name}.failed`, { user: anon(uid), error: e instanceof Error ? e.name + ": " + e.message.slice(0, 200) : "unknown" });
    throw new HttpsError("internal", "Something went wrong. Please try again.");
  }
}
