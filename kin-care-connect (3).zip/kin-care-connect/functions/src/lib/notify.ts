import { anon, db, FieldValue, logEvent, messaging } from "./core";

export type NotificationType = "reminder" | "reminderCompleted" | "familyInvitation" | "activity" | "security";

const PREF_KEY: Record<NotificationType, string> = {
  reminder: "reminders",
  reminderCompleted: "reminderCompletion",
  familyInvitation: "familyInvitations",
  activity: "activityUpdates",
  security: "securityEvents",
};

/** Generic lock-screen text used unless the user opted in to details. */
const GENERIC: Record<NotificationType, { title: string; body: string }> = {
  reminder: { title: "Kin Care Connect", body: "You have a care reminder." },
  reminderCompleted: { title: "Kin Care Connect", body: "A shared reminder was completed." },
  familyInvitation: { title: "Kin Care Connect", body: "You have a new family invitation." },
  activity: { title: "Kin Care Connect", body: "There is a new activity update." },
  security: { title: "Kin Care Connect", body: "There was a security event on your account." },
};

/**
 * Creates an in-app notification and (if enabled) sends a push.
 * Sensitive details are NOT put on the lock screen by default: the push uses
 * generic text and Android "private" visibility; full text is only in the
 * in-app notification centre (behind sign-in).
 */
export async function notifyUser(
  userId: string,
  type: NotificationType,
  detail: { title: string; message: string; link?: string },
): Promise<void> {
  const userSnap = await db.doc(`users/${userId}`).get();
  if (!userSnap.exists) return;
  const prefs = (userSnap.get("notificationPrefs") ?? {}) as Record<string, boolean>;
  if (prefs[PREF_KEY[type]] === false) return;

  await db.collection("notifications").add({
    userId,
    type,
    title: detail.title,
    message: detail.message,
    link: detail.link ?? null,
    readStatus: false,
    createdAt: FieldValue.serverTimestamp(),
  });

  const showDetails = prefs.showDetailsOnLockScreen === true;
  const visible = showDetails ? { title: detail.title, body: detail.message } : GENERIC[type];
  const devices = await db.collection(`users/${userId}/devices`).get();
  const tokens = devices.docs.map((d) => String(d.get("token"))).filter(Boolean);
  if (!tokens.length) return;

  const res = await messaging.sendEachForMulticast({
    tokens,
    notification: visible,
    data: { type, link: detail.link ?? "" },
    android: {
      priority: type === "reminder" ? "high" : "normal",
      notification: { visibility: showDetails ? "private" : "secret" },
    },
  });
  // Clean up dead tokens.
  const dead: Promise<unknown>[] = [];
  res.responses.forEach((r, i) => {
    const code = r.error?.code ?? "";
    if (code.includes("registration-token-not-registered") || code.includes("invalid-argument")) {
      dead.push(devices.docs[i].ref.delete());
    }
  });
  await Promise.all(dead);
  logEvent("notify.sent", { user: anon(userId), type, ok: res.successCount, failed: res.failureCount });
}
