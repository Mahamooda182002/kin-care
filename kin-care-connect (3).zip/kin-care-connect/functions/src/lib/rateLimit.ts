import { HttpsError } from "firebase-functions/v2/https";
import { db, Timestamp } from "./core";

export interface Limit {
  /** Max calls in the window. */
  max: number;
  /** Window length in seconds. */
  windowSeconds: number;
}

/** Per-endpoint limits. AI calls cost money, so they are tighter. */
export const LIMITS: Record<string, Limit> = {
  medicalExplain: { max: 30, windowSeconds: 3600 },
  medicalSummarize: { max: 30, windowSeconds: 3600 },
  medicalTranscribe: { max: 10, windowSeconds: 3600 },
  scamAnalyze: { max: 60, windowSeconds: 3600 },
  familyInvite: { max: 20, windowSeconds: 3600 },
  familyAcceptInvitation: { max: 30, windowSeconds: 3600 },
  familyRevokeInvitation: { max: 30, windowSeconds: 3600 },
  activitySummary: { max: 120, windowSeconds: 3600 },
  remindersCreate: { max: 60, windowSeconds: 3600 },
  accountExportData: { max: 5, windowSeconds: 3600 },
  accountDelete: { max: 3, windowSeconds: 3600 },
};

/** Pure check used by the transaction and by unit tests. */
export function evaluateWindow(
  existing: { windowStart: number; count: number } | undefined,
  nowMs: number,
  limit: Limit,
): { allowed: boolean; windowStart: number; count: number } {
  const windowMs = limit.windowSeconds * 1000;
  if (!existing || nowMs - existing.windowStart >= windowMs) {
    return { allowed: true, windowStart: nowMs, count: 1 };
  }
  if (existing.count >= limit.max) {
    return { allowed: false, windowStart: existing.windowStart, count: existing.count };
  }
  return { allowed: true, windowStart: existing.windowStart, count: existing.count + 1 };
}

/** Fixed-window rate limit stored in Firestore (rateLimits/{uid}_{endpoint}). */
export async function enforceRateLimit(uid: string, endpoint: string): Promise<void> {
  const limit = LIMITS[endpoint] ?? { max: 60, windowSeconds: 3600 };
  const ref = db.doc(`rateLimits/${uid}_${endpoint}`);
  const allowed = await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    const d = snap.data();
    const existing = d ? { windowStart: (d.windowStart as Timestamp).toMillis(), count: Number(d.count) } : undefined;
    const r = evaluateWindow(existing, Date.now(), limit);
    if (r.allowed) {
      tx.set(ref, {
        windowStart: Timestamp.fromMillis(r.windowStart),
        count: r.count,
        expiresAt: Timestamp.fromMillis(r.windowStart + limit.windowSeconds * 1000),
      });
    }
    return r.allowed;
  });
  if (!allowed) {
    throw new HttpsError("resource-exhausted", "You've reached the limit for now. Please try again later.");
  }
}
