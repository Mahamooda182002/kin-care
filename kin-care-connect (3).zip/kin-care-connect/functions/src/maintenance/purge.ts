import { onSchedule } from "firebase-functions/v2/scheduler";
import { db, FieldValue, logEvent, REGION, storage, Timestamp } from "../lib/core";

/** Retention policy (also shown in the app's Privacy settings). */
export const RETENTION_DAYS = {
  recordings: 30,
  scamChecks: 180,
  notifications: 90,
  rateLimits: 2,
  invitations: 30,
};

const daysAgo = (n: number) => Timestamp.fromMillis(Date.now() - n * 86_400_000);

async function purge(q: FirebaseFirestore.Query, onDoc?: (d: FirebaseFirestore.QueryDocumentSnapshot) => Promise<void>): Promise<number> {
  let total = 0;
  for (let i = 0; i < 50; i++) {
    const snap = await q.limit(300).get();
    if (snap.empty) break;
    const batch = db.batch();
    for (const d of snap.docs) {
      if (onDoc) await onDoc(d);
      else batch.delete(d.ref);
    }
    if (!onDoc) await batch.commit();
    total += snap.size;
    if (snap.size < 300) break;
  }
  return total;
}

/** Daily: enforce data retention and deletion policies. */
export const purgeExpiredData = onSchedule({ schedule: "every day 03:30", region: REGION, timeZone: "Asia/Kolkata" }, async () => {
  const recordings = await purge(
    db.collection("recordings").where("deletionStatus", "==", "active").where("createdAt", "<", daysAgo(RETENTION_DAYS.recordings)),
    async (d) => {
      await storage.bucket().file(String(d.get("storageReference"))).delete({ ignoreNotFound: true });
      await d.ref.update({ deletionStatus: "deleted", transcript: FieldValue.delete(), deletedAt: FieldValue.serverTimestamp(), deletedBy: "retention" });
    },
  );
  const scam = await purge(db.collection("scamChecks").where("createdAt", "<", daysAgo(RETENTION_DAYS.scamChecks)));
  const notifs = await purge(db.collection("notifications").where("createdAt", "<", daysAgo(RETENTION_DAYS.notifications)));
  const limits = await purge(db.collection("rateLimits").where("expiresAt", "<", daysAgo(RETENTION_DAYS.rateLimits)));
  const invites = await purge(db.collection("invitations").where("createdAt", "<", daysAgo(RETENTION_DAYS.invitations)));
  logEvent("purgeExpiredData.done", { recordings, scam, notifs, limits, invites });
});
