import { HttpsError, onCall } from "firebase-functions/v2/https";
import { z } from "zod";
import { inputAsksForAdvice, safetyNoticesFor, sanitizeDeep, verifyExtracted } from "../ai/guardrails";
import { MEDICAL_DISCLAIMER, MedicalOutput, MedicalOutputSchema } from "../ai/medicalSchema";
import { explainPrompt, LANGUAGE_NAMES, summarizePrompt, wrapUserText } from "../ai/prompts";
import { AI_API_KEY, STT_API_KEY, chatJson, transcribeAudio } from "../ai/provider";
import { anon, callableOptions, db, FieldValue, guarded, logEvent, parse, requireAuth, storage } from "../lib/core";
import { enforceRateLimit } from "../lib/rateLimit";

const languages = Object.keys(LANGUAGE_NAMES) as [string, ...string[]];

const TextInput = z.object({
  text: z.string().trim().min(1).max(20000),
  language: z.enum(languages).default("en"),
});

async function requireMedicalConsent(uid: string): Promise<void> {
  const snap = await db.doc(`users/${uid}`).get();
  if (snap.get("privacy.aiMedicalConsent") !== true) {
    throw new HttpsError("failed-precondition", "Please allow AI explanations in Settings › Privacy first.");
  }
}

/**
 * Runs the model, validates the structured response, separates facts from
 * generated text and applies medical safety guardrails.
 */
export async function runMedicalAi(kind: "explain" | "summarize", text: string, language: string): Promise<MedicalOutput> {
  const system = kind === "explain" ? explainPrompt(language) : summarizePrompt(language);
  const raw = await chatJson(system, wrapUserText(text), { maxTokens: 2000 });
  const parsed = MedicalOutputSchema.safeParse(raw);
  if (!parsed.success) {
    throw new HttpsError("internal", "The AI response was incomplete. Please try again.");
  }
  return postProcess(parsed.data, text);
}

/** Exported for unit tests. */
export function postProcess(data: ReturnType<typeof MedicalOutputSchema.parse>, originalText: string): MedicalOutput {
  const reasons = new Set<string>();
  // Generated explanation fields are sanitised.
  const summary = sanitizeDeep(data.summary, reasons);
  const terms = sanitizeDeep(data.terms, reasons);
  const abbreviations = sanitizeDeep(data.abbreviations, reasons);
  const followUpActions = sanitizeDeep(data.followUpActions, reasons);
  const questionsForDoctor = sanitizeDeep(data.questionsForDoctor, reasons);

  // "From your text" must really be from the text (facts, kept verbatim).
  const instr = verifyExtracted(originalText, data.fromYourText.instructions);
  const dates = data.fromYourText.dates.filter((d) => verifyExtracted(originalText, [`${d.date}`]).kept.length > 0 || verifyExtracted(originalText, [d.description]).kept.length > 0);
  const uncertainties = [...data.uncertainties];
  if (instr.dropped.length) {
    uncertainties.push("Some instructions could not be matched to your text and were left out. Please check the original.");
  }

  const safetyNotices = safetyNoticesFor(reasons, inputAsksForAdvice(originalText));
  return {
    summary,
    terms,
    abbreviations,
    fromYourText: { instructions: instr.kept, dates },
    followUpActions,
    questionsForDoctor,
    uncertainties,
    language: data.language,
    safetyNotices,
    disclaimer: MEDICAL_DISCLAIMER,
  };
}

/** POST /api/medical/explain */
export const medicalExplain = onCall({ ...callableOptions, timeoutSeconds: 90, secrets: [AI_API_KEY] }, async (req) => {
  const caller = requireAuth(req);
  return guarded("medicalExplain", caller.uid, async () => {
    const input = parse(TextInput, req.data);
    await requireMedicalConsent(caller.uid);
    await enforceRateLimit(caller.uid, "medicalExplain");
    const out = await runMedicalAi("explain", input.text, input.language);
    logEvent("medicalExplain.done", { user: anon(caller.uid), chars: input.text.length, lang: input.language, notices: out.safetyNotices.length });
    return out;
  });
});

/** POST /api/medical/summarize */
export const medicalSummarize = onCall({ ...callableOptions, timeoutSeconds: 90, secrets: [AI_API_KEY] }, async (req) => {
  const caller = requireAuth(req);
  return guarded("medicalSummarize", caller.uid, async () => {
    const input = parse(TextInput, req.data);
    await requireMedicalConsent(caller.uid);
    await enforceRateLimit(caller.uid, "medicalSummarize");
    const out = await runMedicalAi("summarize", input.text, input.language);
    logEvent("medicalSummarize.done", { user: anon(caller.uid), chars: input.text.length, lang: input.language, notices: out.safetyNotices.length });
    return out;
  });
});

const TranscribeInput = z.object({
  recordingId: z.string().regex(/^[A-Za-z0-9]{10,40}$/),
  language: z.enum(languages).default("en"),
});

const MAX_AUDIO_BYTES = 25 * 1024 * 1024;

/**
 * POST /api/medical/transcribe
 * Transcribes a consented recording owned by the caller. The transcript is
 * returned for review/correction; it is stored on the recording doc (deleted
 * with the recording). If transcription fails, the app says so and never
 * pretends the audio was analysed.
 */
export const medicalTranscribe = onCall(
  { ...callableOptions, timeoutSeconds: 300, memory: "1GiB", secrets: [STT_API_KEY] },
  async (req) => {
    const caller = requireAuth(req);
    return guarded("medicalTranscribe", caller.uid, async () => {
      const input = parse(TranscribeInput, req.data);
      await requireMedicalConsent(caller.uid);
      const ref = db.doc(`recordings/${input.recordingId}`);
      const snap = await ref.get();
      if (!snap.exists || snap.get("userId") !== caller.uid || snap.get("deletionStatus") !== "active") {
        throw new HttpsError("not-found", "Recording not found.");
      }
      if (!snap.get("consentReference")) {
        throw new HttpsError("failed-precondition", "This recording has no recorded consent and cannot be processed.");
      }
      const existing = snap.get("transcript");
      if (typeof existing === "string" && existing.length > 0) return { transcript: existing, cached: true };

      await enforceRateLimit(caller.uid, "medicalTranscribe");
      const path = String(snap.get("storageReference"));
      if (!path.startsWith(`recordings/${caller.uid}/`)) throw new HttpsError("permission-denied", "You don't have permission to do that.");

      const file = storage.bucket().file(path);
      const [meta] = await file.getMetadata();
      if (Number(meta.size ?? 0) > MAX_AUDIO_BYTES) throw new HttpsError("invalid-argument", "This recording is too long to transcribe.");
      const [audio] = await file.download();

      await ref.update({ transcriptionStatus: "processing" });
      let transcript = "";
      try {
        transcript = await transcribeAudio(audio, `${input.recordingId}.m4a`, input.language);
      } catch (e) {
        await ref.update({ transcriptionStatus: "failed" });
        throw e;
      }
      if (!transcript) {
        await ref.update({ transcriptionStatus: "empty" });
        throw new HttpsError("failed-precondition", "No speech could be recognised in this recording.");
      }
      await ref.update({ transcript, transcriptionStatus: "done", transcribedAt: FieldValue.serverTimestamp() });
      logEvent("medicalTranscribe.done", { user: anon(caller.uid), bytes: audio.length, chars: transcript.length });
      return { transcript, cached: false };
    });
  },
);
