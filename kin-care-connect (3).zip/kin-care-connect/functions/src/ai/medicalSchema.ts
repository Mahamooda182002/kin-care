import { z } from "zod";

/** Structured output the model must return for explain/summarize. */
export const MedicalOutputSchema = z.object({
  summary: z.string().max(3000).default(""),
  terms: z
    .array(
      z.object({
        term: z.string().min(1).max(120),
        simpleExplanation: z.string().min(1).max(800),
        whatItMeans: z.string().max(800).default(""),
      }),
    )
    .max(25)
    .default([]),
  abbreviations: z
    .array(z.object({ abbreviation: z.string().min(1).max(30), meaning: z.string().min(1).max(300) }))
    .max(30)
    .default([]),
  fromYourText: z
    .object({
      instructions: z.array(z.string().max(500)).max(30).default([]),
      dates: z.array(z.object({ date: z.string().max(60), description: z.string().max(300) })).max(20).default([]),
    })
    .default({ instructions: [], dates: [] }),
  followUpActions: z.array(z.string().max(400)).max(20).default([]),
  questionsForDoctor: z.array(z.string().max(300)).max(15).default([]),
  uncertainties: z.array(z.string().max(400)).max(15).default([]),
  language: z.string().max(10).default("en"),
});

export type MedicalOutput = z.infer<typeof MedicalOutputSchema> & {
  safetyNotices: string[];
  disclaimer: string;
};

export const MEDICAL_DISCLAIMER =
  "This explanation is for understanding only. It is not a diagnosis or medical advice. " +
  "Do not start, stop or change any medicine or dose without talking to your doctor or pharmacist.";
