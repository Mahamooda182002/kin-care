import { defineSecret, defineString } from "firebase-functions/params";
import { HttpsError } from "firebase-functions/v2/https";

/**
 * Server-side AI integration. Keys live ONLY in Google Secret Manager via
 * Firebase params and are never sent to, or stored in, the Android app.
 *
 *   firebase functions:secrets:set AI_API_KEY
 *   firebase functions:secrets:set STT_API_KEY
 *
 * Any OpenAI-compatible endpoint works (OpenAI, Azure OpenAI, Groq, a
 * self-hosted gateway…). Configure base URL / model in functions/.env:
 *   AI_BASE_URL=https://api.openai.com/v1
 *   AI_MODEL=gpt-4o-mini
 *   STT_BASE_URL=https://api.openai.com/v1
 *   STT_MODEL=whisper-1
 * Choose a provider/plan that does not train on your data and supports the
 * data-processing terms you need for health information.
 */
export const AI_API_KEY = defineSecret("AI_API_KEY");
export const STT_API_KEY = defineSecret("STT_API_KEY");
export const AI_BASE_URL = defineString("AI_BASE_URL", { default: "https://api.openai.com/v1" });
export const AI_MODEL = defineString("AI_MODEL", { default: "gpt-4o-mini" });
export const STT_BASE_URL = defineString("STT_BASE_URL", { default: "https://api.openai.com/v1" });
export const STT_MODEL = defineString("STT_MODEL", { default: "whisper-1" });

const unavailable = () =>
  new HttpsError("unavailable", "The AI service is not available right now. Please try again later.");

function key(secret: typeof AI_API_KEY): string {
  let v = "";
  try {
    v = secret.value();
  } catch {
    v = "";
  }
  if (!v) {
    throw new HttpsError("failed-precondition", "The AI service has not been set up yet. Ask the app administrator to configure it.");
  }
  return v;
}

async function fetchWithTimeout(url: string, init: RequestInit, ms: number): Promise<Response> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal });
  } catch {
    throw unavailable();
  } finally {
    clearTimeout(t);
  }
}

/**
 * Calls a chat-completions endpoint in JSON mode and returns the parsed JSON
 * object. The caller MUST validate the result with a schema.
 */
export async function chatJson(system: string, user: string, opts: { maxTokens?: number; temperature?: number } = {}): Promise<unknown> {
  const res = await fetchWithTimeout(
    `${AI_BASE_URL.value().replace(/\/$/, "")}/chat/completions`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key(AI_API_KEY)}` },
      body: JSON.stringify({
        model: AI_MODEL.value(),
        temperature: opts.temperature ?? 0.2,
        max_tokens: opts.maxTokens ?? 1800,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: system },
          { role: "user", content: user },
        ],
      }),
    },
    45_000,
  );
  if (res.status === 429) throw new HttpsError("resource-exhausted", "The AI service is busy. Please try again in a minute.");
  if (!res.ok) throw unavailable();
  const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  const content = body.choices?.[0]?.message?.content;
  if (!content) throw unavailable();
  try {
    return JSON.parse(content);
  } catch {
    throw new HttpsError("internal", "The AI response could not be understood. Please try again.");
  }
}

/** Speech-to-text (OpenAI-compatible /audio/transcriptions). */
export async function transcribeAudio(audio: Buffer, fileName: string, language?: string): Promise<string> {
  const form = new FormData();
  form.append("file", new Blob([new Uint8Array(audio)], { type: "audio/mp4" }), fileName);
  form.append("model", STT_MODEL.value());
  form.append("response_format", "json");
  if (language) form.append("language", language);
  const res = await fetchWithTimeout(
    `${STT_BASE_URL.value().replace(/\/$/, "")}/audio/transcriptions`,
    { method: "POST", headers: { Authorization: `Bearer ${key(STT_API_KEY)}` }, body: form },
    240_000,
  );
  if (res.status === 429) throw new HttpsError("resource-exhausted", "The speech service is busy. Please try again in a minute.");
  if (!res.ok) throw new HttpsError("unavailable", "The recording could not be transcribed right now. Please try again later.");
  const body = (await res.json()) as { text?: string };
  return (body.text ?? "").trim();
}
