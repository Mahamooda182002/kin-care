/**
 * Post-generation medical safety guardrails. The model is instructed not to
 * diagnose or give dosing advice; these checks enforce it regardless.
 * Pure functions (no Firebase) so they are unit-tested.
 */

const DOSE_CHANGE = [
  /\b(increase|decrease|reduce|raise|lower|double|halve|adjust|change)\s+(your|the|this)?\s*(dose|dosage|medicine|medication|tablets?|pills?|insulin)\b/i,
  /\b(stop|start|skip|discontinue|quit)\s+(taking\s+)?(your|the|this)?\s*(medicine|medication|tablets?|pills?|insulin|dose)\b/i,
  /\byou\s+(should|can|could|may)\s+(take|use)\s+\d+(\.\d+)?\s*(mg|mcg|g|ml|units?|tablets?|pills?)\b/i,
  /\btake\s+(an?\s+)?(extra|additional|more|less|fewer)\b/i,
];

const DIAGNOSIS = [
  /\byou\s+(have|probably have|likely have|are suffering from|are diagnosed with|must have)\b/i,
  /\b(this|it)\s+(means|indicates|confirms|shows)\s+(that\s+)?you\s+(have|are)\b/i,
  /\bmy diagnosis\b/i,
  /\bI\s+diagnose\b/i,
];

const PRESCRIBE = [/\b(I|we)\s+(recommend|suggest|prescribe)\s+(taking|you take|starting)\b/i, /\byou\s+should\s+(start|try)\s+taking\b/i];

export const SAFE_REPLACEMENT =
  "[Removed: Kin Care Connect cannot give advice about diagnosing or changing medicines or doses. Please ask your doctor or pharmacist.]";

export interface GuardResult {
  text: string;
  flagged: boolean;
  reasons: Set<"dose" | "diagnosis" | "prescribe">;
}

/** Splits into sentences and replaces any unsafe sentence. */
export function sanitizeSentence(text: string): GuardResult {
  const reasons = new Set<"dose" | "diagnosis" | "prescribe">();
  if (!text) return { text, flagged: false, reasons };
  const parts = text.split(/(?<=[.!?।])\s+/);
  const out = parts.map((s) => {
    let bad = false;
    if (DOSE_CHANGE.some((r) => r.test(s))) { reasons.add("dose"); bad = true; }
    if (DIAGNOSIS.some((r) => r.test(s))) { reasons.add("diagnosis"); bad = true; }
    if (PRESCRIBE.some((r) => r.test(s))) { reasons.add("prescribe"); bad = true; }
    return bad ? SAFE_REPLACEMENT : s;
  });
  // Collapse repeated replacements.
  const joined = out.join(" ").replace(new RegExp(`(${escapeRe(SAFE_REPLACEMENT)}\\s*)+`, "g"), SAFE_REPLACEMENT + " ").trim();
  return { text: joined, flagged: reasons.size > 0, reasons };
}

function escapeRe(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/** Recursively sanitises every string in generated (non-verbatim) fields. */
export function sanitizeDeep<T>(value: T, reasons: Set<string>): T {
  if (typeof value === "string") {
    const r = sanitizeSentence(value);
    r.reasons.forEach((x) => reasons.add(x));
    return r.text as unknown as T;
  }
  if (Array.isArray(value)) return value.map((v) => sanitizeDeep(v, reasons)) as unknown as T;
  if (value && typeof value === "object") {
    const o: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) o[k] = sanitizeDeep(v, reasons);
    return o as T;
  }
  return value;
}

/** Detects when the USER is asking for dosing/diagnosis so we can add a notice. */
export function inputAsksForAdvice(text: string): boolean {
  return /\b(how (much|many)|what dose|should i (take|stop|increase|reduce)|can i (stop|skip|double)|do i have)\b/i.test(text);
}

export function safetyNoticesFor(reasons: Set<string>, asksAdvice: boolean): string[] {
  const notices: string[] = [];
  if (reasons.has("dose") || reasons.has("prescribe")) {
    notices.push("Some text was removed because it looked like advice about medicines or doses. Only your doctor or pharmacist can advise on that.");
  }
  if (reasons.has("diagnosis")) {
    notices.push("Some text was removed because it sounded like a diagnosis. This app explains words; it cannot diagnose.");
  }
  if (asksAdvice) {
    notices.push("Questions about how much medicine to take, or whether you have a condition, must be answered by your doctor or pharmacist.");
  }
  return notices;
}

/**
 * "From your text" items must actually come from the user's text. Items the
 * model may have invented (low word overlap) are dropped and reported as
 * uncertainties instead. This keeps facts and generated explanations apart.
 */
export function verifyExtracted(original: string, items: string[]): { kept: string[]; dropped: string[] } {
  const norm = (s: string) => s.toLowerCase().normalize("NFKC").replace(/[^\p{L}\p{N}\s]/gu, " ");
  const source = new Set(norm(original).split(/\s+/).filter((w) => w.length > 1));
  const kept: string[] = [];
  const dropped: string[] = [];
  for (const item of items) {
    const words = norm(item).split(/\s+/).filter((w) => w.length > 1);
    if (words.length === 0) continue;
    const hits = words.filter((w) => source.has(w)).length;
    (hits / words.length >= 0.6 ? kept : dropped).push(item);
  }
  return { kept, dropped };
}
