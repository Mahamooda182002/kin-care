/**
 * Mirror of lib/features/reminders/domain/repeat_rule.dart, evaluated in the
 * user's local time (offset in minutes) so "08:00 every day" stays 08:00.
 */
export type Frequency = "none" | "daily" | "weekly" | "monthly";
export interface RepeatRule { frequency: Frequency; interval: number; weekdays: number[] }

const DAY = 86_400_000;

/** Local wall-clock helpers: we shift by the offset and use UTC getters. */
function toLocal(ms: number, off: number): Date { return new Date(ms + off * 60_000); }
function fromLocal(d: Date, off: number): number { return d.getTime() - off * 60_000; }
function isoWeekday(d: Date): number { const w = d.getUTCDay(); return w === 0 ? 7 : w; }
function mondayOf(d: Date): number { return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() - (isoWeekday(d) - 1)); }

export function nextAfter(rule: RepeatRule, startMs: number, afterMs: number, offsetMinutes = 0): number | null {
  if (rule.frequency === "none") return null;
  const step = Math.max(1, Math.floor(rule.interval || 1));
  const s = toLocal(startMs, offsetMinutes);
  const a = toLocal(afterMs, offsetMinutes);
  const h = s.getUTCHours(), mi = s.getUTCMinutes();

  if (rule.frequency === "daily") {
    if (s.getTime() > a.getTime()) return startMs;
    const days = Math.floor((a.getTime() - s.getTime()) / DAY);
    let n = Math.floor(days / step) * step;
    let c = new Date(Date.UTC(s.getUTCFullYear(), s.getUTCMonth(), s.getUTCDate() + n, h, mi));
    while (c.getTime() <= a.getTime()) { n += step; c = new Date(Date.UTC(s.getUTCFullYear(), s.getUTCMonth(), s.getUTCDate() + n, h, mi)); }
    return fromLocal(c, offsetMinutes);
  }

  if (rule.frequency === "weekly") {
    const days = rule.weekdays.length ? [...new Set(rule.weekdays)].sort() : [isoWeekday(s)];
    const startWeek = mondayOf(s);
    const cursor = a.getTime() < s.getTime() ? new Date(s.getTime() - DAY) : a;
    for (let i = 0; i < 7 * step * 2 + 8; i++) {
      const c = new Date(Date.UTC(cursor.getUTCFullYear(), cursor.getUTCMonth(), cursor.getUTCDate() + i, h, mi));
      if (c.getTime() <= a.getTime() || c.getTime() < s.getTime()) continue;
      const weeks = Math.round((mondayOf(c) - startWeek) / (7 * DAY));
      if (weeks % step === 0 && days.includes(isoWeekday(c))) return fromLocal(c, offsetMinutes);
    }
    return null;
  }

  // monthly, clamped to month end
  for (let n = 0; n < 1200; n++) {
    const total = s.getUTCMonth() + n * step;
    const y = s.getUTCFullYear() + Math.floor(total / 12);
    const m = total % 12;
    const last = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
    const c = new Date(Date.UTC(y, m, Math.min(s.getUTCDate(), last), h, mi));
    if (c.getTime() > a.getTime()) return fromLocal(c, offsetMinutes);
  }
  return null;
}
