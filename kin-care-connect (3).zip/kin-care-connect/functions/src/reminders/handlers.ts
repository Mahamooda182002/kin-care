import { HttpsError, onCall } from "firebase-functions/v2/https";
import { onSchedule } from "firebase-functions/v2/scheduler";
import { z } from "zod";
import { anon, callableOptions, db, FieldValue, guarded, logEvent, parse, REGION, requireAuth, Timestamp } from "../lib/core";
import { notifyUser } from "../lib/notify";
import { enforceRateLimit } from "../lib/rateLimit";

const DOSE_ADVICE = /\b(increase|decrease|double|halve|reduce)\b.{0,20}\b(dose|dosage)\b/i;

const Input = z.object({
  title: z.string().trim().min(1).max(80),
  reminderType: z.enum(["medicine", "appointment", "routine", "custom"]),
  startAt: z.string().datetime(),
  repeatRule: z.object({
    frequency: z.enum(["none", "daily", "weekly", "monthly"]),
    interval: z.number().int().min(1).max(365).default(1),
    weekdays: z.array(z.number().int().min(1).max(7)).max(7).default([]),
  }),
  notes: z.string().trim().max(300).optional(),
  profileId: z.string().regex(/^[A-Za-z0-9_-]{6,64}$/).optional(),
  timezoneOffsetMinutes: z.number().int().min(-840).max(840).default(0),
});

/**
 * POST /api/reminders
 * Validates and creates a reminder. For a care profile, the caller must be
 * the family admin or an assigned caregiver, and reminders sharing must be
 * consented. The app never generates dosage recommendations.
 */
export const remindersCreate = onCall(callableOptions, async (req) => {
  const caller = requireAuth(req);
  return guarded("remindersCreate", caller.uid, async () => {
    const input = parse(Input, req.data);
    await enforceRateLimit(caller.uid, "remindersCreate");
    if (DOSE_ADVICE.test(`${input.title} ${input.notes ?? ""}`)) {
      throw new HttpsError("invalid-argument", "Reminders can't include instructions to change doses. Enter the medicine as prescribed.");
    }

    let familyId: string | null = null;
    if (input.profileId) {
      const p = await db.doc(`careProfiles/${input.profileId}`).get();
      if (!p.exists) throw new HttpsError("not-found", "Profile not found.");
      familyId = String(p.get("familyId"));
      const m = await db.doc(`familyMembers/${familyId}_${caller.uid}`).get();
      const role = m.exists && m.get("invitationStatus") === "accepted" ? String(m.get("role")) : null;
      const isElder = p.get("linkedUserId") === caller.uid;
      const assigned = ((p.get("caregiverIds") as string[] | undefined) ?? []).includes(caller.uid);
      const canCare = role === "admin" || (role === "caregiver" && assigned);
      if (!isElder && !(canCare && p.get("sharingConsent.reminders") === true)) {
        throw new HttpsError("permission-denied", "You can't add reminders for this person yet. Reminder sharing must be approved and you must be an assigned caregiver.");
      }
    }

    const start = new Date(input.startAt);
    if (input.repeatRule.frequency === "none" && start.getTime() < Date.now() - 60_000) {
      throw new HttpsError("invalid-argument", "Please choose a time in the future.");
    }
    const ref = db.collection("reminders").doc();
    await ref.set({
      reminderId: ref.id,
      userId: caller.uid,
      profileId: input.profileId ?? null,
      familyId,
      title: input.title,
      reminderType: input.reminderType,
      schedule: { startAt: Timestamp.fromDate(start), timezoneOffsetMinutes: input.timezoneOffsetMinutes },
      repeatRule: input.repeatRule,
      nextDueAt: Timestamp.fromDate(start),
      completionStatus: "pending",
      notified: false,
      notes: input.notes ?? null,
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    });
    logEvent("remindersCreate.done", { user: anon(caller.uid), type: input.reminderType, shared: !!input.profileId });
    return { reminderId: ref.id };
  });
});

/**
 * Every 5 minutes: send notifications for reminders that are due and not yet
 * notified. Lock-screen text is generic unless the user opted in.
 */
export const dispatchDueReminders = onSchedule({ schedule: "every 5 minutes", region: REGION, timeZone: "Etc/UTC" }, async () => {
  const now = Timestamp.now();
  const due = await db.collection("reminders")
    .where("completionStatus", "==", "pending")
    .where("notified", "==", false)
    .where("nextDueAt", "<=", now)
    .limit(300)
    .get();

  for (const doc of due.docs) {
    const r = doc.data();
    const recipients = new Set<string>([String(r.userId)]);
    if (r.profileId) {
      const p = await db.doc(`careProfiles/${r.profileId}`).get();
      if (p.exists && p.get("linkedUserId")) recipients.add(String(p.get("linkedUserId")));
    }
    for (const uid of recipients) {
      await notifyUser(uid, "reminder", {
        title: `Reminder: ${String(r.title).slice(0, 60)}`,
        message: "It's time for your care reminder. Open Kin Care Connect to mark it done or snooze.",
        link: r.profileId ? `/reminders?profileId=${r.profileId}` : "/reminders",
      }).catch(() => undefined);
    }
    await doc.ref.update({ notified: true, lastNotifiedAt: FieldValue.serverTimestamp() });
  }
  logEvent("dispatchDueReminders.done", { count: due.size });
});
