import { HttpsError, onCall } from "firebase-functions/v2/https";
import { z } from "zod";
import { callableOptions, db, guarded, parse, requireAuth, Timestamp } from "../lib/core";
import { enforceRateLimit } from "../lib/rateLimit";

const Input = z.object({
  profileId: z.string().regex(/^[A-Za-z0-9_-]{6,64}$/).optional(),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  timezoneOffsetMinutes: z.number().int().min(-840).max(840).default(0),
});

export const ACTIVITY_NOTE =
  "Counts app activity only while monitoring is on and the app is open. It is not a health or emergency signal; gaps are normal.";

/** Local-day window [start, end) in UTC for a YYYY-MM-DD date and offset. */
export function dayWindow(date: string, offsetMinutes: number): { start: Date; end: Date } {
  const [y, m, d] = date.split("-").map(Number);
  const startUtc = Date.UTC(y, m - 1, d) - offsetMinutes * 60_000;
  return { start: new Date(startUtc), end: new Date(startUtc + 24 * 3600_000) };
}

/**
 * GET /api/activity/summary
 * Own activity, or a care profile's shared activity when the caller is a
 * family member AND the profile has activity-sharing consent.
 */
export const activitySummary = onCall(callableOptions, async (req) => {
  const caller = requireAuth(req);
  return guarded("activitySummary", caller.uid, async () => {
    const input = parse(Input, req.data);
    await enforceRateLimit(caller.uid, "activitySummary");
    const { start, end } = dayWindow(input.date, input.timezoneOffsetMinutes);

    let q: FirebaseFirestore.Query = db.collection("activityRecords");
    if (input.profileId) {
      const p = await db.doc(`careProfiles/${input.profileId}`).get();
      if (!p.exists) throw new HttpsError("not-found", "Profile not found.");
      const familyId = String(p.get("familyId"));
      const m = await db.doc(`familyMembers/${familyId}_${caller.uid}`).get();
      const isElder = p.get("linkedUserId") === caller.uid;
      const isMember = m.exists && m.get("invitationStatus") === "accepted";
      if (!isElder && !(isMember && p.get("sharingConsent.activity") === true)) {
        throw new HttpsError("permission-denied", "Activity for this person has not been shared with you.");
      }
      q = q.where("profileId", "==", input.profileId).where("familyId", "==", familyId);
    } else {
      q = q.where("userId", "==", caller.uid);
    }
    const snap = await q
      .where("timestamp", ">=", Timestamp.fromDate(start))
      .where("timestamp", "<", Timestamp.fromDate(end))
      .orderBy("timestamp", "desc")
      .limit(1000)
      .get();

    const counts: Record<string, number> = {};
    snap.docs.forEach((d) => {
      const t = String(d.get("activityType"));
      counts[t] = (counts[t] ?? 0) + 1;
    });
    const last = snap.docs[0];
    const userActivity = snap.docs.filter((d) => !["monitoringStarted", "monitoringStopped"].includes(String(d.get("activityType")))).length;
    return {
      date: input.date,
      counts,
      total: userActivity,
      lastActivityAt: last ? (last.get("timestamp") as Timestamp).toDate().toISOString() : null,
      lastActivityType: last ? String(last.get("activityType")) : null,
      note: ACTIVITY_NOTE,
    };
  });
});
