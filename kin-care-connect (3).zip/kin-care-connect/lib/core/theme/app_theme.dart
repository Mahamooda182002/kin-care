import 'package:flutter/material.dart';

/// Kin Care Connect design tokens: calm blue, teal, white and soft neutrals.
class KcColors {
  KcColors._();
  static const Color blue = Color(0xFF1F5FA8);
  static const Color teal = Color(0xFF138A8A);

  /// Darker teal for backgrounds behind white text (≥ 4.5:1).
  static const Color tealDeep = Color(0xFF0F7777);
  static const Color tealLight = Color(0xFFD7F0EF);
  static const Color blueLight = Color(0xFFE3EDF8);
  static const Color neutral = Color(0xFFF5F7FA);
  static const Color ink = Color(0xFF1B2733);
  static const Color riskLow = Color(0xFF2E7D32);
  static const Color riskMedium = Color(0xFFB26A00);
  static const Color riskHigh = Color(0xFFC62828);

  // Lighter risk colours for dark backgrounds (contrast ≥ 4.5:1, see
  // test/unit/contrast_test.dart).
  static const Color riskLowOnDark = Color(0xFF81C784);
  static const Color riskMediumOnDark = Color(0xFFFFB74D);
  static const Color riskHighOnDark = Color(0xFFEF9A9A);
}

class KcSpacing {
  KcSpacing._();
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 16;
  static const double lg = 24;
  static const double xl = 32;
  static const double radius = 20;

  /// Minimum touch target. Material recommends 48dp; we use 56 for elders.
  static const double touchTarget = 56;
}

class AppTheme {
  AppTheme._();

  static ThemeData light() => _build(Brightness.light);
  static ThemeData dark() => _build(Brightness.dark);

  /// High-contrast variants: used when the in-app "High contrast" option is
  /// on, and when Android's own high-contrast text setting is on.
  static ThemeData highContrastLight() =>
      _build(Brightness.light, highContrast: true);
  static ThemeData highContrastDark() =>
      _build(Brightness.dark, highContrast: true);

  /// The colour scheme for a theme variant (exposed for contrast tests).
  static ColorScheme scheme(Brightness brightness,
      {bool highContrast = false}) {
    final isDark = brightness == Brightness.dark;
    final base = ColorScheme.fromSeed(
      seedColor: KcColors.blue,
      secondary: KcColors.teal,
      brightness: brightness,
      contrastLevel: highContrast ? 1.0 : 0.0,
    );
    if (!highContrast) {
      return base.copyWith(
        surface: isDark ? const Color(0xFF121A22) : Colors.white,
      );
    }
    return base.copyWith(
      surface: isDark ? Colors.black : Colors.white,
      onSurface: isDark ? Colors.white : Colors.black,
      onSurfaceVariant: isDark ? Colors.white : Colors.black,
      outline: isDark ? Colors.white : Colors.black,
      outlineVariant: isDark ? Colors.white70 : Colors.black87,
    );
  }

  /// Body text colour on the scaffold background.
  static Color textColor(Brightness b, {bool highContrast = false}) =>
      b == Brightness.dark
          ? Colors.white
          : (highContrast ? Colors.black : KcColors.ink);

  static Color scaffoldColor(Brightness b, {bool highContrast = false}) {
    final isDark = b == Brightness.dark;
    if (highContrast) return isDark ? Colors.black : Colors.white;
    return isDark ? const Color(0xFF0C1218) : KcColors.neutral;
  }

  static ThemeData _build(Brightness brightness, {bool highContrast = false}) {
    final isDark = brightness == Brightness.dark;
    final scheme = AppTheme.scheme(brightness, highContrast: highContrast);
    // Visible focus indicator for keyboard, D-pad and switch access: a thick
    // outline on any focused button, on top of Material's focus overlay.
    final focusSide = WidgetStateProperty.resolveWith<BorderSide?>((states) =>
        states.contains(WidgetState.focused)
            ? BorderSide(color: scheme.onSurface, width: 3)
            : null);
    final focusColor =
        scheme.primary.withValues(alpha: highContrast ? 0.40 : 0.24);

    final base = ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      brightness: brightness,
      scaffoldBackgroundColor:
          scaffoldColor(brightness, highContrast: highContrast),
      focusColor: focusColor,
    );

    final ink = textColor(brightness, highContrast: highContrast);
    final text = base.textTheme.apply(bodyColor: ink, displayColor: ink);

    return base.copyWith(
      textTheme: text.copyWith(
        bodyLarge: text.bodyLarge?.copyWith(fontSize: 18, height: 1.45),
        bodyMedium: text.bodyMedium?.copyWith(fontSize: 16, height: 1.45),
        titleLarge: text.titleLarge?.copyWith(fontWeight: FontWeight.w700),
        titleMedium: text.titleMedium?.copyWith(fontWeight: FontWeight.w600),
        labelLarge: text.labelLarge?.copyWith(
          fontSize: 17,
          fontWeight: FontWeight.w600,
        ),
      ),
      appBarTheme: AppBarTheme(
        centerTitle: false,
        elevation: 0,
        scrolledUnderElevation: 1,
        backgroundColor: base.scaffoldBackgroundColor,
        foregroundColor: ink,
        titleTextStyle: text.titleLarge?.copyWith(fontWeight: FontWeight.w700),
      ),
      cardTheme: CardThemeData(
        elevation: 1.5,
        shadowColor: Colors.black.withValues(alpha: 0.08),
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(KcSpacing.radius),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(KcSpacing.touchTarget),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ).copyWith(side: focusSide),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size.fromHeight(KcSpacing.touchTarget),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ).copyWith(
          side: WidgetStateProperty.resolveWith((states) =>
              states.contains(WidgetState.focused)
                  ? BorderSide(color: scheme.onSurface, width: 3)
                  : BorderSide(
                      color: highContrast ? scheme.onSurface : scheme.outline)),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          minimumSize: const Size(KcSpacing.touchTarget, 48),
        ).copyWith(side: focusSide),
      ),
      iconButtonTheme: IconButtonThemeData(
        style: IconButton.styleFrom(minimumSize: const Size(48, 48))
            .copyWith(side: focusSide),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: isDark ? const Color(0xFF1A2530) : Colors.white,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(
              color: highContrast ? scheme.outline : scheme.outlineVariant),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: scheme.primary, width: 3),
        ),
      ),
      listTileTheme: const ListTileThemeData(
        minVerticalPadding: 12,
        contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      ),
      navigationBarTheme: NavigationBarThemeData(
        height: 72,
        labelTextStyle: WidgetStatePropertyAll(
          text.labelMedium?.copyWith(fontWeight: FontWeight.w600),
        ),
      ),
      snackBarTheme:
          const SnackBarThemeData(behavior: SnackBarBehavior.floating),
    );
  }
}
