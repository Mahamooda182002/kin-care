import 'dart:math' as math;
import 'dart:ui';

/// WCAG 2.x relative luminance of an opaque colour.
double relativeLuminance(Color c) {
  double ch(double v) =>
      v <= 0.03928 ? v / 12.92 : math.pow((v + 0.055) / 1.055, 2.4).toDouble();
  return 0.2126 * ch(c.r) + 0.7152 * ch(c.g) + 0.0722 * ch(c.b);
}

/// WCAG contrast ratio between two colours (1.0 – 21.0). Translucent
/// colours must be blended onto their background first (Color.alphaBlend).
double contrastRatio(Color a, Color b) {
  final la = relativeLuminance(a);
  final lb = relativeLuminance(b);
  final hi = math.max(la, lb);
  final lo = math.min(la, lb);
  return (hi + 0.05) / (lo + 0.05);
}

/// Returns [fg], or the nearest shade of it (towards black on light
/// backgrounds, towards white on dark ones) that reaches [minRatio] against
/// [bg]. Keeps colour-coded text (risk levels, status chips) readable in
/// light, dark and high-contrast themes.
Color ensureContrast(Color fg, Color bg, {double minRatio = 4.5}) {
  if (contrastRatio(fg, bg) >= minRatio) return fg;
  final target = relativeLuminance(bg) > 0.18
      ? const Color(0xFF000000)
      : const Color(0xFFFFFFFF);
  for (var t = 0.05; t <= 1.0; t += 0.05) {
    final c = Color.lerp(fg, target, t)!;
    if (contrastRatio(c, bg) >= minRatio) return c;
  }
  return target;
}
