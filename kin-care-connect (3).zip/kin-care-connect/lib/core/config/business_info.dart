/// Business and legal-contact details shown in the legal texts, the
/// About & Contact screen and the store listing.
///
/// ┌──────────────────────────────────────────────────────────────────────┐
/// │ OWNER ACTION REQUIRED BEFORE RELEASE                                 │
/// │ Every value that starts with `YOUR_` is a placeholder. Replace each  │
/// │ one with your real details, then run                                 │
/// │   dart run tool/export_legal.dart                                    │
/// │ to regenerate docs/legal/*.md so the public copies match the app.    │
/// │ `test/unit/legal_texts_test.dart` fails if the copies drift.         │
/// └──────────────────────────────────────────────────────────────────────┘
///
/// This file is plain Dart (no Flutter imports) so the export tool and tests
/// can read it. Nothing here is secret.
class BusinessInfo {
  BusinessInfo._();

  /// Name shown to users.
  static const String appName = 'Kin Care Connect';

  /// Trading / brand name of the operator.
  static const String companyName = 'YOUR_COMPANY_NAME';

  /// Registered legal entity (e.g. "Example Care Technologies Private
  /// Limited", CIN U00000XX0000PTC000000) or the individual operator's name.
  static const String legalEntity = 'YOUR_LEGAL_ENTITY_NAME_AND_REGISTRATION';

  /// Registered postal address (required for the grievance section).
  static const String postalAddress = 'YOUR_REGISTERED_POSTAL_ADDRESS';

  /// Where users write for help, data requests and account deletion.
  static const String supportEmail = 'YOUR_SUPPORT_EMAIL';

  /// Public website (also used for the public privacy-policy URL that
  /// Google Play requires).
  static const String website = 'YOUR_WEBSITE_URL';

  /// Public URL where docs/legal/privacy-policy.md is published.
  static const String privacyPolicyUrl = 'YOUR_PUBLIC_PRIVACY_POLICY_URL';

  /// Grievance Officer (DPDP Act 2023 / DPDP Rules) — a named person.
  static const String grievanceOfficerName = 'YOUR_GRIEVANCE_OFFICER_NAME';
  static const String grievanceOfficerEmail = 'YOUR_GRIEVANCE_OFFICER_EMAIL';

  /// How quickly you commit to answering a grievance. Confirm with your
  /// lawyer against the DPDP Rules in force when you launch.
  static const String grievanceResponseTime = 'YOUR_GRIEVANCE_RESPONSE_TIME';

  /// Jurisdiction for the Terms (courts / governing law).
  static const String governingLawCity = 'YOUR_CITY_FOR_JURISDICTION';

  /// The AI language / speech-to-text provider you configured in
  /// functions/.env (AI_BASE_URL, STT_BASE_URL), and where it processes data.
  /// Named in the Privacy Policy because health text and audio go to it when
  /// a user turns AI on.
  static const String aiProviderName = 'YOUR_AI_PROVIDER_NAME';
  static const String aiProviderLocation =
      'YOUR_AI_PROVIDER_PROCESSING_COUNTRY';

  /// Firestore / Storage location chosen when you created the Firebase
  /// project (README recommends asia-south1, Mumbai, for users in India).
  static const String dataLocation = 'YOUR_FIREBASE_DATA_LOCATION';

  /// True while any placeholder above is still unfilled. The About screen
  /// shows a visible warning so an unconfigured build is never mistaken for
  /// a finished one.
  static bool get hasPlaceholders => placeholderValues.isNotEmpty;

  static List<String> get placeholderValues => [
        companyName,
        legalEntity,
        postalAddress,
        supportEmail,
        website,
        privacyPolicyUrl,
        grievanceOfficerName,
        grievanceOfficerEmail,
        grievanceResponseTime,
        governingLawCity,
        aiProviderName,
        aiProviderLocation,
        dataLocation,
      ].where((v) => v.startsWith('YOUR_')).toList();
}
