/// Build-time configuration. Pass values with --dart-define, e.g.
///   flutter run --dart-define=USE_EMULATORS=true --dart-define=EMULATOR_HOST=10.0.2.2
///
/// Nothing here is secret. API keys for AI and speech services live ONLY in
/// Cloud Functions secrets (see README → "Set backend secrets").
class AppConfig {
  AppConfig._();

  static const bool useEmulators = bool.fromEnvironment('USE_EMULATORS');
  static const String emulatorHost =
      String.fromEnvironment('EMULATOR_HOST', defaultValue: '10.0.2.2');
  static const String functionsRegion =
      String.fromEnvironment('FUNCTIONS_REGION', defaultValue: 'asia-south1');

  // Business and contact details (support email, grievance officer, ...)
  // live in business_info.dart.
  static const String appVersion = '1.0.0';
}
