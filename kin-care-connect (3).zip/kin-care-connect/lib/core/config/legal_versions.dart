/// Versions of the legal texts and of the first-run privacy-choices notice.
///
/// Bump a version whenever the matching text changes materially. The version
/// accepted by each user is stored with a server timestamp in
/// `users/{uid}.consents` (Terms + Privacy) and on the device with the
/// privacy choices, so you can prove which text someone agreed to.
class LegalVersions {
  LegalVersions._();

  /// Terms of Service.
  static const String terms = '2026-11-03';

  /// Privacy Policy (also covers the Cookie & Local Storage Policy).
  static const String privacy = '2026-11-03';

  /// First-run "Privacy choices" notice (local storage, notifications, AI).
  static const String privacyChoices = '2026-11-03';

  /// Human-readable date shown at the top of each document.
  static const String lastUpdated = '3 November 2026';

  /// Minimum age to create an account.
  static const int minimumAge = 18;
}
