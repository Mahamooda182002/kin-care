import 'package:flutter/material.dart';

import '../utils/app_exception.dart';

/// Clear yes/no confirmation. Returns true only on explicit confirmation.
///
/// Set [equalWeight] for consent questions (AI processing, lock-screen
/// details): both answers then use the same button style and size, so
/// declining is as easy to see and tap as agreeing.
Future<bool> showConfirmDialog(
  BuildContext context, {
  required String title,
  required String message,
  String confirmLabel = 'Confirm',
  String cancelLabel = 'Cancel',
  bool destructive = false,
  bool equalWeight = false,
}) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (ctx) {
      final scheme = Theme.of(ctx).colorScheme;
      if (equalWeight) {
        final style =
            OutlinedButton.styleFrom(minimumSize: const Size(120, 48));
        return AlertDialog(
          title: Text(title),
          content: SingleChildScrollView(child: Text(message)),
          actionsAlignment: MainAxisAlignment.spaceEvenly,
          actions: [
            OutlinedButton(
                style: style,
                onPressed: () => Navigator.pop(ctx, false),
                child: Text(cancelLabel)),
            OutlinedButton(
                style: style,
                onPressed: () => Navigator.pop(ctx, true),
                child: Text(confirmLabel)),
          ],
        );
      }
      return AlertDialog(
        title: Text(title),
        content: SingleChildScrollView(child: Text(message)),
        actions: [
          TextButton(
              style: TextButton.styleFrom(minimumSize: const Size(64, 48)),
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(cancelLabel)),
          FilledButton(
            style: destructive
                ? FilledButton.styleFrom(
                    backgroundColor: scheme.error,
                    foregroundColor: scheme.onError,
                    minimumSize: const Size(100, 48),
                  )
                : FilledButton.styleFrom(minimumSize: const Size(100, 48)),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(confirmLabel),
          ),
        ],
      );
    },
  );
  return result ?? false;
}

void showSnack(BuildContext context, String message, {bool error = false}) {
  final scheme = Theme.of(context).colorScheme;
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(message),
      backgroundColor: error ? scheme.error : null,
    ));
}

/// Runs [action] and shows a snack bar for any error. Returns null on error.
Future<T?> runGuarded<T>(BuildContext context, Future<T> Function() action,
    {String? success}) async {
  try {
    final r = await action();
    if (success != null && context.mounted) showSnack(context, success);
    return r;
  } catch (e) {
    if (context.mounted) {
      showSnack(context, AppException.from(e).message, error: true);
    }
    return null;
  }
}
