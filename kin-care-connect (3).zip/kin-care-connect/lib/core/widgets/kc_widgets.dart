import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../theme/contrast.dart';

/// Primary call-to-action button with a built-in loading state.
class KcButton extends StatelessWidget {
  const KcButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.loading = false,
    this.variant = KcButtonVariant.filled,
    this.semanticsHint,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool loading;
  final KcButtonVariant variant;
  final String? semanticsHint;

  @override
  Widget build(BuildContext context) {
    final child = loading
        ? const SizedBox(
            height: 24,
            width: 24,
            child: CircularProgressIndicator(strokeWidth: 2.5),
          )
        : Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (icon != null) ...[Icon(icon), const SizedBox(width: 10)],
              Flexible(child: Text(label, textAlign: TextAlign.center)),
            ],
          );
    final pressed = loading ? null : onPressed;
    final Widget button;
    switch (variant) {
      case KcButtonVariant.filled:
        button = FilledButton(onPressed: pressed, child: child);
      case KcButtonVariant.tonal:
        button = FilledButton.tonal(onPressed: pressed, child: child);
      case KcButtonVariant.outlined:
        button = OutlinedButton(onPressed: pressed, child: child);
      case KcButtonVariant.danger:
        button = FilledButton(
          style: FilledButton.styleFrom(
            backgroundColor: Theme.of(context).colorScheme.error,
            foregroundColor: Theme.of(context).colorScheme.onError,
          ),
          onPressed: pressed,
          child: child,
        );
    }
    return Semantics(
      button: true,
      label: loading ? '$label, loading' : label,
      hint: semanticsHint,
      excludeSemantics: true,
      child: button,
    );
  }
}

enum KcButtonVariant { filled, tonal, outlined, danger }

/// Rounded card used throughout the app.
class KcCard extends StatelessWidget {
  const KcCard({
    super.key,
    required this.child,
    this.onTap,
    this.padding = const EdgeInsets.all(KcSpacing.md),
    this.color,
    this.semanticLabel,
  });

  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry padding;
  final Color? color;
  final String? semanticLabel;

  @override
  Widget build(BuildContext context) {
    final card = Card(
      color: color,
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(padding: padding, child: child),
      ),
    );
    if (semanticLabel == null) return card;
    return Semantics(
      label: semanticLabel,
      button: onTap != null,
      child: card,
    );
  }
}

/// Feature tile for the dashboard grid.
class KcFeatureCard extends StatelessWidget {
  const KcFeatureCard({
    super.key,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.onTap,
    this.accent,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;
  final Color? accent;

  @override
  Widget build(BuildContext context) {
    final color = accent ?? Theme.of(context).colorScheme.primary;
    return KcCard(
      onTap: onTap,
      semanticLabel: '$title. $subtitle',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: color, size: 28),
          ),
          const SizedBox(height: 12),
          Text(title, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: Theme.of(context).textTheme.bodySmall,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

class KcSectionHeader extends StatelessWidget {
  const KcSectionHeader(this.title, {super.key, this.action});
  final String title;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: KcSpacing.lg, bottom: KcSpacing.sm),
      child: Row(
        children: [
          Expanded(
            child: Semantics(
              header: true,
              child:
                  Text(title, style: Theme.of(context).textTheme.titleMedium),
            ),
          ),
          if (action != null) action!,
        ],
      ),
    );
  }
}

/// Labeled text field with consistent styling.
class KcTextField extends StatelessWidget {
  const KcTextField({
    super.key,
    required this.label,
    this.controller,
    this.validator,
    this.keyboardType,
    this.obscure = false,
    this.maxLines = 1,
    this.minLines,
    this.hint,
    this.textInputAction,
    this.autofillHints,
    this.onChanged,
    this.prefixIcon,
    this.suffix,
    this.maxLength,
    this.enabled = true,
  });

  final String label;
  final TextEditingController? controller;
  final String? Function(String?)? validator;
  final TextInputType? keyboardType;
  final bool obscure;
  final int maxLines;
  final int? minLines;
  final String? hint;
  final TextInputAction? textInputAction;
  final Iterable<String>? autofillHints;
  final ValueChanged<String>? onChanged;
  final IconData? prefixIcon;
  final Widget? suffix;
  final int? maxLength;
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      validator: validator,
      keyboardType: keyboardType,
      obscureText: obscure,
      maxLines: obscure ? 1 : maxLines,
      minLines: minLines,
      textInputAction: textInputAction,
      autofillHints: autofillHints,
      onChanged: onChanged,
      maxLength: maxLength,
      enabled: enabled,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: prefixIcon == null ? null : Icon(prefixIcon),
        suffixIcon: suffix,
        alignLabelWithHint: maxLines > 1,
      ),
    );
  }
}

/// Password field with show/hide toggle.
class KcPasswordField extends StatefulWidget {
  const KcPasswordField({
    super.key,
    required this.label,
    required this.controller,
    this.validator,
    this.textInputAction,
    this.autofillHints = const [AutofillHints.password],
  });
  final String label;
  final TextEditingController controller;
  final String? Function(String?)? validator;
  final TextInputAction? textInputAction;
  final Iterable<String> autofillHints;

  @override
  State<KcPasswordField> createState() => _KcPasswordFieldState();
}

class _KcPasswordFieldState extends State<KcPasswordField> {
  bool _hidden = true;

  @override
  Widget build(BuildContext context) {
    return KcTextField(
      label: widget.label,
      controller: widget.controller,
      validator: widget.validator,
      obscure: _hidden,
      prefixIcon: Icons.lock_outline,
      textInputAction: widget.textInputAction,
      autofillHints: widget.autofillHints,
      suffix: IconButton(
        tooltip: _hidden ? 'Show password' : 'Hide password',
        icon: Icon(_hidden
            ? Icons.visibility_outlined
            : Icons.visibility_off_outlined),
        onPressed: () => setState(() => _hidden = !_hidden),
      ),
    );
  }
}

/// Full-area loading indicator with optional message.
class KcLoading extends StatelessWidget {
  const KcLoading({super.key, this.message});
  final String? message;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Semantics(
        liveRegion: true,
        label: message ?? 'Loading',
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(),
            if (message != null) ...[
              const SizedBox(height: 16),
              Text(message!, textAlign: TextAlign.center),
            ],
          ],
        ),
      ),
    );
  }
}

class KcErrorView extends StatelessWidget {
  const KcErrorView({super.key, required this.message, this.onRetry});
  final String message;
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(KcSpacing.lg),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.error_outline,
                size: 48, color: Theme.of(context).colorScheme.error),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center),
            if (onRetry != null) ...[
              const SizedBox(height: 16),
              SizedBox(
                width: 200,
                child: KcButton(
                    label: 'Try again',
                    onPressed: onRetry,
                    variant: KcButtonVariant.tonal),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class KcEmptyView extends StatelessWidget {
  const KcEmptyView(
      {super.key,
      required this.icon,
      required this.title,
      this.message,
      this.action});
  final IconData icon;
  final String title;
  final String? message;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(KcSpacing.lg),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 56, color: Theme.of(context).colorScheme.outline),
            const SizedBox(height: 12),
            Text(title,
                style: Theme.of(context).textTheme.titleMedium,
                textAlign: TextAlign.center),
            if (message != null) ...[
              const SizedBox(height: 6),
              Text(message!, textAlign: TextAlign.center),
            ],
            if (action != null) ...[const SizedBox(height: 16), action!],
          ],
        ),
      ),
    );
  }
}

/// Highlighted info / safety notice.
class KcNotice extends StatelessWidget {
  const KcNotice(
      {super.key,
      required this.text,
      this.icon = Icons.info_outline,
      this.tone = KcNoticeTone.info});
  final String text;
  final IconData icon;
  final KcNoticeTone tone;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final (bg, fg) = switch (tone) {
      KcNoticeTone.info => (scheme.primaryContainer, scheme.onPrimaryContainer),
      KcNoticeTone.warning => (
          scheme.tertiaryContainer,
          scheme.onTertiaryContainer
        ),
      KcNoticeTone.danger => (scheme.errorContainer, scheme.onErrorContainer),
    };
    return Semantics(
      container: true,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration:
            BoxDecoration(color: bg, borderRadius: BorderRadius.circular(16)),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: fg),
            const SizedBox(width: 12),
            Expanded(child: Text(text, style: TextStyle(color: fg))),
          ],
        ),
      ),
    );
  }
}

enum KcNoticeTone { info, warning, danger }

/// Small pill label (e.g. risk level, role).
class KcChip extends StatelessWidget {
  const KcChip(this.label, {super.key, this.color});
  final String label;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final c = color ?? theme.colorScheme.primary;
    final bg = c.withValues(alpha: 0.12);
    // Text colour adjusted so it stays ≥ 4.5:1 on the tinted background in
    // every theme (light, dark, high contrast).
    final fg =
        ensureContrast(c, Color.alphaBlend(bg, theme.colorScheme.surface));
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
      ),
      child:
          Text(label, style: TextStyle(color: fg, fontWeight: FontWeight.w700)),
    );
  }
}
