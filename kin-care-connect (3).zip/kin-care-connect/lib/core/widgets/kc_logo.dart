import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// Vector logo: two overlapping hands-as-hearts forming a shield.
/// Drawn in code so no image asset is required.
class KcLogo extends StatelessWidget {
  const KcLogo({super.key, this.size = 72, this.onDark = false});
  final double size;
  final bool onDark;

  @override
  Widget build(BuildContext context) {
    return ExcludeSemantics(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: onDark ? Colors.white : KcColors.blueLight,
          borderRadius: BorderRadius.circular(size * 0.28),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withValues(alpha: 0.12),
                blurRadius: size * 0.2,
                offset: Offset(0, size * 0.06)),
          ],
        ),
        child: CustomPaint(painter: _LogoPainter()),
      ),
    );
  }
}

class _LogoPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size s) {
    final w = s.width;
    final shield = Path()
      ..moveTo(w * 0.5, w * 0.18)
      ..cubicTo(w * 0.62, w * 0.26, w * 0.74, w * 0.28, w * 0.8, w * 0.28)
      ..cubicTo(w * 0.8, w * 0.56, w * 0.7, w * 0.72, w * 0.5, w * 0.84)
      ..cubicTo(w * 0.3, w * 0.72, w * 0.2, w * 0.56, w * 0.2, w * 0.28)
      ..cubicTo(w * 0.26, w * 0.28, w * 0.38, w * 0.26, w * 0.5, w * 0.18)
      ..close();
    canvas.drawPath(shield, Paint()..color = KcColors.blue);

    final heart = Path()
      ..moveTo(w * 0.5, w * 0.66)
      ..cubicTo(w * 0.34, w * 0.56, w * 0.32, w * 0.42, w * 0.42, w * 0.39)
      ..cubicTo(w * 0.46, w * 0.38, w * 0.49, w * 0.41, w * 0.5, w * 0.44)
      ..cubicTo(w * 0.51, w * 0.41, w * 0.54, w * 0.38, w * 0.58, w * 0.39)
      ..cubicTo(w * 0.68, w * 0.42, w * 0.66, w * 0.56, w * 0.5, w * 0.66)
      ..close();
    canvas.drawPath(heart, Paint()..color = KcColors.tealLight);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
