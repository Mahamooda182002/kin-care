import 'package:intl/intl.dart';

class Fmt {
  Fmt._();
  static String date(DateTime d) => DateFormat.yMMMd().format(d);
  static String time(DateTime d) => DateFormat.jm().format(d);
  static String dateTime(DateTime d) =>
      DateFormat('MMM d, y • h:mm a').format(d);

  static String relative(DateTime d, {DateTime? now}) {
    final n = now ?? DateTime.now();
    final diff = n.difference(d);
    if (diff.isNegative) {
      final ahead = d.difference(n);
      if (ahead.inMinutes < 60) return 'in ${ahead.inMinutes} min';
      if (ahead.inHours < 24) return 'in ${ahead.inHours} h';
      return date(d);
    }
    if (diff.inMinutes < 1) return 'just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes} min ago';
    if (diff.inHours < 24) return '${diff.inHours} h ago';
    if (diff.inDays < 7) return '${diff.inDays} d ago';
    return date(d);
  }

  static String greeting({DateTime? now}) {
    final h = (now ?? DateTime.now()).hour;
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  }
}
