/// Pure validation helpers used by forms. Return `null` when valid,
/// otherwise a short, plain-language error message.
class Validators {
  Validators._();

  static final RegExp _email =
      RegExp(r"^[A-Za-z0-9._%+\-']+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$");
  static final RegExp _phone = RegExp(r'^\+?[0-9 ()\-]{7,20}$');

  static String? required(String? v, {String field = 'This field'}) {
    if (v == null || v.trim().isEmpty) return '$field is required.';
    return null;
  }

  static String? fullName(String? v) {
    final r = required(v, field: 'Full name');
    if (r != null) return r;
    if (v!.trim().length < 2) return 'Please enter your full name.';
    if (v.trim().length > 80) return 'Name must be 80 characters or fewer.';
    return null;
  }

  static String? email(String? v) {
    final r = required(v, field: 'Email');
    if (r != null) return r;
    if (!_email.hasMatch(v!.trim())) {
      return 'Please enter a valid email address.';
    }
    return null;
  }

  /// At least 8 characters with a letter and a number.
  static String? password(String? v) {
    if (v == null || v.isEmpty) return 'Password is required.';
    if (v.length < 8) return 'Use at least 8 characters.';
    if (v.length > 128) return 'Password is too long.';
    if (!RegExp(r'[A-Za-z]').hasMatch(v) || !RegExp(r'[0-9]').hasMatch(v)) {
      return 'Use at least one letter and one number.';
    }
    return null;
  }

  static String? confirmPassword(String? v, String original) {
    if (v == null || v.isEmpty) return 'Please confirm your password.';
    if (v != original) return 'Passwords do not match.';
    return null;
  }

  /// Optional phone: empty is fine.
  static String? optionalPhone(String? v) {
    if (v == null || v.trim().isEmpty) return null;
    return phone(v);
  }

  static String? phone(String? v) {
    final r = required(v, field: 'Phone number');
    if (r != null) return r;
    final digits = v!.replaceAll(RegExp(r'\D'), '');
    if (!_phone.hasMatch(v.trim()) || digits.length < 7 || digits.length > 15) {
      return 'Please enter a valid phone number.';
    }
    return null;
  }

  static String? maxLength(String? v, int max, {String field = 'Text'}) {
    if (v != null && v.length > max) {
      return '$field must be $max characters or fewer.';
    }
    return null;
  }
}
