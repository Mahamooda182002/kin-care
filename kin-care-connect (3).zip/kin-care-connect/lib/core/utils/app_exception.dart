import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// A user-presentable error. [message] is always safe to show on screen.
class AppException implements Exception {
  const AppException(this.message, {this.code});
  final String message;
  final String? code;

  @override
  String toString() => message;

  /// Maps Firebase / platform errors to plain-language messages.
  static AppException from(Object error) {
    if (error is AppException) return error;
    if (error is FirebaseAuthException) {
      return AppException(_auth(error.code), code: error.code);
    }
    if (error is FirebaseFunctionsException) {
      return AppException(
        error.message?.isNotEmpty == true
            ? error.message!
            : _functions(error.code),
        code: error.code,
      );
    }
    if (error is FirebaseException) {
      if (error.code == 'permission-denied') {
        return const AppException(
          "You don't have permission to do that.",
          code: 'permission-denied',
        );
      }
      if (error.code == 'unavailable') {
        return const AppException(
          'The service is unavailable. Check your connection and try again.',
          code: 'unavailable',
        );
      }
      return AppException('Something went wrong (${error.code}).',
          code: error.code);
    }
    return const AppException('Something went wrong. Please try again.');
  }

  static String _auth(String code) {
    switch (code) {
      case 'email-already-in-use':
        return 'An account already exists for this email. Try signing in instead.';
      case 'invalid-email':
        return 'That email address is not valid.';
      case 'weak-password':
        return 'That password is too weak. Use at least 8 characters with a letter and a number.';
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
        return 'Email or password is incorrect.';
      case 'user-disabled':
        return 'This account has been disabled. Contact support for help.';
      case 'too-many-requests':
        return 'Too many attempts. Please wait a few minutes and try again.';
      case 'requires-recent-login':
        return 'For your security, please sign in again and retry.';
      case 'expired-action-code':
        return 'This link has expired. Please request a new one.';
      case 'invalid-action-code':
        return 'This link is not valid or was already used.';
      case 'network-request-failed':
        return 'No internet connection. Please try again.';
      default:
        return 'Could not complete sign-in ($code).';
    }
  }

  static String _functions(String code) {
    switch (code) {
      case 'unauthenticated':
        return 'Please sign in again.';
      case 'permission-denied':
        return "You don't have permission to do that.";
      case 'resource-exhausted':
        return "You've reached the limit for now. Please try again later.";
      case 'failed-precondition':
        return 'This feature is not set up yet.';
      case 'unavailable':
        return 'The service is temporarily unavailable. Please try again.';
      case 'invalid-argument':
        return 'Some information is missing or invalid.';
      default:
        return 'Something went wrong. Please try again.';
    }
  }
}
