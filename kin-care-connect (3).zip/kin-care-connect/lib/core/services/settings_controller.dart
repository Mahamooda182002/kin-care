import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../config/legal_versions.dart';

/// Device-level settings (theme, large text, onboarding seen) and the
/// first-run privacy choices (notifications, AI) with timestamp and notice
/// version.
/// Accessibility settings are also mirrored to the user profile so they follow
/// the user across devices (see ProfileRepository.updateAccessibility).
class SettingsController extends ChangeNotifier {
  SettingsController(this._prefs);
  final SharedPreferences _prefs;

  static const _kTheme = 'themeMode';
  static const _kLargeText = 'largeText';
  static const _kHighContrast = 'highContrast';
  static const _kOnboarded = 'onboardingComplete';
  static const _kChoicesVersion = 'privacyChoices.version';
  static const _kChoicesAt = 'privacyChoices.decidedAt';
  static const _kNotifOptIn = 'privacyChoices.notifications';
  static const _kAiOptIn = 'privacyChoices.ai';

  /// Clock used for consent timestamps (overridable in tests).
  DateTime Function() now = DateTime.now;

  ThemeMode get themeMode =>
      ThemeMode.values[_prefs.getInt(_kTheme) ?? ThemeMode.system.index];
  bool get largeText => _prefs.getBool(_kLargeText) ?? false;
  bool get highContrast => _prefs.getBool(_kHighContrast) ?? false;
  bool get onboardingComplete => _prefs.getBool(_kOnboarded) ?? false;

  /// Version of the privacy-choices notice the user answered on this device,
  /// or null if they have not answered yet.
  String? get privacyChoicesVersion => _prefs.getString(_kChoicesVersion);

  /// When the choices were last made or changed (UTC, ISO 8601).
  DateTime? get privacyChoicesAt =>
      DateTime.tryParse(_prefs.getString(_kChoicesAt) ?? '');

  /// True until the user answers the current version of the notice.
  bool get needsPrivacyChoices =>
      privacyChoicesVersion != LegalVersions.privacyChoices;

  /// Optional: the user agreed to receive notifications on this device.
  /// Nothing asks Android for notification permission until this is true.
  bool get notificationsOptIn => _prefs.getBool(_kNotifOptIn) ?? false;

  /// Optional: the user agreed to AI processing when they first opened the
  /// app. Applied once, as the starting value of a NEW account's AI settings;
  /// afterwards the account's Privacy settings are the source of truth.
  bool get aiOptIn => _prefs.getBool(_kAiOptIn) ?? false;

  /// Record for the user's Firestore consent log.
  Map<String, Object?> get privacyChoicesRecord => {
        'version': privacyChoicesVersion,
        'decidedAt': privacyChoicesAt?.toUtc().toIso8601String(),
        'notifications': notificationsOptIn,
        'ai': aiOptIn,
      };

  Future<void> savePrivacyChoices(
      {required bool notifications, required bool ai}) async {
    await _prefs.setBool(_kNotifOptIn, notifications);
    await _prefs.setBool(_kAiOptIn, ai);
    await _prefs.setString(_kChoicesVersion, LegalVersions.privacyChoices);
    await _prefs.setString(_kChoicesAt, now().toUtc().toIso8601String());
    notifyListeners();
  }

  Future<void> setNotificationsOptIn(bool v) async {
    await _prefs.setBool(_kNotifOptIn, v);
    await _prefs.setString(_kChoicesAt, now().toUtc().toIso8601String());
    notifyListeners();
  }

  /// Multiplier applied on top of the system text scale.
  double get textScaleFactor => largeText ? 1.3 : 1.0;

  Future<void> setThemeMode(ThemeMode m) async {
    await _prefs.setInt(_kTheme, m.index);
    notifyListeners();
  }

  Future<void> setLargeText(bool v) async {
    await _prefs.setBool(_kLargeText, v);
    notifyListeners();
  }

  Future<void> setHighContrast(bool v) async {
    await _prefs.setBool(_kHighContrast, v);
    notifyListeners();
  }

  Future<void> completeOnboarding() async {
    await _prefs.setBool(_kOnboarded, true);
    notifyListeners();
  }

  void applyRemote({bool? largeText, bool? highContrast}) {
    var changed = false;
    if (largeText != null && largeText != this.largeText) {
      _prefs.setBool(_kLargeText, largeText);
      changed = true;
    }
    if (highContrast != null && highContrast != this.highContrast) {
      _prefs.setBool(_kHighContrast, highContrast);
      changed = true;
    }
    if (changed) notifyListeners();
  }
}
