import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../features/profile/data/profile_repository.dart';
import '../../features/profile/domain/app_user.dart';
import 'auth_state.dart';
import 'settings_controller.dart';

/// Holds the signed-in user's profile document and keeps device settings in
/// sync with the profile's accessibility preferences.
class SessionController extends ChangeNotifier {
  SessionController(this._auth, this._profiles, this._settings) {
    _auth.addListener(_onAuth);
    _onAuth();
  }

  final AuthState _auth;
  final ProfileRepository _profiles;
  final SettingsController _settings;
  StreamSubscription<AppUser?>? _sub;
  String? _uid;
  AppUser? _user;
  bool _loading = false;

  String? get uid => _uid;
  AppUser? get user => _user;
  bool get loading => _loading;

  void _onAuth() {
    if (_auth.uid == _uid) return;
    _uid = _auth.uid;
    _sub?.cancel();
    _user = null;
    if (_uid == null) {
      _loading = false;
      notifyListeners();
      return;
    }
    _loading = true;
    notifyListeners();
    _sub = _profiles.watch(_uid!).listen((u) {
      _user = u;
      _loading = false;
      if (u != null) {
        _settings.applyRemote(
            largeText: u.largeText, highContrast: u.highContrast);
      }
      notifyListeners();
    }, onError: (_) {
      _loading = false;
      notifyListeners();
    });
  }

  @override
  void dispose() {
    _auth.removeListener(_onAuth);
    _sub?.cancel();
    super.dispose();
  }
}
