import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../features/auth/data/auth_repository.dart';

/// Listenable auth state used by the router for route protection.
class AuthState extends ChangeNotifier {
  AuthState(this._repo) {
    _sub = _repo.authStateChanges().listen((uid) {
      _uid = uid;
      _initialized = true;
      notifyListeners();
    });
  }

  final AuthRepository _repo;
  late final StreamSubscription<String?> _sub;
  String? _uid;
  bool _initialized = false;

  bool get initialized => _initialized;
  bool get signedIn => _uid != null;
  String? get uid => _uid;

  @override
  void dispose() {
    _sub.cancel();
    super.dispose();
  }
}
