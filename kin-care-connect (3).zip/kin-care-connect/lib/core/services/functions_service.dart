import 'package:cloud_functions/cloud_functions.dart';

import '../utils/app_exception.dart';

/// Thin wrapper over Firebase callable functions. Every call carries the
/// user's Firebase ID token and App Check token automatically; the backend
/// verifies both. No API keys or secrets ever live in the app.
///
/// Callable name  ↔  logical endpoint in the brief (Section 7):
///   medicalTranscribe      POST /api/medical/transcribe
///   medicalSummarize       POST /api/medical/summarize
///   medicalExplain         POST /api/medical/explain
///   scamAnalyze            POST /api/scam/analyze
///   familyInvite           POST /api/family/invite
///   familyAcceptInvitation POST /api/family/accept-invitation
///   activitySummary        GET  /api/activity/summary
///   remindersCreate        POST /api/reminders
class FunctionsService {
  FunctionsService(this._functions);
  final FirebaseFunctions _functions;

  Future<Map<String, dynamic>> call(
    String name, [
    Map<String, dynamic> data = const {},
    Duration timeout = const Duration(seconds: 60),
  ]) async {
    try {
      final callable = _functions.httpsCallable(
        name,
        options: HttpsCallableOptions(timeout: timeout),
      );
      final result = await callable.call<dynamic>(data);
      final raw = result.data;
      if (raw is Map) return Map<String, dynamic>.from(raw);
      return {'value': raw};
    } catch (e) {
      throw AppException.from(e);
    }
  }
}

/// Safely converts nested callable results (`Map<Object?, Object?>`) to typed maps.
Map<String, dynamic> asMap(Object? v) => v is Map
    ? v.map((k, val) => MapEntry(k.toString(), val))
    : <String, dynamic>{};

List<Map<String, dynamic>> asMapList(Object? v) =>
    v is List ? v.map(asMap).toList() : const [];

List<String> asStringList(Object? v) =>
    v is List ? v.map((e) => e.toString()).toList() : const [];
