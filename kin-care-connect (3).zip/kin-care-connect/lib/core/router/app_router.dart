import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/presentation/forgot_password_screen.dart';
import '../../features/auth/presentation/login_screen.dart';
import '../../features/auth/presentation/register_screen.dart';
import '../../features/auth/presentation/reset_password_screen.dart';
import '../../features/dashboard/presentation/activity_screen.dart';
import '../../features/dashboard/presentation/dashboard_screen.dart';
import '../../features/dashboard/presentation/home_shell.dart';
import '../../features/emergency/presentation/emergency_contacts_screen.dart';
import '../../features/family/presentation/care_profile_screen.dart';
import '../../features/family/presentation/family_detail_screen.dart';
import '../../features/family/presentation/family_screen.dart';
import '../../features/medical/presentation/medical_result_screen.dart';
import '../../features/medical/presentation/medical_translator_screen.dart';
import '../../features/medical/presentation/recording_screen.dart';
import '../../features/medical/presentation/summaries_screen.dart';
import '../../features/notifications/presentation/notification_settings_screen.dart';
import '../../features/notifications/presentation/notifications_screen.dart';
import '../../features/onboarding/onboarding_screen.dart';
import '../../features/privacy/privacy_choices_screen.dart';
import '../../features/profile/presentation/account_screen.dart';
import '../../features/profile/presentation/change_password_screen.dart';
import '../../features/profile/presentation/edit_profile_screen.dart';
import '../../features/profile/presentation/profile_screen.dart';
import '../../features/reminders/domain/reminder.dart';
import '../../features/reminders/presentation/reminder_edit_screen.dart';
import '../../features/reminders/presentation/reminders_screen.dart';
import '../../features/routine/presentation/activity_history_screen.dart';
import '../../features/routine/presentation/routine_monitor_screen.dart';
import '../../features/scam/domain/scam_rules.dart';
import '../../features/scam/presentation/scam_history_screen.dart';
import '../../features/scam/presentation/scam_result_screen.dart';
import '../../features/scam/presentation/scam_shield_screen.dart';
import '../../features/settings/presentation/about_contact_screen.dart';
import '../../features/settings/presentation/accessibility_settings_screen.dart';
import '../../features/settings/presentation/legal_screen.dart';
import '../../features/settings/presentation/privacy_settings_screen.dart';
import '../../features/settings/presentation/settings_screen.dart';
import '../../features/splash/splash_screen.dart';
import '../services/auth_state.dart';
import '../services/settings_controller.dart';

class Routes {
  Routes._();
  static const splash = '/';
  static const onboarding = '/onboarding';
  static const privacyChoices = '/privacy-choices';
  static const privacyChoicesReview = '/settings/privacy-choices';
  static const aboutContact = '/about';
  static const login = '/login';
  static const register = '/register';
  static const forgotPassword = '/forgot-password';
  static const resetPassword = '/reset-password';
  static const home = '/home';
  static const family = '/family';
  static const activity = '/activity';
  static const notifications = '/notifications';
  static const profile = '/profile';
  static const routine = '/routine';
  static const routineHistory = '/routine/history';
  static const medical = '/medical';
  static const medicalRecord = '/medical/record';
  static const medicalResult = '/medical/result';
  static const medicalSummaries = '/medical/summaries';
  static const scam = '/scam';
  static const scamResult = '/scam/result';
  static const scamHistory = '/scam/history';
  static const reminders = '/reminders';
  static const reminderEdit = '/reminders/edit';
  static const emergency = '/emergency';
  static const settings = '/settings';
  static const accessibility = '/settings/accessibility';
  static const notificationSettings = '/settings/notifications';
  static const privacy = '/settings/privacy';
  static const editProfile = '/profile/edit';
  static const changePassword = '/profile/password';
  static const account = '/profile/account';
  static String legal(String doc) => '/settings/legal/$doc';
  static String familyDetail(String id) => '/family/$id';
  static String careProfile(String familyId, String profileId) =>
      '/family/$familyId/profile/$profileId';
  static String summary(String id) => '/medical/summaries/$id';

  static const publicRoutes = {
    splash,
    onboarding,
    login,
    register,
    forgotPassword,
    resetPassword
  };
}

final _rootKey = GlobalKey<NavigatorState>(debugLabel: 'root');

GoRouter buildRouter(AuthState auth, SettingsController settings) {
  return GoRouter(
    navigatorKey: _rootKey,
    initialLocation: Routes.splash,
    refreshListenable: auth,
    redirect: (context, state) {
      final loc = state.matchedLocation;
      if (loc == Routes.splash) {
        return null; // splash decides once auth is known
      }
      if (!auth.initialized) return Routes.splash;
      // Open to everyone, signed in or not: the first-run privacy notice,
      // the legal texts and the About & Contact page.
      final isPublic = Routes.publicRoutes.contains(loc) ||
          loc == Routes.privacyChoices ||
          loc == Routes.aboutContact ||
          loc.startsWith('/settings/legal/');
      if (!auth.signedIn && !isPublic) return Routes.login;
      if (auth.signedIn &&
          Routes.publicRoutes.contains(loc) &&
          loc != Routes.resetPassword) {
        return Routes.home;
      }
      return null;
    },
    routes: [
      GoRoute(path: Routes.splash, builder: (_, __) => const SplashScreen()),
      GoRoute(
          path: Routes.onboarding,
          builder: (_, __) => const OnboardingScreen()),
      GoRoute(
          path: Routes.privacyChoices,
          builder: (_, __) => const PrivacyChoicesScreen()),
      GoRoute(
          path: Routes.aboutContact,
          builder: (_, __) => const AboutContactScreen()),
      GoRoute(path: Routes.login, builder: (_, __) => const LoginScreen()),
      GoRoute(
          path: Routes.register, builder: (_, __) => const RegisterScreen()),
      GoRoute(
          path: Routes.forgotPassword,
          builder: (_, __) => const ForgotPasswordScreen()),
      GoRoute(
        path: Routes.resetPassword,
        builder: (_, s) =>
            ResetPasswordScreen(code: s.uri.queryParameters['oobCode'] ?? ''),
      ),
      StatefulShellRoute.indexedStack(
        builder: (context, state, shell) => HomeShell(navigationShell: shell),
        branches: [
          StatefulShellBranch(routes: [
            GoRoute(
                path: Routes.home, builder: (_, __) => const DashboardScreen())
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
              path: Routes.family,
              builder: (_, __) => const FamilyScreen(),
              routes: [
                GoRoute(
                  path: ':familyId',
                  parentNavigatorKey: _rootKey,
                  builder: (_, s) => FamilyDetailScreen(
                      familyId: s.pathParameters['familyId']!),
                  routes: [
                    GoRoute(
                      path: 'profile/:profileId',
                      parentNavigatorKey: _rootKey,
                      builder: (_, s) => CareProfileScreen(
                        familyId: s.pathParameters['familyId']!,
                        profileId: s.pathParameters['profileId']!,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
                path: Routes.activity,
                builder: (_, __) => const ActivityScreen())
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
                path: Routes.notifications,
                builder: (_, __) => const NotificationsScreen())
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
              path: Routes.profile,
              builder: (_, __) => const ProfileScreen(),
              routes: [
                GoRoute(
                    path: 'edit',
                    parentNavigatorKey: _rootKey,
                    builder: (_, __) => const EditProfileScreen()),
                GoRoute(
                    path: 'password',
                    parentNavigatorKey: _rootKey,
                    builder: (_, __) => const ChangePasswordScreen()),
                GoRoute(
                    path: 'account',
                    parentNavigatorKey: _rootKey,
                    builder: (_, __) => const AccountScreen()),
              ],
            ),
          ]),
        ],
      ),
      GoRoute(
          path: Routes.routine,
          builder: (_, __) => const RoutineMonitorScreen()),
      GoRoute(
        path: Routes.routineHistory,
        builder: (_, s) => ActivityHistoryScreen(
          profileId: s.uri.queryParameters['profileId'],
          familyId: s.uri.queryParameters['familyId'],
        ),
      ),
      GoRoute(
          path: Routes.medical,
          builder: (_, __) => const MedicalTranslatorScreen()),
      GoRoute(
          path: Routes.medicalRecord,
          builder: (_, __) => const RecordingScreen()),
      GoRoute(
        path: Routes.medicalResult,
        builder: (_, s) =>
            MedicalResultScreen(args: s.extra as MedicalResultArgs),
      ),
      GoRoute(
        path: Routes.medicalSummaries,
        builder: (_, __) => const SummariesScreen(),
        routes: [
          GoRoute(
              path: ':id',
              builder: (_, s) =>
                  SummaryDetailScreen(summaryId: s.pathParameters['id']!)),
        ],
      ),
      GoRoute(path: Routes.scam, builder: (_, __) => const ScamShieldScreen()),
      GoRoute(
          path: Routes.scamResult,
          builder: (_, s) =>
              ScamResultScreen(analysis: s.extra as ScamAnalysis)),
      GoRoute(
          path: Routes.scamHistory,
          builder: (_, __) => const ScamHistoryScreen()),
      GoRoute(
        path: Routes.reminders,
        builder: (_, s) =>
            RemindersScreen(profileId: s.uri.queryParameters['profileId']),
      ),
      GoRoute(
        path: Routes.reminderEdit,
        builder: (_, s) {
          final extra = s.extra;
          return ReminderEditScreen(
            existing: extra is Reminder ? extra : null,
            profileId: s.uri.queryParameters['profileId'],
          );
        },
      ),
      GoRoute(
          path: Routes.emergency,
          builder: (_, __) => const EmergencyContactsScreen()),
      GoRoute(
          path: Routes.settings, builder: (_, __) => const SettingsScreen()),
      GoRoute(
          path: Routes.accessibility,
          builder: (_, __) => const AccessibilitySettingsScreen()),
      GoRoute(
          path: Routes.notificationSettings,
          builder: (_, __) => const NotificationSettingsScreen()),
      GoRoute(
          path: Routes.privacy,
          builder: (_, __) => const PrivacySettingsScreen()),
      GoRoute(
          path: Routes.privacyChoicesReview,
          builder: (_, __) => const PrivacyChoicesScreen(review: true)),
      GoRoute(
          path: '/settings/legal/:doc',
          builder: (_, s) => LegalScreen(doc: s.pathParameters['doc']!)),
    ],
    errorBuilder: (context, state) => Scaffold(
      appBar: AppBar(title: const Text('Page not found')),
      body: const Center(child: Text('Sorry, that page does not exist.')),
    ),
  );
}
