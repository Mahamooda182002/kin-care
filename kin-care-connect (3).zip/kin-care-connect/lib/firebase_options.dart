// PLACEHOLDER — this file is REPLACED when you run `flutterfire configure`.
//
// It exists so the project compiles before you connect your own Firebase
// project. Firebase "options" (API key, app id, project id) are public client
// identifiers, not secrets; security comes from Firestore/Storage rules,
// App Check and server-side checks in Cloud Functions.
//
// See README.md → "2. Connect your Firebase project".
// ignore_for_file: type=lint
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      throw UnsupportedError('Kin Care Connect targets Android.');
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        throw UnsupportedError(
          'Firebase is not configured yet. Run `flutterfire configure` '
          '(see README.md) to generate lib/firebase_options.dart.',
        );
      default:
        throw UnsupportedError('Kin Care Connect currently targets Android.');
    }
  }
}
