import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:provider/single_child_widget.dart';

import 'core/router/app_router.dart';
import 'core/services/auth_state.dart';
import 'core/services/functions_service.dart';
import 'core/services/session_controller.dart';
import 'core/services/settings_controller.dart';
import 'core/theme/app_theme.dart';
import 'features/auth/data/auth_repository.dart';
import 'features/emergency/data/emergency_repository.dart';
import 'features/family/data/family_repository.dart';
import 'features/medical/data/medical_repository.dart';
import 'features/notifications/data/notification_repository.dart';
import 'features/profile/data/profile_repository.dart';
import 'features/reminders/data/reminder_repository.dart';
import 'features/routine/data/activity_repository.dart';
import 'features/routine/presentation/monitoring_tracker.dart';
import 'features/scam/data/scam_repository.dart';

class KinCareApp extends StatefulWidget {
  const KinCareApp({
    super.key,
    required this.settings,
    required this.authRepository,
    required this.profileRepository,
    this.providers = const [],
  });

  /// Production wiring with real Firebase services.
  factory KinCareApp.firebase(
      {required SettingsController settings,
      required FirebaseFunctions functions}) {
    final db = FirebaseFirestore.instance;
    final storage = FirebaseStorage.instance;
    final fn = FunctionsService(functions);
    return KinCareApp(
      settings: settings,
      authRepository: FirebaseAuthRepository(FirebaseAuth.instance, db),
      profileRepository: ProfileRepository(db, storage, fn),
      providers: [
        Provider<FunctionsService>.value(value: fn),
        Provider<FamilyRepository>(create: (_) => FamilyRepository(db, fn)),
        Provider<ReminderRepository>(create: (_) => ReminderRepository(db, fn)),
        Provider<ScamRepository>(create: (_) => ScamRepository(db, fn)),
        Provider<MedicalRepository>(
            create: (_) => MedicalRepository(db, storage, fn)),
        Provider<ActivityRepository>(create: (_) => ActivityRepository(db, fn)),
        Provider<EmergencyRepository>(create: (_) => EmergencyRepository(db)),
        Provider<NotificationRepository>(
            create: (_) =>
                NotificationRepository(db, FirebaseMessaging.instance)),
      ],
    );
  }

  final SettingsController settings;
  final AuthRepository authRepository;
  final ProfileRepository profileRepository;
  final List<SingleChildWidget> providers;

  @override
  State<KinCareApp> createState() => _KinCareAppState();
}

class _KinCareAppState extends State<KinCareApp> {
  late final AuthState _authState;
  late final SessionController _session;
  late final GoRouter _router;

  @override
  void initState() {
    super.initState();
    _authState = AuthState(widget.authRepository);
    _session = SessionController(
        _authState, widget.profileRepository, widget.settings);
    _router = buildRouter(_authState, widget.settings);
  }

  @override
  void dispose() {
    _session.dispose();
    _authState.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider<AuthRepository>.value(value: widget.authRepository),
        Provider<ProfileRepository>.value(value: widget.profileRepository),
        ...widget.providers,
        ChangeNotifierProvider<SettingsController>.value(
            value: widget.settings),
        ChangeNotifierProvider<AuthState>.value(value: _authState),
        ChangeNotifierProvider<SessionController>.value(value: _session),
      ],
      child: Consumer<SettingsController>(
        builder: (context, settings, _) => MaterialApp.router(
          title: 'Kin Care Connect',
          debugShowCheckedModeBanner: false,
          theme: settings.highContrast
              ? AppTheme.highContrastLight()
              : AppTheme.light(),
          darkTheme: settings.highContrast
              ? AppTheme.highContrastDark()
              : AppTheme.dark(),
          // Android's own high-contrast text setting.
          highContrastTheme: AppTheme.highContrastLight(),
          highContrastDarkTheme: AppTheme.highContrastDark(),
          themeMode: settings.themeMode,
          routerConfig: _router,
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          supportedLocales: const [Locale('en')],
          builder: (context, child) => _AccessibilityScope(
            settings: settings,
            child: MonitoringTracker(child: child!),
          ),
        ),
      ),
    );
  }
}

/// Applies the in-app large-text option on top of the system font scale.
class _AccessibilityScope extends StatelessWidget {
  const _AccessibilityScope({required this.settings, required this.child});
  final SettingsController settings;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final mq = MediaQuery.of(context);
    final systemScale = mq.textScaler.scale(1.0);
    final scale = (systemScale * settings.textScaleFactor).clamp(1.0, 2.0);
    return MediaQuery(
      data: mq.copyWith(
        textScaler: TextScaler.linear(scale),
        highContrast: mq.highContrast || settings.highContrast,
      ),
      child: child,
    );
  }
}

/// Shown when Firebase has not been configured yet (placeholder options).
class SetupRequiredApp extends StatelessWidget {
  const SetupRequiredApp({super.key, required this.settings, this.reason = ''});
  final SettingsController settings;
  final String reason;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      home: Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.settings_suggest_outlined,
                    size: 56, color: KcColors.teal),
                const SizedBox(height: 16),
                Text('Kin Care Connect needs setup',
                    style: Theme.of(context).textTheme.headlineSmall),
                const SizedBox(height: 12),
                const Text(
                  'This build is not connected to a Firebase project yet. '
                  'Run `flutterfire configure` and rebuild. Step-by-step instructions are in README.md.',
                ),
                if (reason.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Text(reason, style: Theme.of(context).textTheme.bodySmall),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
