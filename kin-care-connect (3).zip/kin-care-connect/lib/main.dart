import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app.dart';
import 'core/config/app_config.dart';
import 'core/services/settings_controller.dart';
import 'firebase_options.dart';

/// Background FCM handler. Must be a top-level function.
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // Notifications are displayed by the system tray. No sensitive data is
  // included in payloads by default (see functions/src/notify.ts).
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final settings = SettingsController(prefs);

  try {
    await Firebase.initializeApp(
        options: DefaultFirebaseOptions.currentPlatform);
  } on UnsupportedError catch (e) {
    // firebase_options.dart is still the placeholder: show setup guidance
    // instead of crashing. Run `flutterfire configure` (see README).
    runApp(SetupRequiredApp(settings: settings, reason: e.message ?? ''));
    return;
  }

  // App Check: Play Integrity in release, debug provider in debug builds.
  // Register the debug token printed in logcat in the Firebase console.
  await FirebaseAppCheck.instance.activate(
    providerAndroid: kReleaseMode
        ? const AndroidPlayIntegrityProvider()
        : const AndroidDebugProvider(),
  );

  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  final functions =
      FirebaseFunctions.instanceFor(region: AppConfig.functionsRegion);

  if (AppConfig.useEmulators) {
    const host = AppConfig.emulatorHost;
    await FirebaseAuth.instance.useAuthEmulator(host, 9099);
    FirebaseFirestore.instance.useFirestoreEmulator(host, 8080);
    functions.useFunctionsEmulator(host, 5001);
    await FirebaseStorage.instance.useStorageEmulator(host, 9199);
  }

  runApp(KinCareApp.firebase(settings: settings, functions: functions));
}
