// Legal texts for Kin Care Connect.
//
// TEMPLATE — NEEDS LAWYER REVIEW. These texts were written to describe what
// this codebase actually does (see docs/DATA_INVENTORY.md). They are not legal
// advice. Have a qualified lawyer review them for the DPDP Act 2023, the DPDP
// Rules and any other law that applies to you before you publish the app.
//
// Plain Dart (no Flutter imports): the same text is rendered in the app
// (LegalScreen) and exported to docs/legal/*.md by tool/export_legal.dart.
// Business details come from lib/core/config/business_info.dart.

import '../../core/config/business_info.dart';
import '../../core/config/legal_versions.dart';

class LegalSection {
  const LegalSection(this.heading, this.body);
  final String heading;

  /// Paragraphs separated by blank lines. Lines starting with "• " are list
  /// items.
  final String body;
}

class LegalDoc {
  const LegalDoc({
    required this.id,
    required this.title,
    required this.version,
    required this.sections,
    this.fileName,
  });

  /// Route segment: /settings/legal/{id}.
  final String id;
  final String title;
  final String version;
  final List<LegalSection> sections;

  /// File name under docs/legal/, or null if not exported.
  final String? fileName;

  static const templateNotice =
      'Template — needs lawyer review. This text describes how the app works '
      'today but has not yet been reviewed by a lawyer.';

  String get lastUpdatedLine =>
      'Last updated: ${LegalVersions.lastUpdated} (version $version)';

  /// Markdown copy for docs/legal/.
  String toMarkdown() {
    final b = StringBuffer()
      ..writeln('# $title')
      ..writeln()
      ..writeln('> **$templateNotice**')
      ..writeln()
      ..writeln('_${lastUpdatedLine}_')
      ..writeln()
      ..writeln('<!-- Generated from lib/features/legal/legal_texts.dart by '
          '`dart run tool/export_legal.dart`. Do not edit by hand. -->');
    for (final s in sections) {
      b
        ..writeln()
        ..writeln('## ${s.heading}')
        ..writeln();
      final lines = s.body.split('\n');
      for (final l in lines) {
        b.writeln(l.startsWith('• ') ? '- ${l.substring(2)}' : l);
      }
    }
    return b.toString();
  }
}

const _b = BusinessInfo.appName;
const _company = BusinessInfo.companyName;
const _entity = BusinessInfo.legalEntity;
const _email = BusinessInfo.supportEmail;
const _ageMin = LegalVersions.minimumAge;

const _contactBlock = '''• Operator: $_company ($_entity)
• Postal address: ${BusinessInfo.postalAddress}
• Support and privacy requests: $_email
• Website: ${BusinessInfo.website}''';

const _grievanceBlock =
    '''If you have a concern about how your personal data is handled, contact our Grievance Officer:

• Name: ${BusinessInfo.grievanceOfficerName}
• Email: ${BusinessInfo.grievanceOfficerEmail}
• Post: ${BusinessInfo.postalAddress}

We will acknowledge your grievance and respond within ${BusinessInfo.grievanceResponseTime}. If you are not satisfied with our response, you may complain to the Data Protection Board of India under the Digital Personal Data Protection Act, 2023.''';

const _deletionWithoutApp =
    '''You can ask us to delete your account and data even if you no longer have the app or cannot sign in:

1. Email $_email from the email address registered to your account, with the subject "Delete my Kin Care Connect account".
2. Say whether you want the whole account deleted or only some data (for example, only recordings).
3. We may ask you to confirm the request from that email address so that nobody else can delete your account.

We then carry out the same deletion the app performs (described below) and confirm by email. If you cannot use the registered email address, tell us and we will explain how else you can verify that the account is yours.''';

const _whatDeletionRemoves =
    '''Deleting your account (in the app: Settings › Account › Delete my account) removes, from our live database and file storage:

• your profile and settings, consent records and device notification tokens;
• your reminders and their history, emergency contacts, medical summaries, recordings (audio and transcripts), scam-check results, activity records and notifications;
• your family memberships and any invitations sent to or by you;
• family groups you administer alone, together with their care profiles, memberships, invitations and the care-profile reminders and shared emergency contacts kept in them;
• your profile picture and recordings in file storage;
• your sign-in account (Firebase Authentication).

If you are the linked elder on someone else's care profile, the link is removed and all of its sharing approvals are switched off. Your name is removed from caregiver assignments.

What stays: content that other family members created themselves (for example a reminder another caregiver wrote) stays in their accounts; and some records keep an internal user ID (a random code, not your name or email) to show who created or approved something. Any backup copies, if the operator has enabled backups, are deleted when those backups expire. Server logs contain only shortened one-way codes of user IDs, never your name, email or content.''';

/// Privacy Policy.
const privacyPolicy = LegalDoc(
  id: 'privacy',
  title: 'Privacy Policy',
  version: LegalVersions.privacy,
  fileName: 'privacy-policy.md',
  sections: [
    LegalSection('Who we are',
        '''$_b is provided by $_company ("we", "us"). We are the Data Fiduciary for the personal data described here under India's Digital Personal Data Protection Act, 2023 (DPDP Act).

$_contactBlock'''),
    LegalSection('Summary',
        '''• The app is free. There are no ads, no in-app purchases and no tracking for advertising.
• We collect only what the features you use need. We never sell your data.
• Nothing is shared with your family unless the elder (or the family administrator when no elder account is linked) approves it, one type of information at a time.
• AI processing is off until you turn it on.
• You can export your data or delete your account at any time.'''),
    LegalSection('What we collect and why', '''Account
• Full name and email address: to create your account, sign you in, and show family members who you are. Your password is handled by Firebase Authentication and is never stored in our database.
• Account type (elderly member or family caregiver): a label you choose, shown on your profile.
• Profile picture (optional): shown to you and to members of your family groups.
• Settings: accessibility (large text, high contrast), notification preferences, AI and privacy choices.
• Consent records: which version of the Terms and this Policy you accepted, your confirmation that you are $_ageMin or older, and when.

Family care
• Family groups: group name, members' names, emails and roles, and invitations (the invitee's email and the inviter's name).
• Care profiles: the name and optional notes for the person being cared for, which caregivers are assigned, and the sharing approvals.
• Reminders: title, type, schedule, repeat rule, optional notes and completion history (who completed or snoozed, and when).
• Emergency contacts: name, relationship and phone number of people you add. Only add people who are happy for their details to be stored.

Medical Translator
• Text you type or paste, the explanation or summary created, its title and language.
• Recordings (only after everyone present agrees): the audio and its transcript. Deleted automatically after 30 days, or sooner if you delete them.

Scam Shield
• The basic check runs on your phone and sends nothing.
• We store only the result (risk level, warning signs found, advice and message type), never the message text.
• If you choose the optional AI check, the message text is sent to our server and the AI provider to be analysed, and is not saved.

Routine Monitor
• Only while you switch monitoring on and the app is open: simple events such as "monitoring started", "app opened" or "check-in", with times. No location, microphone, camera or sensor data is collected.

Device and service data
• A notification token for this phone, only if you allow notifications.
• Security data: Firebase App Check confirms requests come from the genuine app (using Google Play Integrity); per-account usage counters limit abuse; server logs contain shortened one-way codes of user IDs and event counts, never your content, name or email.

What we do not collect
• No location, contacts list, call logs, SMS inbox, advertising ID, or analytics or advertising trackers. The app uses no cookies.'''),
    LegalSection('Legal basis',
        '''We process your data on the basis of your consent (DPDP Act section 6), given when you create an account and, separately, for each optional feature (AI processing, recordings, notifications and family sharing). Where the law allows, we may also process data for certain legitimate uses (section 7), such as responding to a medical emergency or complying with a legal obligation.

You can withdraw consent at any time in the app (Settings › Privacy settings and Settings › Notification preferences) or by emailing us. Withdrawing consent does not affect processing that happened before, and features that depend on it will stop working.'''),
    LegalSection('AI processing',
        '''Medical Translator AI and Scam Shield AI are off by default and can be switched on or off separately in Settings › Privacy settings. When switched on, the text you submit (or the transcript of a recording you choose to transcribe) is sent over an encrypted connection to our server and then to our AI provider, ${BusinessInfo.aiProviderName}, which processes it in ${BusinessInfo.aiProviderLocation}.

We use a provider plan under which your data is not used to train AI models, and we keep provider costs ourselves: AI features never cost you anything. AI explanations can be wrong; they are not medical advice and do not diagnose.'''),
    LegalSection('Who can see your data', '''• You.
• Members of your family groups: only your name, email, role and profile picture, plus care information that the elder (or the administrator when no elder is linked) has approved for sharing: activity, medical summaries the author chose to share, and reminders. Emergency contacts added to a family are visible to its members.
• Our service providers, who process data on our behalf under contract: Google (Firebase Authentication, Cloud Firestore, Cloud Storage, Cloud Functions, Cloud Messaging and App Check), with data stored in ${BusinessInfo.dataLocation}; and ${BusinessInfo.aiProviderName} for AI features you switch on.
• Authorities, only when the law requires it.

We do not sell or rent personal data and we do not share it with advertisers or data brokers.'''),
    LegalSection('Transfers outside India',
        '''Some providers may process data outside India (for example, the AI provider in ${BusinessInfo.aiProviderLocation}, and Google's global infrastructure for notifications). We only use countries that are not restricted by the Government of India under section 16 of the DPDP Act, and we require providers to protect the data.'''),
    LegalSection('How long we keep data',
        '''• Audio recordings and transcripts: 30 days, or sooner if you delete them.
• Scam-check results: 180 days.
• Notifications: 90 days.
• Invitations: 30 days.
• Usage counters for abuse prevention: about 2 days after their time window.
• Everything else (profile, reminders, contacts, summaries, activity, family groups): until you delete it or your account.

Automatic deletion runs every day.'''),
    LegalSection('Security',
        '''Data is encrypted in transit (TLS) and at rest (Google-managed encryption). Access is limited by server-side security rules, every server request is checked for sign-in and app integrity, AI and speech keys are kept only on the server, and we limit how often each account can call costly features. No system is perfectly secure; if a personal data breach affects you, we will inform you and the Data Protection Board of India as the law requires.'''),
    LegalSection('Your rights', '''Under the DPDP Act you can:
• get a summary of the personal data we hold about you and how it is processed: Settings › Account › Export my data gives you a full copy (JSON);
• correct or update your data: edit it in the app or ask us;
• erase your data: delete individual items in the app, or delete your account;
• withdraw consent for optional processing at any time;
• nominate another person to exercise these rights if you die or become unable to (email us);
• raise a grievance (see below).

Email $_email for any request we cannot handle in the app. We may need to confirm your identity first.'''),
    LegalSection('Deleting your account', _whatDeletionRemoves),
    LegalSection('Requesting deletion without the app', _deletionWithoutApp),
    LegalSection('Children',
        '''$_b is for adults aged $_ageMin and over: family caregivers and the elderly people they support. You must confirm that you are $_ageMin or older to create an account, and we do not knowingly collect personal data of children (under $_ageMin under the DPDP Act).

If we learn that a child has created an account, we will delete it. If you believe a child has given us data, email $_email.

If the app is ever opened to children, we would first need verifiable consent from a parent or lawful guardian, as section 9 of the DPDP Act requires, and we would not track, behaviourally monitor or target advertising at children.'''),
    LegalSection('Cookies and local storage',
        '''The app does not use cookies, advertising IDs or analytics trackers. It stores a small amount of information on your phone so it works properly; see our Cookie & Local Storage Policy for the full list.'''),
    LegalSection('Changes to this policy',
        '''We will show you a notice in the app before a material change takes effect, and ask for your agreement again where the law requires. The version and date at the top tell you which text applies.'''),
    LegalSection('Grievance Officer', _grievanceBlock),
  ],
);

/// Terms of Service.
const termsOfService = LegalDoc(
  id: 'terms',
  title: 'Terms of Service',
  version: LegalVersions.terms,
  fileName: 'terms-of-service.md',
  sections: [
    LegalSection('About these terms',
        '''These terms are an agreement between you and $_company ($_entity), which provides $_b ("the app"). By creating an account you agree to them and to our Privacy Policy.

$_contactBlock'''),
    LegalSection('What the app does',
        '''$_b helps families coordinate care for elderly relatives: reminders, emergency contacts, plain-language explanations of medical information, warning signs of possible scams, and a simple activity log while the app is open.'''),
    LegalSection('Price: free, with no hidden fees',
        '''The app is free to download and use. There are no in-app purchases, subscriptions, advertisements or hidden fees. AI features are paid for by us, the operator; you are never charged for them. To keep the service fair and affordable, each account has usage limits on AI features (for example, a number of explanations per hour).

Your mobile network operator may charge for data you use, as with any app. If we ever decide to introduce a paid feature, we will tell you clearly in advance, it will be optional, and nothing will be charged without your explicit agreement.'''),
    LegalSection('Who can use the app',
        '''You must be $_ageMin or older to create an account. Do not create an account for a child or let a child use your account.'''),
    LegalSection('Not medical advice',
        '''Explanations and summaries help you understand information; they do not diagnose, prescribe or recommend changes to medicines or doses, and they can contain mistakes. Always follow your doctor or pharmacist, and check anything important with them.'''),
    LegalSection('Not an emergency service',
        '''The app does not detect falls or medical emergencies and never contacts emergency services or family automatically. In an emergency, call 112 (India) or your local emergency number.'''),
    LegalSection('Scam checks are advisory',
        '''Scam Shield looks for common warning signs. It can miss scams and can flag genuine messages, and it never confirms that a message is safe. Never share OTPs, PINs or passwords, and verify requests through an official number you already know.'''),
    LegalSection('Your responsibilities',
        '''• Record conversations only when everyone present agrees.
• Add emergency contacts and care profiles only for people who are happy for their details to be stored.
• Invite to your family group only people you trust, and give them the least access they need.
• Keep your password private and tell us if you think your account has been misused.
• Do not misuse the service: no attempts to break security, overload the service, use it for unlawful purposes, or upload content you have no right to share.'''),
    LegalSection('Your content',
        '''You keep ownership of what you add. You allow us to store and process it only to provide the features you use, as described in the Privacy Policy.'''),
    LegalSection('Availability and changes to the service',
        '''We work to keep the app available and accurate, but it is provided "as is" and may sometimes be unavailable, for example during maintenance or if a provider has an outage. Reminders depend on your phone, its settings and its connection, so do not rely on the app as the only reminder for critical medicines.'''),
    LegalSection('Liability',
        '''To the extent the law allows, we are not liable for indirect or consequential loss, or for loss caused by relying on AI explanations, scam checks or reminders instead of professional advice. Nothing in these terms limits liability that cannot be limited by law, or your rights as a consumer under the Consumer Protection Act, 2019.'''),
    LegalSection('Ending your use',
        '''You can stop using the app and delete your account at any time (Settings › Account), or ask us to delete it by email. We may suspend or close an account that seriously or repeatedly breaks these terms, and will tell you why unless the law prevents it.'''),
    LegalSection('Changes to these terms',
        '''We will tell you in the app before a material change takes effect. If you do not agree, you can delete your account.'''),
    LegalSection('Governing law',
        '''These terms are governed by the laws of India. Courts in ${BusinessInfo.governingLawCity} have jurisdiction, without affecting any right you have to bring a complaint where you live.'''),
    LegalSection('Contact and grievances', _grievanceBlock),
  ],
);

/// Cookie & Local Storage Policy. A native app has no cookies; this explains
/// the on-device storage it does use.
const storagePolicy = LegalDoc(
  id: 'storage',
  title: 'Cookie & Local Storage Policy',
  version: LegalVersions.privacy,
  fileName: 'cookie-and-local-storage-policy.md',
  sections: [
    LegalSection('No cookies, no trackers',
        '''$_b is a native Android app. It does not use browser cookies, advertising IDs, analytics SDKs, ad networks or cross-app tracking, and it does not open web pages inside the app that would set cookies. If you visit our website, any cookies there are covered by the website's own notice.'''),
    LegalSection('What the app stores on your phone',
        '''The app needs a small amount of on-device storage to work. This storage is essential and is not used for tracking:

• App settings (Android "shared preferences"): theme, large text, high contrast, whether you have seen the introduction, and your privacy choices with the date and the notice version.
• Sign-in session: Firebase Authentication keeps you signed in until you log out.
• Offline copy: Cloud Firestore keeps a temporary copy of data the app has loaded so it can open quickly and work briefly offline.
• App integrity token: Firebase App Check stores a short-lived token proving requests come from the genuine app.
• Notification token: only if you allow notifications, Firebase Cloud Messaging keeps a token so reminders can reach this phone.
• Recordings in progress: audio is saved in the app's temporary folder while you record and is deleted after it is uploaded or discarded.'''),
    LegalSection('Your choices',
        '''• Notifications and AI processing are optional. You choose them on the "Privacy choices" screen when you first open the app, and can change them any time in Settings › Privacy settings and Settings › Notification preferences.
• Logging out removes the sign-in session and this phone's notification token.
• Clearing the app's storage in Android settings, or uninstalling the app, removes everything stored on the phone. It does not delete your account; use Settings › Account › Delete my account for that.'''),
    LegalSection('Contact', '''Questions: $_email.'''),
  ],
);

/// Public account-deletion page (Google Play requires a way to request
/// deletion without installing the app). Publish docs/legal/account-deletion.md
/// on your website and enter its URL in Play Console.
const accountDeletion = LegalDoc(
  id: 'deletion',
  title: 'Delete your Kin Care Connect account',
  version: LegalVersions.privacy,
  fileName: 'account-deletion.md',
  sections: [
    LegalSection('In the app',
        '''Open Settings › Account › Delete my account, confirm, and enter your password. Deletion starts immediately.'''),
    LegalSection('Without the app', _deletionWithoutApp),
    LegalSection('What is deleted', _whatDeletionRemoves),
    LegalSection('Deleting some data only',
        '''You can delete individual recordings, summaries, reminders, contacts, notifications and scam-check results in the app at any time, or email $_email to ask us to.'''),
    LegalSection('Developer', _contactBlock),
  ],
);

const allLegalDocs = [
  privacyPolicy,
  termsOfService,
  storagePolicy,
  accountDeletion,
];

LegalDoc? legalDocById(String id) {
  for (final d in allLegalDocs) {
    if (d.id == id) return d;
  }
  return null;
}
