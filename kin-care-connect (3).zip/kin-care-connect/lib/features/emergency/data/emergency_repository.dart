import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../core/utils/app_exception.dart';

class EmergencyContact {
  const EmergencyContact(
      {required this.id,
      required this.ownerId,
      required this.name,
      required this.relationship,
      required this.phone,
      this.profileId,
      this.familyId,
      this.isPrimary = false});
  final String id;
  final String ownerId;
  final String name;
  final String relationship;
  final String phone;
  final String? profileId;
  final String? familyId;
  final bool isPrimary;

  factory EmergencyContact.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? const {};
    return EmergencyContact(
      id: d.id,
      ownerId: (m['ownerId'] as String?) ?? '',
      name: (m['contactName'] as String?) ?? '',
      relationship: (m['relationship'] as String?) ?? '',
      phone: (m['phoneNumber'] as String?) ?? '',
      profileId: m['profileId'] as String?,
      familyId: m['familyId'] as String?,
      isPrimary: m['isPrimary'] == true,
    );
  }
}

class EmergencyRepository {
  EmergencyRepository(this._db);
  final FirebaseFirestore _db;

  CollectionReference<Map<String, dynamic>> get _col =>
      _db.collection('emergencyContacts');

  Stream<List<EmergencyContact>> watchMine(String uid) => _col
      .where('ownerId', isEqualTo: uid)
      .snapshots()
      .map((s) => s.docs.map(EmergencyContact.fromDoc).toList()
        ..sort((a, b) => (b.isPrimary ? 1 : 0) - (a.isPrimary ? 1 : 0)));

  Stream<List<EmergencyContact>> watchForProfile(
          String profileId, String familyId) =>
      _col
          .where('familyId', isEqualTo: familyId)
          .where('profileId', isEqualTo: profileId)
          .snapshots()
          .map((s) => s.docs.map(EmergencyContact.fromDoc).toList());

  Future<void> save(
      {String? id,
      required String uid,
      required String name,
      required String relationship,
      required String phone,
      bool isPrimary = false,
      String? profileId,
      String? familyId}) async {
    try {
      final data = {
        'ownerId': uid,
        'contactName': name.trim(),
        'relationship': relationship.trim(),
        'phoneNumber': phone.trim(),
        'isPrimary': isPrimary,
        'profileId': profileId,
        'familyId': profileId == null ? null : familyId,
        'updatedAt': FieldValue.serverTimestamp(),
      };
      if (id == null) {
        final ref = _col.doc();
        await ref.set({
          ...data,
          'contactId': ref.id,
          'createdAt': FieldValue.serverTimestamp()
        });
      } else {
        await _col.doc(id).update(data);
      }
    } catch (e) {
      throw AppException.from(e);
    }
  }

  Future<void> delete(String id) async {
    try {
      await _col.doc(id).delete();
    } catch (e) {
      throw AppException.from(e);
    }
  }
}
