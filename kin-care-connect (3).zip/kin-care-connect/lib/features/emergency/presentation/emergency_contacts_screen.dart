import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/services/session_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_exception.dart';
import '../../../core/utils/validators.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../data/emergency_repository.dart';

/// Module K. Calls go through the phone's own dialer; the app never contacts
/// emergency services automatically.
class EmergencyContactsScreen extends StatelessWidget {
  const EmergencyContactsScreen({super.key});

  static const notice =
      'Kin Care Connect is not a replacement for emergency services. In an '
      'emergency, call your local emergency number (112 in India and the EU, '
      '911 in the US, 999 in the UK). The app never calls anyone automatically.';

  static Future<void> dial(BuildContext context, String number) async {
    final uri =
        Uri(scheme: 'tel', path: number.replaceAll(RegExp(r'[^0-9+]'), ''));
    final ok = await canLaunchUrl(uri) && await launchUrl(uri);
    if (!ok && context.mounted) {
      showSnack(context, 'Could not open the phone dialer.', error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final uid = context.watch<SessionController>().uid;
    if (uid == null) return const Scaffold(body: KcLoading());
    final repo = context.read<EmergencyRepository>();
    return Scaffold(
      appBar: AppBar(title: const Text('Emergency Contacts')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _edit(context, uid, null),
        icon: const Icon(Icons.person_add_alt),
        label: const Text('Add contact'),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(
            KcSpacing.md, KcSpacing.md, KcSpacing.md, 96),
        children: [
          const KcNotice(
              text: notice,
              tone: KcNoticeTone.danger,
              icon: Icons.emergency_outlined),
          const SizedBox(height: KcSpacing.md),
          KcButton(
              label: 'Call emergency number (112)',
              icon: Icons.call,
              variant: KcButtonVariant.danger,
              onPressed: () => dial(context, '112')),
          const KcSectionHeader('Your contacts'),
          StreamBuilder<List<EmergencyContact>>(
            stream: repo.watchMine(uid),
            builder: (context, snap) {
              if (snap.hasError) {
                return KcErrorView(
                    message: AppException.from(snap.error!).message);
              }
              if (!snap.hasData) return const KcLoading();
              if (snap.data!.isEmpty) {
                return const KcEmptyView(
                    icon: Icons.contact_phone_outlined,
                    title: 'No emergency contacts',
                    message: 'Add the people you would call first.');
              }
              return Column(
                children: snap.data!
                    .map((c) => Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: KcCard(
                            child: Row(
                              children: [
                                // Decorative initial: the name is read below.
                                ExcludeSemantics(
                                    child: CircleAvatar(
                                        radius: 26,
                                        child: Text(
                                            c.name.isNotEmpty
                                                ? c.name[0].toUpperCase()
                                                : '?',
                                            style: const TextStyle(
                                                fontSize: 20)))),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                            c.name + (c.isPrimary ? '  ★' : ''),
                                            semanticsLabel: c.isPrimary
                                                ? '${c.name}, primary contact'
                                                : c.name,
                                            style: Theme.of(context)
                                                .textTheme
                                                .titleMedium),
                                        Text(c.relationship),
                                        Text(c.phone,
                                            style: const TextStyle(
                                                fontWeight: FontWeight.w600)),
                                      ]),
                                ),
                                IconButton.filled(
                                  iconSize: 28,
                                  tooltip: 'Call ${c.name}',
                                  onPressed: () => dial(context, c.phone),
                                  icon: const Icon(Icons.call),
                                ),
                                PopupMenuButton<String>(
                                  tooltip: 'More options for ${c.name}',
                                  onSelected: (v) async {
                                    if (v == 'edit') {
                                      _edit(context, uid, c);
                                    } else {
                                      final ok = await showConfirmDialog(
                                          context,
                                          title: 'Delete ${c.name}?',
                                          message:
                                              'This contact will be removed.',
                                          confirmLabel: 'Delete',
                                          destructive: true);
                                      if (ok && context.mounted) {
                                        await runGuarded(
                                            context, () => repo.delete(c.id),
                                            success: 'Contact deleted.');
                                      }
                                    }
                                  },
                                  itemBuilder: (_) => const [
                                    PopupMenuItem(
                                        value: 'edit', child: Text('Edit')),
                                    PopupMenuItem(
                                        value: 'delete', child: Text('Delete')),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ))
                    .toList(),
              );
            },
          ),
        ],
      ),
    );
  }

  Future<void> _edit(BuildContext context, String uid, EmergencyContact? c) =>
      showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (_) => Provider<EmergencyRepository>.value(
            value: context.read<EmergencyRepository>(),
            child: _ContactForm(uid: uid, existing: c)),
      );
}

class _ContactForm extends StatefulWidget {
  const _ContactForm({required this.uid, this.existing});
  final String uid;
  final EmergencyContact? existing;
  @override
  State<_ContactForm> createState() => _ContactFormState();
}

class _ContactFormState extends State<_ContactForm> {
  final _form = GlobalKey<FormState>();
  late final _name = TextEditingController(text: widget.existing?.name ?? '');
  late final _rel =
      TextEditingController(text: widget.existing?.relationship ?? '');
  late final _phone = TextEditingController(text: widget.existing?.phone ?? '');
  late bool _primary = widget.existing?.isPrimary ?? false;
  bool _saving = false;

  @override
  void dispose() {
    _name.dispose();
    _rel.dispose();
    _phone.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _saving = true);
    final ok = await runGuarded(context, () async {
      await context.read<EmergencyRepository>().save(
            id: widget.existing?.id,
            uid: widget.uid,
            name: _name.text,
            relationship: _rel.text,
            phone: _phone.text,
            isPrimary: _primary,
          );
      return true;
    });
    if (!mounted) return;
    setState(() => _saving = false);
    if (ok == true) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(KcSpacing.lg, 0, KcSpacing.lg,
          MediaQuery.viewInsetsOf(context).bottom + KcSpacing.lg),
      child: Form(
        key: _form,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
                widget.existing == null
                    ? 'Add emergency contact'
                    : 'Edit contact',
                style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: KcSpacing.md),
            KcTextField(
                label: 'Name',
                controller: _name,
                validator: (v) => Validators.required(v, field: 'Name'),
                prefixIcon: Icons.person_outline),
            const SizedBox(height: 12),
            KcTextField(
                label: 'Relationship',
                hint: 'e.g. Son, Neighbour, Doctor',
                controller: _rel,
                validator: (v) => Validators.required(v, field: 'Relationship'),
                prefixIcon: Icons.people_outline),
            const SizedBox(height: 12),
            KcTextField(
                label: 'Phone number',
                controller: _phone,
                validator: Validators.phone,
                keyboardType: TextInputType.phone,
                prefixIcon: Icons.phone_outlined),
            SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Primary contact'),
                value: _primary,
                onChanged: (v) => setState(() => _primary = v)),
            const SizedBox(height: 8),
            KcButton(label: 'Save contact', loading: _saving, onPressed: _save),
          ],
        ),
      ),
    );
  }
}
