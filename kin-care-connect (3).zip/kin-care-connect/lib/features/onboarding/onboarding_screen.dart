import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../core/router/app_router.dart';
import '../../core/services/settings_controller.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/kc_widgets.dart';

class OnboardingPageData {
  const OnboardingPageData(this.title, this.body, this.icon, this.color);
  final String title;
  final String body;
  final IconData icon;
  final Color color;
}

const onboardingPages = [
  OnboardingPageData(
    'Family Care',
    'Bring your family together to look after the people you love. Share reminders, emergency contacts and updates, only with the people you choose.',
    Icons.diversity_1_outlined,
    KcColors.blue,
  ),
  OnboardingPageData(
    'Medical Understanding',
    'Turn confusing medical words and doctor instructions into simple language, and keep your notes organised. It explains. It never diagnoses.',
    Icons.medical_information_outlined,
    KcColors.teal,
  ),
  OnboardingPageData(
    'Scam Warnings',
    'Paste a suspicious message to see common warning signs, like requests for OTPs, urgent threats or strange links, and get clear advice on what to do. It can miss scams, so stay careful.',
    Icons.shield_outlined,
    Color(0xFF5B4BB7),
  ),
];

/// Module B: three onboarding screens with Skip, Next, Get Started and page
/// indicators.
class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _controller = PageController();
  int _index = 0;

  bool get _isLast => _index == onboardingPages.length - 1;

  Future<void> _finish() async {
    await context.read<SettingsController>().completeOnboarding();
    if (mounted) context.go(Routes.register);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: TextButton(
                  onPressed: _finish,
                  child: const Text('Skip'),
                ),
              ),
            ),
            Expanded(
              child: PageView.builder(
                controller: _controller,
                itemCount: onboardingPages.length,
                onPageChanged: (i) => setState(() => _index = i),
                itemBuilder: (context, i) {
                  final p = onboardingPages[i];
                  // Scrolls instead of overflowing on small screens or with
                  // large text (accessibility).
                  return LayoutBuilder(
                      builder: (context, box) => SingleChildScrollView(
                          padding: const EdgeInsets.symmetric(
                              horizontal: KcSpacing.lg),
                          child: ConstrainedBox(
                            constraints:
                                BoxConstraints(minHeight: box.maxHeight),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                ExcludeSemantics(
                                    child: Container(
                                  width: 140,
                                  height: 140,
                                  decoration: BoxDecoration(
                                    color: p.color.withValues(alpha: 0.12),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(p.icon, size: 84, color: p.color),
                                )),
                                const SizedBox(height: KcSpacing.xl),
                                Semantics(
                                  header: true,
                                  child: Text(
                                    p.title,
                                    style: Theme.of(context)
                                        .textTheme
                                        .headlineMedium
                                        ?.copyWith(fontWeight: FontWeight.w800),
                                    textAlign: TextAlign.center,
                                  ),
                                ),
                                const SizedBox(height: KcSpacing.md),
                                Text(
                                  p.body,
                                  style: Theme.of(context).textTheme.bodyLarge,
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          )));
                },
              ),
            ),
            Semantics(
              label: 'Page ${_index + 1} of ${onboardingPages.length}',
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(onboardingPages.length, (i) {
                  final active = i == _index;
                  return AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    margin: const EdgeInsets.symmetric(horizontal: 5),
                    height: 10,
                    width: active ? 28 : 10,
                    decoration: BoxDecoration(
                      color: active
                          ? Theme.of(context).colorScheme.primary
                          : Theme.of(context).colorScheme.outlineVariant,
                      borderRadius: BorderRadius.circular(8),
                    ),
                  );
                }),
              ),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(
                  KcSpacing.lg, KcSpacing.md, KcSpacing.lg, 0),
              child: Text(
                'Free to use: no ads, no in-app purchases and no fees.',
                textAlign: TextAlign.center,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(KcSpacing.lg),
              child: _isLast
                  ? KcButton(
                      label: 'Get Started',
                      icon: Icons.arrow_forward,
                      onPressed: _finish)
                  : KcButton(
                      label: 'Next',
                      onPressed: () => _controller.nextPage(
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.easeOut,
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
