import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../../core/config/legal_versions.dart';
import '../../../core/utils/app_exception.dart';

/// Authentication contract. The UI depends on this interface so screens can be
/// tested with a fake implementation.
abstract class AuthRepository {
  Stream<String?> authStateChanges();
  String? get currentUid;
  String? get currentEmail;
  bool get emailVerified;

  /// Creates the account. [acceptedTerms] (Terms of Service + Privacy
  /// Policy) and [confirmedAdult] (18 or older) must both be true; they come
  /// from two separate, unticked checkboxes on the registration form.
  /// [aiOptIn] / [notificationsOptIn] / [privacyChoices] carry the optional
  /// choices made on the first-run Privacy choices screen.
  Future<void> register({
    required String fullName,
    required String email,
    required String password,
    required bool acceptedTerms,
    required bool confirmedAdult,
    bool aiOptIn = false,
    bool notificationsOptIn = false,
    Map<String, Object?>? privacyChoices,
  });
  Future<void> signIn({required String email, required String password});
  Future<void> sendPasswordReset(String email);
  Future<void> confirmPasswordReset(
      {required String code, required String newPassword});
  Future<void> changePassword(
      {required String currentPassword, required String newPassword});
  Future<void> reauthenticate(String password);
  Future<void> sendEmailVerification();
  Future<bool> reloadAndCheckVerified();
  Future<void> signOut();
}

/// Firebase email/password implementation.
class FirebaseAuthRepository implements AuthRepository {
  FirebaseAuthRepository(this._auth, this._db);
  final FirebaseAuth _auth;
  final FirebaseFirestore _db;

  static const termsVersion = LegalVersions.terms;
  static const privacyVersion = LegalVersions.privacy;

  /// The new user document. Pure so it can be unit-tested; [timestamp] is
  /// `FieldValue.serverTimestamp()` in production. Only the fields listed in
  /// docs/DATA_INVENTORY.md are written (no phone number, no password).
  static Map<String, Object?> newUserDoc({
    required String uid,
    required String fullName,
    required String email,
    required Object timestamp,
    bool aiOptIn = false,
    bool notificationsOptIn = false,
    Map<String, Object?>? privacyChoices,
  }) {
    // Notification categories start in the state the user chose on the
    // Privacy choices screen: all on if they opted in, all off otherwise.
    final n = notificationsOptIn;
    return {
      'uid': uid,
      'fullName': fullName.trim(),
      'email': email.trim().toLowerCase(),
      'role': 'caregiver',
      'profileImage': null,
      'accessibilitySettings': {'largeText': false, 'highContrast': false},
      'notificationPrefs': {
        'reminders': n,
        'familyInvitations': n,
        'activityUpdates': n,
        'reminderCompletion': n,
        'securityEvents': n,
        'showDetailsOnLockScreen': false,
      },
      'privacy': {
        'aiMedicalConsent': aiOptIn,
        'aiScamConsent': aiOptIn,
        'recordingConsentAcknowledged': false,
        'policyVersion': privacyVersion,
        'updatedAt': timestamp,
      },
      'consents': {
        'termsVersion': termsVersion,
        'privacyVersion': privacyVersion,
        'acceptedAt': timestamp,
        'ageConfirmed': true,
        'minimumAge': LegalVersions.minimumAge,
        if (privacyChoices != null && privacyChoices['version'] != null)
          'privacyChoices': privacyChoices,
      },
      'createdAt': timestamp,
      'updatedAt': timestamp,
    };
  }

  @override
  Stream<String?> authStateChanges() =>
      _auth.authStateChanges().map((u) => u?.uid);

  @override
  String? get currentUid => _auth.currentUser?.uid;

  @override
  String? get currentEmail => _auth.currentUser?.email;

  @override
  bool get emailVerified => _auth.currentUser?.emailVerified ?? false;

  @override
  Future<void> register({
    required String fullName,
    required String email,
    required String password,
    required bool acceptedTerms,
    required bool confirmedAdult,
    bool aiOptIn = false,
    bool notificationsOptIn = false,
    Map<String, Object?>? privacyChoices,
  }) async {
    if (!acceptedTerms) {
      throw const AppException(
          'Please accept the Terms of Service and Privacy Policy to continue.');
    }
    if (!confirmedAdult) {
      throw const AppException(
          'Kin Care Connect is for adults aged 18 and over.');
    }
    try {
      final cred = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      final user = cred.user!;
      await user.updateDisplayName(fullName.trim());
      // Profile document. Passwords are never stored in Firestore.
      await _db.collection('users').doc(user.uid).set(newUserDoc(
            uid: user.uid,
            fullName: fullName,
            email: email,
            timestamp: FieldValue.serverTimestamp(),
            aiOptIn: aiOptIn,
            notificationsOptIn: notificationsOptIn,
            privacyChoices: privacyChoices,
          ));
      await user.sendEmailVerification();
    } catch (e) {
      throw AppException.from(e);
    }
  }

  @override
  Future<void> signIn({required String email, required String password}) async {
    try {
      await _auth.signInWithEmailAndPassword(
          email: email.trim(), password: password);
    } catch (e) {
      throw AppException.from(e);
    }
  }

  @override
  Future<void> sendPasswordReset(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email.trim());
    } on FirebaseAuthException catch (e) {
      // Do not reveal whether an account exists for this email.
      if (e.code == 'user-not-found') return;
      throw AppException.from(e);
    }
  }

  @override
  Future<void> confirmPasswordReset(
      {required String code, required String newPassword}) async {
    try {
      await _auth.confirmPasswordReset(code: code, newPassword: newPassword);
    } catch (e) {
      throw AppException.from(e);
    }
  }

  @override
  Future<void> reauthenticate(String password) async {
    final user = _auth.currentUser;
    if (user == null || user.email == null) {
      throw const AppException('Please sign in again.');
    }
    try {
      await user.reauthenticateWithCredential(
        EmailAuthProvider.credential(email: user.email!, password: password),
      );
    } catch (e) {
      throw AppException.from(e);
    }
  }

  @override
  Future<void> changePassword(
      {required String currentPassword, required String newPassword}) async {
    await reauthenticate(currentPassword);
    try {
      await _auth.currentUser!.updatePassword(newPassword);
    } catch (e) {
      throw AppException.from(e);
    }
  }

  @override
  Future<void> sendEmailVerification() async {
    try {
      await _auth.currentUser?.sendEmailVerification();
    } catch (e) {
      throw AppException.from(e);
    }
  }

  @override
  Future<bool> reloadAndCheckVerified() async {
    await _auth.currentUser?.reload();
    // Refresh the ID token so the backend sees email_verified=true.
    await _auth.currentUser?.getIdToken(true);
    return _auth.currentUser?.emailVerified ?? false;
  }

  @override
  Future<void> signOut() => _auth.signOut();
}
