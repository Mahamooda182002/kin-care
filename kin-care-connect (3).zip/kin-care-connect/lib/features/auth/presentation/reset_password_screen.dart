import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/router/app_router.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_exception.dart';
import '../../../core/utils/validators.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../data/auth_repository.dart';

/// Completes a password reset from the emailed link
/// (configure the action URL to open /reset-password?oobCode=… in the app,
/// see README → "Password reset links"). If no code is present the user can
/// paste the code from the email.
class ResetPasswordScreen extends StatefulWidget {
  const ResetPasswordScreen({super.key, required this.code});
  final String code;

  @override
  State<ResetPasswordScreen> createState() => _ResetPasswordScreenState();
}

class _ResetPasswordScreenState extends State<ResetPasswordScreen> {
  final _form = GlobalKey<FormState>();
  late final _code = TextEditingController(text: widget.code);
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  bool _loading = false;
  String? _error;

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      await context.read<AuthRepository>().confirmPasswordReset(
          code: _code.text.trim(), newPassword: _password.text);
      if (!mounted) return;
      showSnack(context, 'Password updated. Please sign in.');
      context.go(Routes.login);
    } catch (e) {
      setState(() => _error = AppException.from(e).message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _code.dispose();
    _password.dispose();
    _confirm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Set a new password')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(KcSpacing.lg),
          child: Form(
            key: _form,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (widget.code.isEmpty) ...[
                  KcTextField(
                      label: 'Reset code from the email',
                      controller: _code,
                      validator: (v) =>
                          Validators.required(v, field: 'Reset code')),
                  const SizedBox(height: KcSpacing.md),
                ],
                KcPasswordField(
                    label: 'New password',
                    controller: _password,
                    validator: Validators.password,
                    autofillHints: const [AutofillHints.newPassword]),
                const SizedBox(height: KcSpacing.md),
                KcPasswordField(
                    label: 'Confirm new password',
                    controller: _confirm,
                    validator: (v) =>
                        Validators.confirmPassword(v, _password.text),
                    autofillHints: const [AutofillHints.newPassword]),
                const SizedBox(height: KcSpacing.lg),
                if (_error != null) ...[
                  KcNotice(text: _error!, tone: KcNoticeTone.danger),
                  const SizedBox(height: KcSpacing.md)
                ],
                KcButton(
                    label: 'Update password',
                    loading: _loading,
                    onPressed: _submit),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
