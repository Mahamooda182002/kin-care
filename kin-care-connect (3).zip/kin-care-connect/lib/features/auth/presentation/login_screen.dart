import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/router/app_router.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_exception.dart';
import '../../../core/utils/validators.dart';
import '../../../core/widgets/kc_logo.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../data/auth_repository.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _form = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _loading = false;
  String? _error;

  Future<void> _submit() async {
    setState(() => _error = null);
    if (!_form.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      await context
          .read<AuthRepository>()
          .signIn(email: _email.text, password: _password.text);
      // Router redirect sends the user to the dashboard.
    } catch (e) {
      setState(() => _error = AppException.from(e).message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(KcSpacing.lg),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 480),
              child: Form(
                key: _form,
                child: AutofillGroup(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Center(child: KcLogo(size: 80)),
                      const SizedBox(height: KcSpacing.lg),
                      Text('Welcome back',
                          style: Theme.of(context).textTheme.headlineMedium,
                          textAlign: TextAlign.center),
                      const SizedBox(height: 6),
                      const Text('Sign in to Kin Care Connect',
                          textAlign: TextAlign.center),
                      const SizedBox(height: KcSpacing.xl),
                      KcTextField(
                        label: 'Email',
                        controller: _email,
                        validator: Validators.email,
                        keyboardType: TextInputType.emailAddress,
                        prefixIcon: Icons.email_outlined,
                        textInputAction: TextInputAction.next,
                        autofillHints: const [AutofillHints.email],
                      ),
                      const SizedBox(height: KcSpacing.md),
                      KcPasswordField(
                        label: 'Password',
                        controller: _password,
                        validator: (v) => (v == null || v.isEmpty)
                            ? 'Password is required.'
                            : null,
                        textInputAction: TextInputAction.done,
                      ),
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          onPressed: () => context.push(Routes.forgotPassword),
                          child: const Text('Forgot password?'),
                        ),
                      ),
                      if (_error != null) ...[
                        KcNotice(
                            text: _error!,
                            tone: KcNoticeTone.danger,
                            icon: Icons.error_outline),
                        const SizedBox(height: KcSpacing.md),
                      ],
                      KcButton(
                          label: 'Sign in',
                          loading: _loading,
                          onPressed: _submit),
                      const SizedBox(height: KcSpacing.md),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Flexible(child: Text("Don't have an account?")),
                          TextButton(
                              onPressed: () => context.go(Routes.register),
                              child: const Text('Create one')),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
