import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/config/legal_versions.dart';
import '../../../core/router/app_router.dart';
import '../../../core/services/settings_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_exception.dart';
import '../../../core/utils/validators.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../data/auth_repository.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  // Both unticked by default; neither is ever pre-checked.
  bool _accepted = false;
  bool _adult = false;
  bool _loading = false;
  String? _error;

  Future<void> _submit() async {
    setState(() => _error = null);
    final valid = _form.currentState!.validate();
    if (!_adult) {
      setState(() => _error =
          'Please confirm that you are ${LegalVersions.minimumAge} or older. '
              'If you are younger, tap "I am under ${LegalVersions.minimumAge}" below.');
      return;
    }
    if (!_accepted) {
      setState(() => _error =
          'Please agree to the Terms of Service and Privacy Policy to continue.');
      return;
    }
    if (!valid) return;
    final settings = context.read<SettingsController>();
    setState(() => _loading = true);
    try {
      await context.read<AuthRepository>().register(
            fullName: _name.text,
            email: _email.text,
            password: _password.text,
            acceptedTerms: _accepted,
            confirmedAdult: _adult,
            aiOptIn: settings.aiOptIn,
            notificationsOptIn: settings.notificationsOptIn,
            privacyChoices: settings.privacyChoicesRecord,
          );
      // Router redirect moves to the dashboard; a verification email was sent.
    } catch (e) {
      setState(() => _error = AppException.from(e).message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  /// Respectful explanation for people under the minimum age. No data is
  /// collected or stored.
  Future<void> _under18() => showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Kin Care Connect is for adults'),
          content: const Text(
              'Thank you for your interest. Accounts are only for people aged '
              '${LegalVersions.minimumAge} and over, so we can\'t create one for you. '
              'If you help look after a grandparent or relative, a parent or '
              'another adult in your family can create an account and include '
              'you in caring together offline.\n\nNothing you typed has been saved.'),
          actions: [
            FilledButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  for (final c in [_name, _email, _password, _confirm]) {
                    c.clear();
                  }
                  setState(() {
                    _adult = false;
                    _accepted = false;
                    _error = null;
                  });
                },
                child: const Text('OK')),
          ],
        ),
      );

  @override
  void dispose() {
    for (final c in [_name, _email, _password, _confirm]) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create account')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(KcSpacing.lg),
          child: Form(
            key: _form,
            child: FocusTraversalGroup(
              child: AutofillGroup(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text('Join your family on Kin Care Connect.'),
                    const SizedBox(height: KcSpacing.lg),
                    KcTextField(
                        label: 'Full name',
                        controller: _name,
                        validator: Validators.fullName,
                        prefixIcon: Icons.person_outline,
                        textInputAction: TextInputAction.next,
                        autofillHints: const [AutofillHints.name]),
                    const SizedBox(height: KcSpacing.md),
                    KcTextField(
                        label: 'Email',
                        controller: _email,
                        validator: Validators.email,
                        keyboardType: TextInputType.emailAddress,
                        prefixIcon: Icons.email_outlined,
                        textInputAction: TextInputAction.next,
                        autofillHints: const [AutofillHints.email]),
                    const SizedBox(height: KcSpacing.md),
                    KcPasswordField(
                        label: 'Password',
                        controller: _password,
                        validator: Validators.password,
                        textInputAction: TextInputAction.next,
                        autofillHints: const [AutofillHints.newPassword]),
                    const Padding(
                      padding: EdgeInsets.only(top: 6, left: 4),
                      child: Text(
                          'At least 8 characters, with a letter and a number.'),
                    ),
                    const SizedBox(height: KcSpacing.md),
                    KcPasswordField(
                        label: 'Confirm password',
                        controller: _confirm,
                        validator: (v) =>
                            Validators.confirmPassword(v, _password.text),
                        textInputAction: TextInputAction.done,
                        autofillHints: const [AutofillHints.newPassword]),
                    const SizedBox(height: KcSpacing.md),
                    // Two separate, unticked confirmations. Neither is ever
                    // pre-checked and the account is not created without both.
                    CheckboxListTile(
                      key: const Key('ageCheckbox'),
                      value: _adult,
                      onChanged: (v) => setState(() => _adult = v ?? false),
                      controlAffinity: ListTileControlAffinity.leading,
                      contentPadding: EdgeInsets.zero,
                      title: const Text(
                          'I confirm I am ${LegalVersions.minimumAge} years or older.'),
                    ),
                    CheckboxListTile(
                      key: const Key('termsCheckbox'),
                      value: _accepted,
                      onChanged: (v) => setState(() => _accepted = v ?? false),
                      controlAffinity: ListTileControlAffinity.leading,
                      contentPadding: EdgeInsets.zero,
                      title: const Text(
                          'I agree to the Terms of Service and Privacy Policy.'),
                    ),
                    Wrap(
                      spacing: 8,
                      children: [
                        TextButton(
                            onPressed: () =>
                                context.push(Routes.legal('terms')),
                            child: const Text('Read the Terms')),
                        TextButton(
                            onPressed: () =>
                                context.push(Routes.legal('privacy')),
                            child: const Text('Read the Privacy Policy')),
                      ],
                    ),
                    const Padding(
                      padding: EdgeInsets.only(left: 4, top: 4),
                      child: Text(
                          'The app is free: no ads, no in-app purchases and no fees.'),
                    ),
                    const SizedBox(height: KcSpacing.md),
                    if (_error != null) ...[
                      KcNotice(
                          text: _error!,
                          tone: KcNoticeTone.danger,
                          icon: Icons.error_outline),
                      const SizedBox(height: KcSpacing.md),
                    ],
                    KcButton(
                        label: 'Create account',
                        loading: _loading,
                        onPressed: _submit),
                    const SizedBox(height: KcSpacing.sm),
                    TextButton(
                        onPressed: _under18,
                        child: const Text(
                            'I am under ${LegalVersions.minimumAge}')),
                    const SizedBox(height: KcSpacing.md),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Flexible(child: Text('Already have an account?')),
                        TextButton(
                            onPressed: () => context.go(Routes.login),
                            child: const Text('Sign in')),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
