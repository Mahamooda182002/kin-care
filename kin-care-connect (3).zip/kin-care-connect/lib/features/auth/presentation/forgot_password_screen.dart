import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_exception.dart';
import '../../../core/utils/validators.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../data/auth_repository.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _form = GlobalKey<FormState>();
  final _email = TextEditingController();
  bool _loading = false;
  bool _sent = false;
  String? _error;

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      await context.read<AuthRepository>().sendPasswordReset(_email.text);
      setState(() => _sent = true);
    } catch (e) {
      setState(() => _error = AppException.from(e).message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _email.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Forgot password')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(KcSpacing.lg),
          child: Form(
            key: _form,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                    "Enter your email and we'll send you a link to reset your password."),
                const SizedBox(height: KcSpacing.lg),
                KcTextField(
                    label: 'Email',
                    controller: _email,
                    validator: Validators.email,
                    keyboardType: TextInputType.emailAddress,
                    prefixIcon: Icons.email_outlined),
                const SizedBox(height: KcSpacing.lg),
                if (_sent)
                  const KcNotice(
                    text:
                        'If an account exists for that email, a reset link is on its way. Check your inbox and spam folder.',
                    icon: Icons.mark_email_read_outlined,
                  ),
                if (_error != null)
                  KcNotice(text: _error!, tone: KcNoticeTone.danger),
                const SizedBox(height: KcSpacing.md),
                KcButton(
                    label: _sent ? 'Send again' : 'Send reset link',
                    loading: _loading,
                    onPressed: _submit),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
