import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_exception.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/validators.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../data/reminder_repository.dart';
import '../domain/reminder.dart';
import '../domain/repeat_rule.dart';

class ReminderEditScreen extends StatefulWidget {
  const ReminderEditScreen({super.key, this.existing, this.profileId});
  final Reminder? existing;
  final String? profileId;

  @override
  State<ReminderEditScreen> createState() => _ReminderEditScreenState();
}

class _ReminderEditScreenState extends State<ReminderEditScreen> {
  final _form = GlobalKey<FormState>();
  late final _title = TextEditingController(text: widget.existing?.title ?? '');
  late final _notes = TextEditingController(text: widget.existing?.notes ?? '');
  late ReminderType _type = widget.existing?.type ?? ReminderType.medicine;
  late DateTime _when = widget.existing?.nextDueAt ??
      DateTime.now().add(const Duration(hours: 1));
  late RepeatFrequency _freq =
      widget.existing?.repeatRule.frequency ?? RepeatFrequency.none;
  late int _interval = widget.existing?.repeatRule.interval ?? 1;
  late final Set<int> _weekdays = {...?widget.existing?.repeatRule.weekdays};
  bool _saving = false;
  String? _error;

  RepeatRule get _rule => RepeatRule(
      frequency: _freq,
      interval: _interval,
      weekdays: _freq == RepeatFrequency.weekly
          ? (_weekdays.toList()..sort())
          : const []);

  Future<void> _pickDate() async {
    final d = await showDatePicker(
        context: context,
        initialDate: _when,
        firstDate: DateTime.now().subtract(const Duration(days: 1)),
        lastDate: DateTime.now().add(const Duration(days: 730)));
    if (d != null) {
      setState(() =>
          _when = DateTime(d.year, d.month, d.day, _when.hour, _when.minute));
    }
  }

  Future<void> _pickTime() async {
    final t = await showTimePicker(
        context: context, initialTime: TimeOfDay.fromDateTime(_when));
    if (t != null) {
      setState(() => _when =
          DateTime(_when.year, _when.month, _when.day, t.hour, t.minute));
    }
  }

  Future<void> _save() async {
    setState(() => _error = null);
    if (!_form.currentState!.validate()) return;
    if (_when.isBefore(DateTime.now().subtract(const Duration(minutes: 1))) &&
        _freq == RepeatFrequency.none) {
      setState(() => _error = 'Please choose a time in the future.');
      return;
    }
    setState(() => _saving = true);
    try {
      final repo = context.read<ReminderRepository>();
      if (widget.existing == null) {
        await repo.create(
            title: _title.text,
            type: _type,
            startAt: _when,
            repeatRule: _rule,
            notes: _notes.text,
            profileId: widget.profileId);
      } else {
        await repo.update(widget.existing!,
            title: _title.text,
            type: _type,
            startAt: _when,
            repeatRule: _rule,
            notes: _notes.text);
      }
      if (!mounted) return;
      showSnack(context, 'Reminder saved.');
      context.pop();
    } catch (e) {
      setState(() => _error = AppException.from(e).message);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  void dispose() {
    _title.dispose();
    _notes.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return Scaffold(
      appBar: AppBar(
          title:
              Text(widget.existing == null ? 'New reminder' : 'Edit reminder')),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(KcSpacing.md),
          children: [
            DropdownButtonFormField<ReminderType>(
              initialValue: _type,
              decoration: const InputDecoration(labelText: 'Type'),
              items: ReminderType.values
                  .map((t) => DropdownMenuItem(value: t, child: Text(t.label)))
                  .toList(),
              onChanged: (t) =>
                  setState(() => _type = t ?? ReminderType.custom),
            ),
            const SizedBox(height: KcSpacing.md),
            KcTextField(
              label: 'Title',
              hint: _type == ReminderType.medicine
                  ? 'e.g. Evening tablets (as prescribed)'
                  : 'e.g. Visit Dr. Rao',
              controller: _title,
              maxLength: 80,
              validator: (v) => Validators.required(v, field: 'Title'),
            ),
            if (_type == ReminderType.medicine)
              const Padding(
                padding: EdgeInsets.only(bottom: 8),
                child: KcNotice(
                    text:
                        'Enter the medicine exactly as prescribed. The app will remind you but never suggests or changes doses.',
                    tone: KcNoticeTone.warning),
              ),
            Row(children: [
              Expanded(
                  child: OutlinedButton.icon(
                      onPressed: _pickDate,
                      icon: const Icon(Icons.calendar_today),
                      label: Text(Fmt.date(_when)))),
              const SizedBox(width: 12),
              Expanded(
                  child: OutlinedButton.icon(
                      onPressed: _pickTime,
                      icon: const Icon(Icons.schedule),
                      label: Text(Fmt.time(_when)))),
            ]),
            const SizedBox(height: KcSpacing.md),
            DropdownButtonFormField<RepeatFrequency>(
              initialValue: _freq,
              decoration: const InputDecoration(labelText: 'Repeat'),
              items: const [
                DropdownMenuItem(
                    value: RepeatFrequency.none,
                    child: Text('Does not repeat')),
                DropdownMenuItem(
                    value: RepeatFrequency.daily, child: Text('Daily')),
                DropdownMenuItem(
                    value: RepeatFrequency.weekly, child: Text('Weekly')),
                DropdownMenuItem(
                    value: RepeatFrequency.monthly, child: Text('Monthly')),
              ],
              onChanged: (f) =>
                  setState(() => _freq = f ?? RepeatFrequency.none),
            ),
            if (_freq != RepeatFrequency.none) ...[
              const SizedBox(height: KcSpacing.md),
              Row(children: [
                const Text('Every'),
                const SizedBox(width: 12),
                IconButton.outlined(
                    tooltip: 'Decrease',
                    onPressed: _interval > 1
                        ? () => setState(() => _interval--)
                        : null,
                    icon: const Icon(Icons.remove)),
                Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Text('$_interval',
                        style: Theme.of(context).textTheme.titleLarge)),
                IconButton.outlined(
                    tooltip: 'Increase',
                    onPressed: _interval < 30
                        ? () => setState(() => _interval++)
                        : null,
                    icon: const Icon(Icons.add)),
                const SizedBox(width: 12),
                Text(switch (_freq) {
                  RepeatFrequency.daily => 'day(s)',
                  RepeatFrequency.weekly => 'week(s)',
                  _ => 'month(s)'
                }),
              ]),
            ],
            if (_freq == RepeatFrequency.weekly) ...[
              const SizedBox(height: KcSpacing.md),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: List.generate(7, (i) {
                  final d = i + 1;
                  return FilterChip(
                    label: Text(dayNames[i]),
                    selected: _weekdays.contains(d),
                    onSelected: (s) => setState(
                        () => s ? _weekdays.add(d) : _weekdays.remove(d)),
                  );
                }),
              ),
            ],
            const SizedBox(height: 8),
            Text(_rule.describe(),
                style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: KcSpacing.md),
            KcTextField(
                label: 'Notes (optional)',
                controller: _notes,
                maxLines: 3,
                maxLength: 300),
            const SizedBox(height: KcSpacing.md),
            if (_error != null) ...[
              KcNotice(text: _error!, tone: KcNoticeTone.danger),
              const SizedBox(height: KcSpacing.md)
            ],
            KcButton(
                label: 'Save reminder',
                icon: Icons.save,
                loading: _saving,
                onPressed: _save),
          ],
        ),
      ),
    );
  }
}
