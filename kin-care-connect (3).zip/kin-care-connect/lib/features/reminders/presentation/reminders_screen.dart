import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/router/app_router.dart';
import '../../../core/services/session_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_exception.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../data/reminder_repository.dart';
import '../domain/reminder.dart';

/// Module J: list of reminders with complete / snooze / reschedule / history.
class RemindersScreen extends StatelessWidget {
  const RemindersScreen({super.key, this.profileId});
  final String? profileId;

  @override
  Widget build(BuildContext context) {
    final uid = context.watch<SessionController>().uid;
    if (uid == null) return const Scaffold(body: KcLoading());
    final repo = context.read<ReminderRepository>();
    final stream = profileId != null
        ? repo.watchForProfile(profileId!)
        : repo.watchMine(uid);
    final addRoute = profileId != null
        ? '${Routes.reminderEdit}?profileId=$profileId'
        : Routes.reminderEdit;

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title:
              Text(profileId != null ? 'Shared reminders' : 'Care Reminders'),
          bottom: const TabBar(
              tabs: [Tab(text: 'Upcoming'), Tab(text: 'Completed')]),
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => context.push(addRoute),
          icon: const Icon(Icons.add_alarm),
          label: const Text('Add reminder'),
        ),
        body: StreamBuilder<List<Reminder>>(
          stream: stream,
          builder: (context, snap) {
            if (snap.hasError) {
              return KcErrorView(
                  message: AppException.from(snap.error!).message);
            }
            if (!snap.hasData) return const KcLoading();
            final upcoming = snap.data!
                .where((r) => r.status == CompletionStatus.pending)
                .toList();
            final done = snap.data!
                .where((r) => r.status != CompletionStatus.pending)
                .toList();
            return TabBarView(children: [
              _List(
                  items: upcoming,
                  uid: uid,
                  empty:
                      'No upcoming reminders. Tap "Add reminder" to create one.'),
              _List(
                  items: done,
                  uid: uid,
                  empty: 'Completed one-time reminders appear here.'),
            ]);
          },
        ),
      ),
    );
  }
}

class _List extends StatelessWidget {
  const _List({required this.items, required this.uid, required this.empty});
  final List<Reminder> items;
  final String uid;
  final String empty;

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) {
      return KcEmptyView(
          icon: Icons.alarm_off, title: 'Nothing here', message: empty);
    }
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(
          KcSpacing.md, KcSpacing.md, KcSpacing.md, 96),
      itemCount: items.length + 1,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, i) {
        if (i == items.length) {
          return const Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text(
                'Kin Care Connect never suggests medicine doses. Always follow your doctor or pharmacist.'),
          );
        }
        return _ReminderCard(reminder: items[i], uid: uid);
      },
    );
  }
}

class _ReminderCard extends StatelessWidget {
  const _ReminderCard({required this.reminder, required this.uid});
  final Reminder reminder;
  final String uid;

  IconData get _icon => switch (reminder.type) {
        ReminderType.medicine => Icons.medication_outlined,
        ReminderType.appointment => Icons.event_available_outlined,
        ReminderType.routine => Icons.self_improvement,
        ReminderType.custom => Icons.notifications_active_outlined,
      };

  @override
  Widget build(BuildContext context) {
    final r = reminder;
    final repo = context.read<ReminderRepository>();
    return KcCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(_icon,
                  size: 32, color: Theme.of(context).colorScheme.primary),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(r.title,
                          style: Theme.of(context).textTheme.titleMedium),
                      Text('${r.type.label} • ${r.repeatRule.describe()}'),
                    ]),
              ),
              if (r.isOverdue)
                const KcChip('Due now', color: KcColors.riskMedium),
            ],
          ),
          const SizedBox(height: 8),
          Text(r.status == CompletionStatus.pending
              ? 'Next: ${Fmt.dateTime(r.nextDueAt)}'
              : 'Completed${r.lastCompletedAt != null ? ' ${Fmt.dateTime(r.lastCompletedAt!)}' : ''}'),
          if (r.notes != null && r.notes!.isNotEmpty)
            Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(r.notes!,
                    style: Theme.of(context).textTheme.bodySmall)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 4,
            children: [
              if (r.status == CompletionStatus.pending) ...[
                FilledButton.icon(
                  style: FilledButton.styleFrom(minimumSize: const Size(0, 48)),
                  onPressed: () => runGuarded(
                      context, () => repo.markCompleted(r, uid),
                      success: 'Marked as done.'),
                  icon: const Icon(Icons.check),
                  label: const Text('Done'),
                ),
                OutlinedButton.icon(
                  style:
                      OutlinedButton.styleFrom(minimumSize: const Size(0, 48)),
                  onPressed: () => _snooze(context),
                  icon: const Icon(Icons.snooze),
                  label: const Text('Snooze'),
                ),
              ],
              PopupMenuButton<String>(
                tooltip: 'More options',
                onSelected: (v) => _more(context, v),
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'reschedule', child: Text('Reschedule')),
                  PopupMenuItem(value: 'edit', child: Text('Edit')),
                  PopupMenuItem(value: 'history', child: Text('History')),
                  PopupMenuItem(value: 'delete', child: Text('Delete')),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _snooze(BuildContext context) async {
    final minutes = await showModalBottomSheet<int>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          for (final m in const [10, 30, 60, 180])
            ListTile(
                title: Text(m < 60
                    ? '$m minutes'
                    : '${m ~/ 60} hour${m >= 120 ? 's' : ''}'),
                onTap: () => Navigator.pop(ctx, m)),
        ]),
      ),
    );
    if (minutes != null && context.mounted) {
      await runGuarded(
          context,
          () => context
              .read<ReminderRepository>()
              .snooze(reminder, Duration(minutes: minutes), uid),
          success: 'Snoozed.');
    }
  }

  Future<void> _more(BuildContext context, String v) async {
    final repo = context.read<ReminderRepository>();
    switch (v) {
      case 'edit':
        context.push(Routes.reminderEdit, extra: reminder);
      case 'reschedule':
        final date = await showDatePicker(
            context: context,
            initialDate: reminder.nextDueAt.isBefore(DateTime.now())
                ? DateTime.now()
                : reminder.nextDueAt,
            firstDate: DateTime.now().subtract(const Duration(days: 1)),
            lastDate: DateTime.now().add(const Duration(days: 730)));
        if (date == null || !context.mounted) return;
        final time = await showTimePicker(
            context: context,
            initialTime: TimeOfDay.fromDateTime(reminder.nextDueAt));
        if (time == null || !context.mounted) return;
        await runGuarded(
            context,
            () => repo.reschedule(
                reminder,
                DateTime(
                    date.year, date.month, date.day, time.hour, time.minute)),
            success: 'Rescheduled.');
      case 'history':
        await showModalBottomSheet<void>(
          context: context,
          showDragHandle: true,
          builder: (_) => StreamBuilder<List<Map<String, dynamic>>>(
            stream: repo.watchHistory(reminder.id),
            builder: (context, snap) {
              final h = snap.data ?? const [];
              if (h.isEmpty) {
                return const Padding(
                    padding: EdgeInsets.all(24),
                    child: Text('No history yet.'));
              }
              return ListView(
                shrinkWrap: true,
                children: h.map((e) {
                  final at = e['at'];
                  final when = at is Timestamp ? at.toDate() : null;
                  return ListTile(
                    leading: Icon(e['action'] == 'completed'
                        ? Icons.check_circle_outline
                        : Icons.snooze),
                    title: Text(e['action'] == 'completed'
                        ? 'Completed'
                        : 'Snoozed ${e['minutes'] ?? ''} min'),
                    subtitle: when != null ? Text(Fmt.dateTime(when)) : null,
                  );
                }).toList(),
              );
            },
          ),
        );
      case 'delete':
        final ok = await showConfirmDialog(context,
            title: 'Delete reminder?',
            message: '"${reminder.title}" and its history will be deleted.',
            confirmLabel: 'Delete',
            destructive: true);
        if (ok && context.mounted) {
          await runGuarded(context, () => repo.delete(reminder.id),
              success: 'Reminder deleted.');
        }
    }
  }
}
