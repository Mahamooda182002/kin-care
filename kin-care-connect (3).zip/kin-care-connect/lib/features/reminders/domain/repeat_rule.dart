/// Recurrence rules for care reminders. Pure Dart (no Flutter/Firebase) so it
/// can be unit-tested and mirrored exactly by the Cloud Functions scheduler.
enum RepeatFrequency { none, daily, weekly, monthly }

class RepeatRule {
  const RepeatRule(
      {this.frequency = RepeatFrequency.none,
      this.interval = 1,
      this.weekdays = const []});

  final RepeatFrequency frequency;

  /// Every N days/weeks/months (1 = every).
  final int interval;

  /// For weekly rules: ISO weekdays (1 = Monday … 7 = Sunday). Empty = same
  /// weekday as the first occurrence.
  final List<int> weekdays;

  bool get repeats => frequency != RepeatFrequency.none;

  static const none = RepeatRule();

  String describe() {
    const names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    switch (frequency) {
      case RepeatFrequency.none:
        return 'Does not repeat';
      case RepeatFrequency.daily:
        return interval == 1 ? 'Every day' : 'Every $interval days';
      case RepeatFrequency.weekly:
        final days = weekdays.isEmpty
            ? ''
            : ' on ${(weekdays.toList()..sort()).map((d) => names[d - 1]).join(', ')}';
        return (interval == 1 ? 'Every week' : 'Every $interval weeks') + days;
      case RepeatFrequency.monthly:
        return interval == 1 ? 'Every month' : 'Every $interval months';
    }
  }

  /// Returns the next occurrence strictly after [after], given the series
  /// started at [start]. Returns null for non-repeating rules.
  DateTime? nextAfter(DateTime start, DateTime after) {
    if (!repeats) return null;
    final step = interval < 1 ? 1 : interval;
    switch (frequency) {
      case RepeatFrequency.none:
        return null;
      case RepeatFrequency.daily:
        var next = start;
        if (!next.isAfter(after)) {
          final days = after.difference(start).inDays;
          final jumps = (days ~/ step);
          next = _addDays(start, jumps * step);
          while (!next.isAfter(after)) {
            next = _addDays(next, step);
          }
        }
        return next;
      case RepeatFrequency.weekly:
        final days = weekdays.isEmpty
            ? [start.weekday]
            : (weekdays.toSet().toList()..sort());
        // Walk day by day (bounded) checking weekday + week-interval alignment.
        final startWeek = _mondayOf(start);
        final cursor = after.isBefore(start)
            ? start.subtract(const Duration(days: 1))
            : after;
        for (var i = 0; i < 7 * step * 2 + 8; i++) {
          final candidateDay =
              _addDays(DateTime(cursor.year, cursor.month, cursor.day), i);
          final candidate = DateTime(candidateDay.year, candidateDay.month,
              candidateDay.day, start.hour, start.minute);
          if (!candidate.isAfter(after) || candidate.isBefore(start)) continue;
          final weeksFromStart =
              _mondayOf(candidate).difference(startWeek).inDays ~/ 7;
          if (weeksFromStart % step == 0 && days.contains(candidate.weekday)) {
            return candidate;
          }
        }
        return null;
      case RepeatFrequency.monthly:
        var n = 0;
        while (true) {
          final candidate = _addMonths(start, n * step);
          if (candidate.isAfter(after)) return candidate;
          n++;
          if (n > 1200) return null;
        }
    }
  }

  static DateTime _addDays(DateTime d, int days) =>
      DateTime(d.year, d.month, d.day + days, d.hour, d.minute);

  static DateTime _mondayOf(DateTime d) =>
      DateTime(d.year, d.month, d.day - (d.weekday - 1));

  /// Adds months, clamping to the last day of the month (Jan 31 → Feb 28/29).
  static DateTime _addMonths(DateTime d, int months) {
    final y = d.year + ((d.month - 1 + months) ~/ 12);
    final m = ((d.month - 1 + months) % 12) + 1;
    final lastDay = DateTime(y, m + 1, 0).day;
    return DateTime(y, m, d.day > lastDay ? lastDay : d.day, d.hour, d.minute);
  }

  Map<String, dynamic> toMap() => {
        'frequency': frequency.name,
        'interval': interval,
        'weekdays': weekdays,
      };

  factory RepeatRule.fromMap(Map<String, dynamic>? m) {
    if (m == null) return RepeatRule.none;
    final f = RepeatFrequency.values.firstWhere((e) => e.name == m['frequency'],
        orElse: () => RepeatFrequency.none);
    final interval = (m['interval'] is int) ? m['interval'] as int : 1;
    final wd = ((m['weekdays'] as List?) ?? const [])
        .whereType<int>()
        .where((d) => d >= 1 && d <= 7)
        .toList();
    return RepeatRule(
        frequency: f, interval: interval.clamp(1, 365), weekdays: wd);
  }
}
