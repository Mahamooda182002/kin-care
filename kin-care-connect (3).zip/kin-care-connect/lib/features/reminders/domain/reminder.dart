import 'package:cloud_firestore/cloud_firestore.dart';

import 'repeat_rule.dart';

enum ReminderType { medicine, appointment, routine, custom }

extension ReminderTypeX on ReminderType {
  String get label => switch (this) {
        ReminderType.medicine => 'Medicine',
        ReminderType.appointment => 'Doctor appointment',
        ReminderType.routine => 'Routine',
        ReminderType.custom => 'Custom',
      };
  static ReminderType parse(String? v) => ReminderType.values
      .firstWhere((t) => t.name == v, orElse: () => ReminderType.custom);
}

enum CompletionStatus { pending, completed, missed }

class Reminder {
  const Reminder({
    required this.id,
    required this.userId,
    required this.title,
    required this.type,
    required this.startAt,
    required this.nextDueAt,
    this.repeatRule = RepeatRule.none,
    this.status = CompletionStatus.pending,
    this.notes,
    this.profileId,
    this.familyId,
    this.lastCompletedAt,
  });

  final String id;
  final String userId;
  final String title;
  final ReminderType type;
  final DateTime startAt;
  final DateTime nextDueAt;
  final RepeatRule repeatRule;
  final CompletionStatus status;
  final String? notes;
  final String? profileId;
  final String? familyId;
  final DateTime? lastCompletedAt;

  bool get isOverdue =>
      status == CompletionStatus.pending && nextDueAt.isBefore(DateTime.now());

  factory Reminder.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? const {};
    final schedule =
        (m['schedule'] as Map?)?.cast<String, dynamic>() ?? const {};
    final start =
        (schedule['startAt'] as Timestamp?)?.toDate() ?? DateTime.now();
    return Reminder(
      id: d.id,
      userId: (m['userId'] as String?) ?? '',
      title: (m['title'] as String?) ?? '',
      type: ReminderTypeX.parse(m['reminderType'] as String?),
      startAt: start,
      nextDueAt: (m['nextDueAt'] as Timestamp?)?.toDate() ?? start,
      repeatRule: RepeatRule.fromMap(
          (m['repeatRule'] as Map?)?.cast<String, dynamic>()),
      status: CompletionStatus.values.firstWhere(
        (s) => s.name == m['completionStatus'],
        orElse: () => CompletionStatus.pending,
      ),
      notes: m['notes'] as String?,
      profileId: m['profileId'] as String?,
      familyId: m['familyId'] as String?,
      lastCompletedAt: (m['lastCompletedAt'] as Timestamp?)?.toDate(),
    );
  }
}
