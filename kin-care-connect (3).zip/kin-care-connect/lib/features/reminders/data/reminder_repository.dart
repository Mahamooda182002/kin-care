import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../core/services/functions_service.dart';
import '../../../core/utils/app_exception.dart';
import '../domain/reminder.dart';
import '../domain/repeat_rule.dart';

class ReminderRepository {
  ReminderRepository(this._db, this._functions);
  final FirebaseFirestore _db;
  final FunctionsService _functions;

  CollectionReference<Map<String, dynamic>> get _col =>
      _db.collection('reminders');

  Stream<List<Reminder>> watchMine(String uid, {int limit = 100}) => _col
      .where('userId', isEqualTo: uid)
      .orderBy('nextDueAt')
      .limit(limit)
      .snapshots()
      .map((s) => s.docs.map(Reminder.fromDoc).toList());

  Stream<List<Reminder>> watchForProfile(String profileId) => _col
      .where('profileId', isEqualTo: profileId)
      .orderBy('nextDueAt')
      .snapshots()
      .map((s) => s.docs.map(Reminder.fromDoc).toList());

  Stream<List<Map<String, dynamic>>> watchHistory(String reminderId) => _col
      .doc(reminderId)
      .collection('history')
      .orderBy('at', descending: true)
      .limit(50)
      .snapshots()
      .map((s) => s.docs.map((d) => d.data()).toList());

  /// Created through the backend (POST /api/reminders) so validation and
  /// family authorization run server-side.
  Future<void> create({
    required String title,
    required ReminderType type,
    required DateTime startAt,
    required RepeatRule repeatRule,
    String? notes,
    String? profileId,
  }) async {
    await _functions.call('remindersCreate', {
      'title': title.trim(),
      'reminderType': type.name,
      'startAt': startAt.toUtc().toIso8601String(),
      'repeatRule': repeatRule.toMap(),
      if (notes != null && notes.trim().isNotEmpty) 'notes': notes.trim(),
      if (profileId != null) 'profileId': profileId,
      'timezoneOffsetMinutes': startAt.timeZoneOffset.inMinutes,
    });
  }

  Future<void> update(Reminder r,
          {required String title,
          required ReminderType type,
          required DateTime startAt,
          required RepeatRule repeatRule,
          String? notes}) =>
      _guard(() => _col.doc(r.id).update({
            'title': title.trim(),
            'reminderType': type.name,
            'schedule': {'startAt': Timestamp.fromDate(startAt)},
            'repeatRule': repeatRule.toMap(),
            'nextDueAt': Timestamp.fromDate(startAt),
            'completionStatus': 'pending',
            'notified': false,
            'notes':
                (notes == null || notes.trim().isEmpty) ? null : notes.trim(),
            'updatedAt': FieldValue.serverTimestamp(),
          }));

  /// Marks the current occurrence done and advances recurring reminders.
  Future<void> markCompleted(Reminder r, String byUid) async {
    final now = DateTime.now();
    final next = r.repeatRule
        .nextAfter(r.startAt, r.nextDueAt.isAfter(now) ? r.nextDueAt : now);
    await _guard(() async {
      final batch = _db.batch();
      batch.update(_col.doc(r.id), {
        'completionStatus': next == null ? 'completed' : 'pending',
        'nextDueAt': Timestamp.fromDate(next ?? r.nextDueAt),
        'lastCompletedAt': FieldValue.serverTimestamp(),
        'notified': false,
        'updatedAt': FieldValue.serverTimestamp(),
      });
      batch.set(_col.doc(r.id).collection('history').doc(), {
        'action': 'completed',
        'occurrence': Timestamp.fromDate(r.nextDueAt),
        'by': byUid,
        'at': FieldValue.serverTimestamp(),
      });
      await batch.commit();
    });
  }

  Future<void> snooze(Reminder r, Duration by, String byUid) =>
      _guard(() async {
        final batch = _db.batch();
        batch.update(_col.doc(r.id), {
          'nextDueAt': Timestamp.fromDate(DateTime.now().add(by)),
          'notified': false,
          'updatedAt': FieldValue.serverTimestamp(),
        });
        batch.set(_col.doc(r.id).collection('history').doc(), {
          'action': 'snoozed',
          'minutes': by.inMinutes,
          'by': byUid,
          'at': FieldValue.serverTimestamp(),
        });
        await batch.commit();
      });

  Future<void> reschedule(Reminder r, DateTime to) =>
      _guard(() => _col.doc(r.id).update({
            'nextDueAt': Timestamp.fromDate(to),
            'completionStatus': 'pending',
            'notified': false,
            'updatedAt': FieldValue.serverTimestamp(),
          }));

  Future<void> delete(String id) => _guard(() => _col.doc(id).delete());

  Future<void> _guard(Future<void> Function() f) async {
    try {
      await f();
    } catch (e) {
      throw AppException.from(e);
    }
  }
}
