import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../core/config/legal_versions.dart';
import '../../core/router/app_router.dart';
import '../../core/services/session_controller.dart';
import '../../core/services/settings_controller.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/kc_dialogs.dart';
import '../../core/widgets/kc_widgets.dart';
import '../notifications/data/notification_repository.dart';
import '../profile/data/profile_repository.dart';

/// First-run "Privacy choices" notice.
///
/// Kin Care Connect is a native app with no cookies, ads or analytics, so this
/// is NOT a cookie banner. It explains the essential on-device storage and asks
/// for the two optional things the app can do:
///   • notifications on this phone, and
///   • AI processing of text the user chooses to submit.
///
/// Rules this screen follows (see docs/COMPLIANCE_CHECKLIST.md):
///   • nothing is pre-ticked (for a new user);
///   • "Decline all" and "Accept all" have exactly the same size and style;
///   • there is no close button that silently counts as consent;
///   • choices are stored with a timestamp and the notice version, and can be
///     changed later in Settings › Privacy settings.
class PrivacyChoicesScreen extends StatefulWidget {
  const PrivacyChoicesScreen({super.key, this.review = false});

  /// Opened again from Settings to change earlier choices.
  final bool review;

  @override
  State<PrivacyChoicesScreen> createState() => _PrivacyChoicesScreenState();
}

class _PrivacyChoicesScreenState extends State<PrivacyChoicesScreen> {
  bool _notifications = false;
  bool _ai = false;
  bool _saving = false;
  bool _initialised = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialised) return;
    _initialised = true;
    final settings = context.read<SettingsController>();
    final user = context.read<SessionController?>()?.user;
    // A new user starts with everything off. Someone who already answered
    // (or whose account already holds an AI choice) sees their own answer.
    if (!settings.needsPrivacyChoices || widget.review) {
      _notifications = settings.notificationsOptIn;
      _ai = settings.aiOptIn;
    }
    if (user != null) {
      _ai = user.privacy.aiMedicalConsent && user.privacy.aiScamConsent;
    }
  }

  Future<void> _save({required bool notifications, required bool ai}) async {
    setState(() {
      _notifications = notifications;
      _ai = ai;
      _saving = true;
    });
    final settings = context.read<SettingsController>();
    final session = context.read<SessionController?>();
    final notifRepo = context.read<NotificationRepository?>();
    final profiles = context.read<ProfileRepository?>();
    await settings.savePrivacyChoices(notifications: notifications, ai: ai);

    final user = session?.user;
    if (user != null && mounted) {
      // Signed in: the account's AI settings follow this choice, and the
      // phone is (un)registered for notifications straight away.
      final p = user.privacy;
      if (profiles != null &&
          (p.aiMedicalConsent != ai || p.aiScamConsent != ai)) {
        await runGuarded(
            context,
            () => profiles.updatePrivacy(
                user.uid, p.copyWith(aiMedicalConsent: ai, aiScamConsent: ai)));
      }
      if (notifRepo != null) {
        if (notifications) {
          await notifRepo.registerDevice(user.uid);
        } else {
          await notifRepo.unregisterDevice(user.uid);
        }
      }
    }
    if (!mounted) return;
    setState(() => _saving = false);
    _leave();
  }

  void _leave() {
    if (widget.review && context.canPop()) {
      showSnack(context, 'Your privacy choices were saved.');
      context.pop();
      return;
    }
    final settings = context.read<SettingsController>();
    final signedIn = context.read<SessionController?>()?.uid != null;
    if (signedIn) {
      context.go(Routes.home);
    } else if (!settings.onboardingComplete) {
      context.go(Routes.onboarding);
    } else {
      context.go(Routes.login);
    }
  }

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return PopScope(
      // First run: no back/close that would count as an answer.
      canPop: widget.review,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Your privacy choices'),
          automaticallyImplyLeading: widget.review,
        ),
        body: SafeArea(
          child: FocusTraversalGroup(
            child: ListView(
              padding: const EdgeInsets.all(KcSpacing.lg),
              children: [
                Text(
                  'Kin Care Connect has no ads, no analytics and no cookies. '
                  'Please choose which optional features you want. Nothing is '
                  'switched on unless you choose it, and you can change your '
                  'mind any time in Settings › Privacy settings.',
                  style: text.bodyLarge,
                ),
                const KcSectionHeader('Always on: essential storage'),
                KcCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                          'The app keeps your settings, your sign-in and a '
                          'temporary copy of your data on this phone so it '
                          'works properly. This is never used for tracking.'),
                      TextButton(
                        onPressed: () => context.push(Routes.legal('storage')),
                        child: const Text(
                            'Read the Cookie & Local Storage Policy'),
                      ),
                    ],
                  ),
                ),
                const KcSectionHeader('Optional'),
                KcCard(
                  padding: EdgeInsets.zero,
                  child: Column(children: [
                    CheckboxListTile(
                      key: const Key('choiceNotifications'),
                      value: _notifications,
                      onChanged: _saving
                          ? null
                          : (v) => setState(() => _notifications = v ?? false),
                      title: const Text('Notifications'),
                      subtitle: const Text(
                          'Reminders and family updates on this phone. Android '
                          'asks for permission only if you choose this. '
                          'Lock-screen text stays private.'),
                    ),
                    const Divider(height: 1),
                    CheckboxListTile(
                      key: const Key('choiceAi'),
                      value: _ai,
                      onChanged: _saving
                          ? null
                          : (v) => setState(() => _ai = v ?? false),
                      title: const Text('AI processing'),
                      subtitle: const Text(
                          'Send text or recording transcripts that you choose '
                          'to our server and an AI provider, to explain medical '
                          'words or look for scam warning signs. Without it, '
                          'the scam check runs only on your phone and the app '
                          'asks before any AI use.'),
                    ),
                  ]),
                ),
                const SizedBox(height: KcSpacing.lg),
                // Equal weight: same widget, same variant, same width.
                Row(
                  children: [
                    Expanded(
                      child: KcButton(
                        key: const Key('declineAll'),
                        label: 'Decline all',
                        variant: KcButtonVariant.tonal,
                        onPressed: _saving
                            ? null
                            : () => _save(notifications: false, ai: false),
                      ),
                    ),
                    const SizedBox(width: KcSpacing.md),
                    Expanded(
                      child: KcButton(
                        key: const Key('acceptAll'),
                        label: 'Accept all',
                        variant: KcButtonVariant.tonal,
                        onPressed: _saving
                            ? null
                            : () => _save(notifications: true, ai: true),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: KcSpacing.md),
                KcButton(
                  key: const Key('saveChoices'),
                  label: 'Save my choices',
                  variant: KcButtonVariant.outlined,
                  loading: _saving,
                  onPressed: () =>
                      _save(notifications: _notifications, ai: _ai),
                ),
                const SizedBox(height: KcSpacing.md),
                TextButton(
                  onPressed: () => context.push(Routes.legal('privacy')),
                  child: const Text('Read the Privacy Policy'),
                ),
                Text(
                  'Notice version ${LegalVersions.privacyChoices}',
                  style: text.bodySmall,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
