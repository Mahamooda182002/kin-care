import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../core/router/app_router.dart';
import '../../core/services/auth_state.dart';
import '../../core/services/settings_controller.dart';
import '../../core/theme/app_theme.dart';
import '../../core/widgets/kc_logo.dart';

/// Module A: logo, name, tagline, loading animation, then routes to
/// onboarding, login or the dashboard depending on auth state.
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1400))
    ..repeat(reverse: true);
  bool _minTimeElapsed = false;
  bool _navigated = false;
  AuthState? _auth;

  @override
  void initState() {
    super.initState();
    Future<void>.delayed(const Duration(milliseconds: 1500), () {
      _minTimeElapsed = true;
      _maybeNavigate();
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final a = context.read<AuthState>();
    if (a != _auth) {
      _auth?.removeListener(_maybeNavigate);
      _auth = a..addListener(_maybeNavigate);
    }
  }

  void _maybeNavigate() {
    if (!mounted || _navigated || !_minTimeElapsed) return;
    final auth = context.read<AuthState>();
    if (!auth.initialized) return;
    _navigated = true;
    final settings = context.read<SettingsController>();
    if (settings.needsPrivacyChoices) {
      // First run (or the notice changed): ask before anything optional.
      context.go(Routes.privacyChoices);
    } else if (auth.signedIn) {
      context.go(Routes.home);
    } else if (!settings.onboardingComplete) {
      context.go(Routes.onboarding);
    } else {
      context.go(Routes.login);
    }
  }

  @override
  void dispose() {
    _auth?.removeListener(_maybeNavigate);
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [KcColors.blue, KcColors.tealDeep],
          ),
        ),
        child: Center(
          child: Semantics(
            label: 'Kin Care Connect. Caring Together. Living Safer. Loading.',
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ScaleTransition(
                  scale: Tween(begin: 0.94, end: 1.04).animate(
                      CurvedAnimation(parent: _c, curve: Curves.easeInOut)),
                  child: const KcLogo(size: 104, onDark: true),
                ),
                const SizedBox(height: 24),
                const Text(
                  'Kin Care Connect',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 30,
                      fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Caring Together. Living Safer.',
                  // Full white: white70 on the teal end of the gradient
                  // fell below 4.5:1 contrast.
                  style: TextStyle(color: Colors.white, fontSize: 18),
                ),
                const SizedBox(height: 40),
                const SizedBox(
                  width: 140,
                  child: LinearProgressIndicator(
                    color: Colors.white,
                    backgroundColor: Colors.white24,
                    minHeight: 4,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
