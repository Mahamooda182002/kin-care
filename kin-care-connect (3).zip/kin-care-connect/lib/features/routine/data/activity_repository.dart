import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../core/services/functions_service.dart';
import '../../../core/utils/app_exception.dart';

/// Activity types recorded by the in-app routine monitor. These describe app
/// interactions only; they are NOT health or emergency signals.
enum ActivityType {
  monitoringStarted,
  monitoringStopped,
  appOpened,
  checkIn,
  interaction
}

extension ActivityTypeX on ActivityType {
  String get label => switch (this) {
        ActivityType.monitoringStarted => 'Monitoring started',
        ActivityType.monitoringStopped => 'Monitoring stopped',
        ActivityType.appOpened => 'Opened the app',
        ActivityType.checkIn => '"I\'m okay" check-in',
        ActivityType.interaction => 'Used the app',
      };
  static ActivityType parse(String? v) => ActivityType.values
      .firstWhere((t) => t.name == v, orElse: () => ActivityType.interaction);
}

class ActivityRecord {
  const ActivityRecord(
      {required this.id,
      required this.userId,
      required this.type,
      required this.timestamp,
      this.profileId,
      this.source = 'app_foreground'});
  final String id;
  final String userId;
  final ActivityType type;
  final DateTime timestamp;
  final String? profileId;
  final String source;

  factory ActivityRecord.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? const {};
    return ActivityRecord(
      id: d.id,
      userId: (m['userId'] as String?) ?? '',
      type: ActivityTypeX.parse(m['activityType'] as String?),
      timestamp: (m['timestamp'] as Timestamp?)?.toDate() ?? DateTime.now(),
      profileId: m['profileId'] as String?,
      source: (m['source'] as String?) ?? 'app_foreground',
    );
  }
}

class MonitoringPrefs {
  const MonitoringPrefs(
      {this.recordAppOpen = true,
      this.recordCheckIns = true,
      this.recordInteractions = true,
      this.shareProfileId});
  final bool recordAppOpen;
  final bool recordCheckIns;
  final bool recordInteractions;

  /// Care profile (linked to this elderly account) that activity is shared
  /// with, subject to that profile's activity-sharing consent.
  final String? shareProfileId;

  factory MonitoringPrefs.fromMap(Map<String, dynamic>? m) => MonitoringPrefs(
        recordAppOpen: m?['recordAppOpen'] != false,
        recordCheckIns: m?['recordCheckIns'] != false,
        recordInteractions: m?['recordInteractions'] != false,
        shareProfileId: m?['shareProfileId'] as String?,
      );

  Map<String, dynamic> toMap() => {
        'recordAppOpen': recordAppOpen,
        'recordCheckIns': recordCheckIns,
        'recordInteractions': recordInteractions,
        'shareProfileId': shareProfileId,
      };
}

class MonitoringState {
  const MonitoringState(
      {required this.active,
      this.startedAt,
      this.prefs = const MonitoringPrefs(),
      this.permissionGranted = false});
  final bool active;
  final DateTime? startedAt;
  final MonitoringPrefs prefs;
  final bool permissionGranted;

  factory MonitoringState.fromUserDoc(Map<String, dynamic>? d) {
    final m = (d?['monitoring'] as Map?)?.cast<String, dynamic>();
    return MonitoringState(
      active: m?['active'] == true,
      startedAt: (m?['startedAt'] as Timestamp?)?.toDate(),
      prefs: MonitoringPrefs.fromMap(
          (m?['prefs'] as Map?)?.cast<String, dynamic>()),
      permissionGranted: m?['permissionGranted'] == true,
    );
  }
}

class ActivitySummary {
  const ActivitySummary(
      {required this.date,
      required this.counts,
      this.lastActivityAt,
      this.lastActivityType,
      required this.total,
      required this.note});
  final String date;
  final Map<String, int> counts;
  final DateTime? lastActivityAt;
  final String? lastActivityType;
  final int total;
  final String note;
}

class ActivityRepository {
  ActivityRepository(this._db, this._functions);
  final FirebaseFirestore _db;
  final FunctionsService _functions;

  CollectionReference<Map<String, dynamic>> get _col =>
      _db.collection('activityRecords');

  Stream<MonitoringState> watchState(String uid) => _db
      .collection('users')
      .doc(uid)
      .snapshots()
      .map((s) => MonitoringState.fromUserDoc(s.data()));

  Future<void> setMonitoring(String uid,
      {required bool active,
      required MonitoringPrefs prefs,
      String? familyId}) async {
    try {
      await _db.collection('users').doc(uid).update({
        'monitoring': {
          'active': active,
          'permissionGranted': active,
          'startedAt': active ? FieldValue.serverTimestamp() : null,
          'prefs': prefs.toMap(),
        },
        'updatedAt': FieldValue.serverTimestamp(),
      });
      await record(
          uid,
          active
              ? ActivityType.monitoringStarted
              : ActivityType.monitoringStopped,
          profileId: prefs.shareProfileId,
          familyId: familyId);
    } catch (e) {
      throw AppException.from(e);
    }
  }

  Future<void> updatePrefs(String uid, MonitoringPrefs prefs) async {
    try {
      await _db
          .collection('users')
          .doc(uid)
          .update({'monitoring.prefs': prefs.toMap()});
    } catch (e) {
      throw AppException.from(e);
    }
  }

  Future<void> record(String uid, ActivityType type,
      {String? profileId, String? familyId}) async {
    try {
      await _col.add({
        'userId': uid,
        'profileId': profileId,
        'familyId': profileId == null ? null : familyId,
        'activityType': type.name,
        'timestamp': FieldValue.serverTimestamp(),
        'source': 'app_foreground',
        'consentReference': profileId == null
            ? 'self'
            : 'careProfiles/$profileId#sharingConsent.activity',
      });
    } catch (e) {
      throw AppException.from(e);
    }
  }

  Stream<List<ActivityRecord>> watchMine(String uid, {int limit = 100}) => _col
      .where('userId', isEqualTo: uid)
      .orderBy('timestamp', descending: true)
      .limit(limit)
      .snapshots()
      .map((s) => s.docs.map(ActivityRecord.fromDoc).toList());

  /// Records shared with a family care profile (rules require consent).
  Stream<List<ActivityRecord>> watchForProfile(
          String profileId, String familyId, {int limit = 100}) =>
      _col
          .where('profileId', isEqualTo: profileId)
          .where('familyId', isEqualTo: familyId)
          .orderBy('timestamp', descending: true)
          .limit(limit)
          .snapshots()
          .map((s) => s.docs.map(ActivityRecord.fromDoc).toList());

  /// GET /api/activity/summary
  Future<ActivitySummary> summary({String? profileId, DateTime? day}) async {
    final d = day ?? DateTime.now();
    final r = await _functions.call('activitySummary', {
      if (profileId != null) 'profileId': profileId,
      'date':
          '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}',
      'timezoneOffsetMinutes': d.timeZoneOffset.inMinutes,
    });
    final counts = asMap(r['counts'])
        .map((k, v) => MapEntry(k, (v as num?)?.toInt() ?? 0));
    return ActivitySummary(
      date: (r['date'] ?? '').toString(),
      counts: counts,
      total: (r['total'] as num?)?.toInt() ?? 0,
      lastActivityAt: r['lastActivityAt'] is String
          ? DateTime.tryParse(r['lastActivityAt'] as String)?.toLocal()
          : null,
      lastActivityType: r['lastActivityType'] as String?,
      note: (r['note'] ?? '').toString(),
    );
  }
}
