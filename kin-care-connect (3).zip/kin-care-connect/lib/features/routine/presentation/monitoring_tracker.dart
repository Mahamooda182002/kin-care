import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/services/session_controller.dart';
import '../../family/data/family_repository.dart';
import '../../family/domain/family_models.dart';
import '../data/activity_repository.dart';

/// Records routine activity ONLY while:
///   • the user has switched monitoring on (explicit consent), and
///   • the app is open in the foreground.
/// There is no background service. When the app is closed or in the
/// background nothing is recorded, and gaps must never be interpreted as an
/// emergency.
class MonitoringTracker extends StatefulWidget {
  const MonitoringTracker({super.key, required this.child});
  final Widget child;

  /// Minimum gap between "used the app" records, to avoid noisy data.
  static const interactionThrottle = Duration(minutes: 15);

  @override
  State<MonitoringTracker> createState() => _MonitoringTrackerState();
}

class _MonitoringTrackerState extends State<MonitoringTracker>
    with WidgetsBindingObserver {
  StreamSubscription<MonitoringState>? _stateSub;
  StreamSubscription<CareProfile?>? _profileSub;
  MonitoringState? _state;
  CareProfile? _shareProfile;
  DateTime? _lastInteraction;
  String? _uid;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final uid = context.read<SessionController>().uid;
    if (uid != _uid) {
      _uid = uid;
      _stateSub?.cancel();
      if (uid != null) {
        var first = true;
        _stateSub =
            context.read<ActivityRepository>().watchState(uid).listen((s) {
          _state = s;
          _watchProfile(s.prefs.shareProfileId);
          if (first && s.active && s.prefs.recordAppOpen) {
            _record(ActivityType.appOpened);
          }
          first = false;
        });
      }
    }
  }

  void _watchProfile(String? profileId) {
    if (profileId == _shareProfile?.id && _profileSub != null) return;
    _profileSub?.cancel();
    _shareProfile = null;
    if (profileId == null) return;
    _profileSub = context
        .read<FamilyRepository>()
        .watchProfile(profileId)
        .listen((p) => _shareProfile = p);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed &&
        (_state?.active ?? false) &&
        (_state?.prefs.recordAppOpen ?? false)) {
      _record(ActivityType.appOpened);
    }
  }

  void _onPointer(PointerDownEvent _) {
    final s = _state;
    if (s == null || !s.active || !s.prefs.recordInteractions) return;
    final now = DateTime.now();
    if (_lastInteraction != null &&
        now.difference(_lastInteraction!) <
            MonitoringTracker.interactionThrottle) {
      return;
    }
    _lastInteraction = now;
    _record(ActivityType.interaction);
  }

  void _record(ActivityType type) {
    final uid = _uid;
    if (uid == null) return;
    // Only attach to a care profile when that profile is linked to this user
    // AND activity sharing is consented; rules enforce the same.
    final p = _shareProfile;
    final share =
        p != null && p.linkedUserId == uid && p.sharingConsent.activity;
    context
        .read<ActivityRepository>()
        .record(uid, type,
            profileId: share ? p.id : null, familyId: share ? p.familyId : null)
        .catchError((_) {});
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _stateSub?.cancel();
    _profileSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Listener(
      behavior: HitTestBehavior.translucent,
      onPointerDown: _onPointer,
      child: widget.child);
}
