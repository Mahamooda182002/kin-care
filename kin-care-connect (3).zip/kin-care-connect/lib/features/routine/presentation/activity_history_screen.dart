import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/services/session_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/kc_widgets.dart';
import 'routine_monitor_screen.dart';
import 'widgets/activity_list.dart';
import 'widgets/activity_summary_card.dart';

class ActivityHistoryScreen extends StatelessWidget {
  const ActivityHistoryScreen({super.key, this.profileId, this.familyId});
  final String? profileId;
  final String? familyId;

  @override
  Widget build(BuildContext context) {
    final uid = context.watch<SessionController>().uid;
    if (uid == null) return const Scaffold(body: KcLoading());
    final shared = profileId != null && familyId != null;
    return Scaffold(
      appBar:
          AppBar(title: Text(shared ? 'Shared activity' : 'Activity history')),
      body: ListView(
        padding: const EdgeInsets.all(KcSpacing.md),
        children: [
          ActivitySummaryCard(profileId: profileId),
          const SizedBox(height: KcSpacing.md),
          const KcNotice(
              text: RoutineMonitorScreen.limitations, tone: KcNoticeTone.info),
          const SizedBox(height: KcSpacing.md),
          ActivityList(uid: uid, profileId: profileId, familyId: familyId),
        ],
      ),
    );
  }
}
