import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/router/app_router.dart';
import '../../../core/services/session_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../../family/data/family_repository.dart';
import '../../family/domain/family_models.dart';
import '../data/activity_repository.dart';
import 'widgets/activity_summary_card.dart';

/// Module F: transparent, in-app-only routine activity awareness.
class RoutineMonitorScreen extends StatelessWidget {
  const RoutineMonitorScreen({super.key});

  static const limitations =
      'Monitoring only records when Kin Care Connect is open on this phone and '
      'monitoring is switched on. It records simple app activity (opening the '
      'app, check-ins, using the app). It does NOT detect falls, medical '
      'emergencies or health problems, and it never contacts emergency '
      'services. Periods with no activity are normal (for example when the '
      'phone is locked or the app is closed) and do not mean something is wrong.';

  @override
  Widget build(BuildContext context) {
    final uid = context.watch<SessionController>().uid;
    if (uid == null) return const Scaffold(body: KcLoading());
    final repo = context.read<ActivityRepository>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Routine Monitor'),
        actions: [
          IconButton(
              tooltip: 'Activity history',
              icon: const Icon(Icons.history),
              onPressed: () => context.push(Routes.routineHistory)),
        ],
      ),
      body: StreamBuilder<MonitoringState>(
        stream: repo.watchState(uid),
        builder: (context, snap) {
          if (snap.hasError) {
            return const KcErrorView(
                message: 'Monitoring status could not be loaded.');
          }
          if (!snap.hasData) return const KcLoading();
          final s = snap.data!;
          return ListView(
            padding: const EdgeInsets.all(KcSpacing.md),
            children: [
              _StatusCard(state: s),
              const SizedBox(height: KcSpacing.md),
              const KcNotice(text: limitations, icon: Icons.info_outline),
              const SizedBox(height: KcSpacing.md),
              if (s.active) ...[
                KcButton(
                  label: "I'm okay. Check in",
                  icon: Icons.thumb_up_alt_outlined,
                  variant: KcButtonVariant.tonal,
                  onPressed: s.prefs.recordCheckIns
                      ? () => runGuarded(
                          context, () => _checkIn(context, uid, s),
                          success: 'Check-in recorded.')
                      : null,
                ),
                const SizedBox(height: KcSpacing.sm),
                KcButton(
                  label: 'Stop monitoring',
                  icon: Icons.stop_circle_outlined,
                  variant: KcButtonVariant.outlined,
                  onPressed: () async {
                    final ok = await showConfirmDialog(context,
                        title: 'Stop monitoring?',
                        message: 'Activity will no longer be recorded.',
                        confirmLabel: 'Stop');
                    if (ok && context.mounted) {
                      await runGuarded(
                          context,
                          () => repo.setMonitoring(uid,
                              active: false, prefs: s.prefs),
                          success: 'Monitoring stopped.');
                    }
                  },
                ),
              ] else
                KcButton(
                  label: 'Start monitoring',
                  icon: Icons.play_circle_outline,
                  onPressed: () => _start(context, uid, s),
                ),
              const SizedBox(height: KcSpacing.md),
              const ActivitySummaryCard(),
              const KcSectionHeader('Preferences'),
              _PrefsCard(uid: uid, state: s),
            ],
          );
        },
      ),
    );
  }

  Future<void> _checkIn(
      BuildContext context, String uid, MonitoringState s) async {
    final fam = await _shareTarget(context, s);
    if (!context.mounted) return;
    await context.read<ActivityRepository>().record(uid, ActivityType.checkIn,
        profileId: fam?.id, familyId: fam?.familyId);
  }

  Future<CareProfile?> _shareTarget(
      BuildContext context, MonitoringState s) async {
    final id = s.prefs.shareProfileId;
    if (id == null) return null;
    final p = await context.read<FamilyRepository>().watchProfile(id).first;
    final uid = context.mounted ? context.read<SessionController>().uid : null;
    if (p == null || p.linkedUserId != uid || !p.sharingConsent.activity) {
      return null;
    }
    return p;
  }

  Future<void> _start(
      BuildContext context, String uid, MonitoringState s) async {
    final ok = await showConfirmDialog(
      context,
      title: 'Allow routine monitoring?',
      message:
          '$limitations\n\nYou can stop at any time. Do you want to start?',
      confirmLabel: 'Start',
    );
    if (!ok || !context.mounted) return;
    final target = await _shareTarget(context, s);
    if (!context.mounted) return;
    await runGuarded(
        context,
        () => context.read<ActivityRepository>().setMonitoring(uid,
            active: true, prefs: s.prefs, familyId: target?.familyId),
        success: 'Monitoring is on while the app is open.');
  }
}

class _StatusCard extends StatelessWidget {
  const _StatusCard({required this.state});
  final MonitoringState state;

  @override
  Widget build(BuildContext context) {
    final on = state.active;
    return KcCard(
      color: on ? Theme.of(context).colorScheme.secondaryContainer : null,
      semanticLabel: on ? 'Monitoring is on' : 'Monitoring is off',
      child: Row(
        children: [
          Icon(on ? Icons.monitor_heart : Icons.monitor_heart_outlined,
              size: 48,
              color: on
                  ? Theme.of(context).colorScheme.secondary
                  : Theme.of(context).colorScheme.outline),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(on ? 'Monitoring is ON' : 'Monitoring is OFF',
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(color: on ? KcColors.ink : null)),
                Text(
                  on
                      ? 'Recording only while the app is open${state.startedAt != null ? ' • since ${Fmt.dateTime(state.startedAt!)}' : ''}'
                      : 'Nothing is being recorded.',
                  style: TextStyle(color: on ? KcColors.ink : null),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PrefsCard extends StatelessWidget {
  const _PrefsCard({required this.uid, required this.state});
  final String uid;
  final MonitoringState state;

  @override
  Widget build(BuildContext context) {
    final repo = context.read<ActivityRepository>();
    final p = state.prefs;
    Future<void> save(MonitoringPrefs n) =>
        runGuarded(context, () => repo.updatePrefs(uid, n));
    return KcCard(
      padding: EdgeInsets.zero,
      child: Column(
        children: [
          SwitchListTile(
            title: const Text('Record when I open the app'),
            value: p.recordAppOpen,
            onChanged: (v) => save(MonitoringPrefs(
                recordAppOpen: v,
                recordCheckIns: p.recordCheckIns,
                recordInteractions: p.recordInteractions,
                shareProfileId: p.shareProfileId)),
          ),
          SwitchListTile(
            title: const Text('Allow "I\'m okay" check-ins'),
            value: p.recordCheckIns,
            onChanged: (v) => save(MonitoringPrefs(
                recordAppOpen: p.recordAppOpen,
                recordCheckIns: v,
                recordInteractions: p.recordInteractions,
                shareProfileId: p.shareProfileId)),
          ),
          SwitchListTile(
            title: const Text('Record when I use the app'),
            subtitle: const Text('At most once every 15 minutes'),
            value: p.recordInteractions,
            onChanged: (v) => save(MonitoringPrefs(
                recordAppOpen: p.recordAppOpen,
                recordCheckIns: p.recordCheckIns,
                recordInteractions: v,
                shareProfileId: p.shareProfileId)),
          ),
          const Divider(height: 1),
          StreamBuilder<List<CareProfile>>(
            stream: context.read<FamilyRepository>().watchProfilesLinkedTo(uid),
            builder: (context, snap) {
              final profiles = snap.data ?? const <CareProfile>[];
              if (profiles.isEmpty) {
                return const ListTile(
                  leading: Icon(Icons.lock_outline),
                  title: Text('Activity stays private'),
                  subtitle: Text(
                      'To share with family, a family admin must link your account to a care profile.'),
                );
              }
              return Padding(
                padding: const EdgeInsets.all(16),
                child: DropdownButtonFormField<String?>(
                  initialValue: profiles.any((x) => x.id == p.shareProfileId)
                      ? p.shareProfileId
                      : null,
                  isExpanded: true,
                  decoration: const InputDecoration(
                      labelText: 'Share activity with family'),
                  items: [
                    const DropdownMenuItem<String?>(
                        value: null, child: Text('Keep private')),
                    ...profiles.map((cp) => DropdownMenuItem<String?>(
                          value: cp.id,
                          child: Text(
                              '${cp.displayName}${cp.sharingConsent.activity ? '' : ' (sharing consent off)'}'),
                        )),
                  ],
                  onChanged: (v) => save(MonitoringPrefs(
                      recordAppOpen: p.recordAppOpen,
                      recordCheckIns: p.recordCheckIns,
                      recordInteractions: p.recordInteractions,
                      shareProfileId: v)),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
