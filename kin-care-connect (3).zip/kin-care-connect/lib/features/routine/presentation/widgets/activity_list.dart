import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../core/utils/app_exception.dart';
import '../../../../core/utils/formatters.dart';
import '../../../../core/widgets/kc_widgets.dart';
import '../../data/activity_repository.dart';

class ActivityList extends StatelessWidget {
  const ActivityList(
      {super.key, this.uid, this.profileId, this.familyId, this.limit = 100});
  final String? uid;
  final String? profileId;
  final String? familyId;
  final int limit;

  @override
  Widget build(BuildContext context) {
    final repo = context.read<ActivityRepository>();
    final stream = profileId != null && familyId != null
        ? repo.watchForProfile(profileId!, familyId!, limit: limit)
        : repo.watchMine(uid!, limit: limit);
    return StreamBuilder<List<ActivityRecord>>(
      stream: stream,
      builder: (context, snap) {
        if (snap.hasError) {
          return KcErrorView(message: AppException.from(snap.error!).message);
        }
        if (!snap.hasData) {
          return const Padding(padding: EdgeInsets.all(24), child: KcLoading());
        }
        final items = snap.data!;
        if (items.isEmpty) {
          return const KcEmptyView(
              icon: Icons.timeline,
              title: 'No activity yet',
              message: 'Activity appears here while monitoring is on.');
        }
        String? lastDay;
        final children = <Widget>[];
        for (final a in items) {
          final day = Fmt.date(a.timestamp);
          if (day != lastDay) {
            children.add(Padding(
              padding: const EdgeInsets.only(top: 12, bottom: 4),
              child: Text(day, style: Theme.of(context).textTheme.labelLarge),
            ));
            lastDay = day;
          }
          children.add(ListTile(
            dense: false,
            leading: Icon(_icon(a.type)),
            title: Text(a.type.label),
            subtitle: Text(Fmt.time(a.timestamp)),
          ));
        }
        return Column(
            crossAxisAlignment: CrossAxisAlignment.start, children: children);
      },
    );
  }

  IconData _icon(ActivityType t) => switch (t) {
        ActivityType.monitoringStarted => Icons.play_circle_outline,
        ActivityType.monitoringStopped => Icons.stop_circle_outlined,
        ActivityType.appOpened => Icons.open_in_new,
        ActivityType.checkIn => Icons.thumb_up_alt_outlined,
        ActivityType.interaction => Icons.touch_app_outlined,
      };
}
