import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../core/utils/app_exception.dart';
import '../../../../core/utils/formatters.dart';
import '../../../../core/widgets/kc_widgets.dart';
import '../../data/activity_repository.dart';

/// Daily summary from GET /api/activity/summary.
class ActivitySummaryCard extends StatefulWidget {
  const ActivitySummaryCard(
      {super.key, this.profileId, this.title = "Today's summary"});
  final String? profileId;
  final String title;

  @override
  State<ActivitySummaryCard> createState() => _ActivitySummaryCardState();
}

class _ActivitySummaryCardState extends State<ActivitySummaryCard> {
  late Future<ActivitySummary> _future = _load();

  Future<ActivitySummary> _load() =>
      context.read<ActivityRepository>().summary(profileId: widget.profileId);

  @override
  Widget build(BuildContext context) {
    return KcCard(
      child: FutureBuilder<ActivitySummary>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const SizedBox(height: 80, child: KcLoading());
          }
          if (snap.hasError) {
            return Row(
              children: [
                Expanded(child: Text(AppException.from(snap.error!).message)),
                TextButton(
                    onPressed: () => setState(() => _future = _load()),
                    child: const Text('Retry')),
              ],
            );
          }
          final s = snap.data!;
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(widget.title,
                  style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              Text(
                  '${s.total} recorded app ${s.total == 1 ? 'activity' : 'activities'} today'),
              if (s.lastActivityAt != null)
                Text('Last recorded: ${Fmt.relative(s.lastActivityAt!)}'),
              if ((s.counts['checkIn'] ?? 0) > 0)
                Text('Check-ins: ${s.counts['checkIn']}'),
              const SizedBox(height: 8),
              Text(s.note, style: Theme.of(context).textTheme.bodySmall),
            ],
          );
        },
      ),
    );
  }
}
