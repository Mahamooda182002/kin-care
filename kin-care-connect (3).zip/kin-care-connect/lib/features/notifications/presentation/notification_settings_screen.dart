import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';

import '../../../core/services/session_controller.dart';
import '../../../core/services/settings_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../../profile/data/profile_repository.dart';
import '../../profile/domain/app_user.dart';
import '../data/notification_repository.dart';

class NotificationSettingsScreen extends StatefulWidget {
  const NotificationSettingsScreen({super.key});
  @override
  State<NotificationSettingsScreen> createState() =>
      _NotificationSettingsScreenState();
}

class _NotificationSettingsScreenState
    extends State<NotificationSettingsScreen> {
  late Future<AuthorizationStatus> _status =
      context.read<NotificationRepository>().permissionStatus();

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionController>();
    final user = session.user;
    if (user == null) return const Scaffold(body: KcLoading());
    final p = user.notificationPrefs;
    final repo = context.read<ProfileRepository>();

    Future<void> save(NotificationPrefs n) =>
        runGuarded(context, () => repo.updateNotificationPrefs(user.uid, n));
    NotificationPrefs copy(
            {bool? reminders,
            bool? familyInvitations,
            bool? activityUpdates,
            bool? reminderCompletion,
            bool? securityEvents,
            bool? lock}) =>
        NotificationPrefs(
          reminders: reminders ?? p.reminders,
          familyInvitations: familyInvitations ?? p.familyInvitations,
          activityUpdates: activityUpdates ?? p.activityUpdates,
          reminderCompletion: reminderCompletion ?? p.reminderCompletion,
          securityEvents: securityEvents ?? p.securityEvents,
          showDetailsOnLockScreen: lock ?? p.showDetailsOnLockScreen,
        );

    Future<void> setAll(bool on) async {
      final settings = context.read<SettingsController>();
      final notif = context.read<NotificationRepository>();
      await save(p.withAll(on));
      await settings.setNotificationsOptIn(on);
      if (on) {
        await notif.registerDevice(user.uid);
      } else {
        await notif.unregisterDevice(user.uid);
      }
      if (mounted) {
        setState(() => _status = notif.permissionStatus());
      }
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Notification preferences')),
      body: ListView(
        padding: const EdgeInsets.all(KcSpacing.md),
        children: [
          FutureBuilder<AuthorizationStatus>(
            future: _status,
            builder: (context, snap) {
              final s = snap.data;
              final allowed = s == AuthorizationStatus.authorized ||
                  s == AuthorizationStatus.provisional;
              return KcCard(
                child: Row(children: [
                  Icon(
                      allowed
                          ? Icons.notifications_active
                          : Icons.notifications_off_outlined,
                      size: 32),
                  const SizedBox(width: 12),
                  Expanded(
                      child: Text(allowed
                          ? 'Notifications are allowed on this phone.'
                          : 'Notifications are turned off for this app on this phone.')),
                  if (!allowed)
                    TextButton(
                      onPressed: () async {
                        final notif = context.read<NotificationRepository>();
                        await context
                            .read<SettingsController>()
                            .setNotificationsOptIn(true);
                        final st = await notif.registerDevice(user.uid);
                        if (st == AuthorizationStatus.denied) {
                          await openAppSettings();
                        }
                        if (mounted) {
                          setState(() => _status = context
                              .read<NotificationRepository>()
                              .permissionStatus());
                        }
                      },
                      child: const Text('Allow'),
                    ),
                ]),
              );
            },
          ),
          const SizedBox(height: KcSpacing.md),
          // One tap to stop everything (or turn everything back on).
          KcCard(
            padding: EdgeInsets.zero,
            child: SwitchListTile(
              key: const Key('allNotifications'),
              title: const Text('All notifications'),
              subtitle: Text(p.allOff
                  ? 'Off. You will not get any notifications from Kin Care Connect.'
                  : 'Turn off to stop every notification in one tap.'),
              value: !p.allOff,
              onChanged: (on) => setAll(on),
            ),
          ),
          const KcSectionHeader('Notify me about'),
          KcCard(
            padding: EdgeInsets.zero,
            child: Column(children: [
              SwitchListTile(
                  title: const Text('Care reminders'),
                  value: p.reminders,
                  onChanged: (v) => save(copy(reminders: v))),
              SwitchListTile(
                  title: const Text('Family invitations'),
                  value: p.familyInvitations,
                  onChanged: (v) => save(copy(familyInvitations: v))),
              SwitchListTile(
                  title: const Text('Approved activity updates'),
                  value: p.activityUpdates,
                  onChanged: (v) => save(copy(activityUpdates: v))),
              SwitchListTile(
                  title: const Text('Reminder completed'),
                  subtitle:
                      const Text('When someone marks a shared reminder done'),
                  value: p.reminderCompletion,
                  onChanged: (v) => save(copy(reminderCompletion: v))),
              SwitchListTile(
                  title: const Text('Account security'),
                  subtitle: const Text(
                      'Sign-in and account changes. We suggest keeping this on.'),
                  value: p.securityEvents,
                  onChanged: (v) => save(copy(securityEvents: v))),
            ]),
          ),
          const KcSectionHeader('Privacy'),
          KcCard(
            padding: EdgeInsets.zero,
            child: SwitchListTile(
              title: const Text('Show details on lock screen'),
              subtitle: const Text(
                  'Off by default. When off, notifications only say "You have a care reminder" without medical details.'),
              value: p.showDetailsOnLockScreen,
              onChanged: (v) async {
                if (v) {
                  final ok = await showConfirmDialog(context,
                      title: 'Show details on lock screen?',
                      message:
                          'Anyone who can see your phone may read reminder titles, which can include medicine names.',
                      confirmLabel: 'Show details',
                      cancelLabel: 'Keep private',
                      equalWeight: true);
                  if (!ok) return;
                }
                await save(copy(lock: v));
              },
            ),
          ),
          const SizedBox(height: 12),
          const Text(
              'Reminder schedules are set on each reminder in Care Reminders. '
              'Kin Care Connect never sends marketing emails or promotional '
              'notifications. The only emails are account emails you ask for '
              '(email verification and password reset).'),
        ],
      ),
    );
  }
}
