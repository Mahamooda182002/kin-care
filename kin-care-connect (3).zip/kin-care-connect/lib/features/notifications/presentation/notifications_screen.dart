import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/router/app_router.dart';
import '../../../core/services/session_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_exception.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../data/notification_repository.dart';

/// Module L: in-app notification centre.
class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  IconData _icon(String type) => switch (type) {
        'reminder' => Icons.alarm,
        'reminderCompleted' => Icons.task_alt,
        'familyInvitation' => Icons.group_add_outlined,
        'activity' => Icons.timeline,
        'security' => Icons.security,
        _ => Icons.notifications_outlined,
      };

  @override
  Widget build(BuildContext context) {
    final uid = context.watch<SessionController>().uid;
    if (uid == null) return const Scaffold(body: KcLoading());
    final repo = context.read<NotificationRepository>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          IconButton(
              tooltip: 'Mark all as read',
              icon: const Icon(Icons.done_all),
              onPressed: () =>
                  runGuarded(context, () => repo.markAllRead(uid))),
          IconButton(
              tooltip: 'Notification settings',
              icon: const Icon(Icons.tune),
              onPressed: () => context.push(Routes.notificationSettings)),
        ],
      ),
      body: StreamBuilder<List<AppNotification>>(
        stream: repo.watch(uid),
        builder: (context, snap) {
          if (snap.hasError) {
            return KcErrorView(message: AppException.from(snap.error!).message);
          }
          if (!snap.hasData) return const KcLoading();
          if (snap.data!.isEmpty) {
            return const KcEmptyView(
                icon: Icons.notifications_none,
                title: 'No notifications',
                message:
                    'Reminders, invitations and updates will appear here.');
          }
          return ListView.separated(
            padding: const EdgeInsets.all(KcSpacing.md),
            itemCount: snap.data!.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final n = snap.data![i];
              return Dismissible(
                key: ValueKey(n.id),
                direction: DismissDirection.endToStart,
                onDismissed: (_) =>
                    runGuarded(context, () => repo.delete(n.id)),
                background: Container(
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 24),
                    child: const Icon(Icons.delete_outline)),
                child: KcCard(
                  padding: EdgeInsets.zero,
                  color: n.read
                      ? null
                      : Theme.of(context)
                          .colorScheme
                          .primaryContainer
                          .withValues(alpha: 0.5),
                  onTap: () {
                    if (!n.read) repo.markRead(n.id);
                    if (n.link != null && n.link!.startsWith('/')) {
                      context.push(n.link!);
                    }
                  },
                  child: ListTile(
                    leading: Icon(_icon(n.type)),
                    title: Text(n.title,
                        style: TextStyle(
                            fontWeight:
                                n.read ? FontWeight.w500 : FontWeight.w800)),
                    subtitle:
                        Text('${n.message}\n${Fmt.relative(n.createdAt)}'),
                    isThreeLine: true,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
