import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';

import '../../../core/utils/app_exception.dart';

class AppNotification {
  const AppNotification(
      {required this.id,
      required this.type,
      required this.title,
      required this.message,
      required this.read,
      required this.createdAt,
      this.link});
  final String id;
  final String type;
  final String title;
  final String message;
  final bool read;
  final DateTime createdAt;
  final String? link;

  factory AppNotification.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? const {};
    return AppNotification(
      id: d.id,
      type: (m['type'] as String?) ?? 'general',
      title: (m['title'] as String?) ?? 'Kin Care Connect',
      message: (m['message'] as String?) ?? '',
      read: m['readStatus'] == true,
      createdAt: (m['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      link: m['link'] as String?,
    );
  }
}

class NotificationRepository {
  NotificationRepository(this._db, this._messaging);
  final FirebaseFirestore _db;
  final FirebaseMessaging _messaging;

  CollectionReference<Map<String, dynamic>> get _col =>
      _db.collection('notifications');

  Stream<List<AppNotification>> watch(String uid, {int limit = 50}) => _col
      .where('userId', isEqualTo: uid)
      .orderBy('createdAt', descending: true)
      .limit(limit)
      .snapshots()
      .map((s) => s.docs.map(AppNotification.fromDoc).toList());

  Stream<int> watchUnreadCount(String uid) => _col
      .where('userId', isEqualTo: uid)
      .where('readStatus', isEqualTo: false)
      .snapshots()
      .map((s) => s.size);

  Future<void> markRead(String id) =>
      _guard(() => _col.doc(id).update({'readStatus': true}));

  Future<void> markAllRead(String uid) => _guard(() async {
        final unread = await _col
            .where('userId', isEqualTo: uid)
            .where('readStatus', isEqualTo: false)
            .limit(400)
            .get();
        final batch = _db.batch();
        for (final d in unread.docs) {
          batch.update(d.reference, {'readStatus': true});
        }
        await batch.commit();
      });

  Future<void> delete(String id) => _guard(() => _col.doc(id).delete());

  /// Asks for notification permission (Android 13+) and registers the FCM
  /// token so the backend can deliver reminders. Tokens live in a private
  /// subcollection only the owner and server can read.
  ///
  /// Only called after the user opted in to notifications (Privacy choices
  /// or Notification preferences). FCM auto-init is disabled in
  /// AndroidManifest.xml, so no token exists before this.
  Future<AuthorizationStatus> registerDevice(String uid) async {
    try {
      await _messaging.setAutoInitEnabled(true);
      final settings = await _messaging.requestPermission();
      if (settings.authorizationStatus == AuthorizationStatus.denied) {
        return settings.authorizationStatus;
      }
      // Registration tokens are used for Admin SDK sends (see functions/src/notify.ts).
      // ignore: deprecated_member_use
      final token = await _messaging.getToken();
      if (token != null) await _saveToken(uid, token);
      // ignore: deprecated_member_use
      _messaging.onTokenRefresh.listen((t) => _saveToken(uid, t));
      return settings.authorizationStatus;
    } catch (e) {
      debugPrint('FCM registration skipped: ${e.runtimeType}');
      return AuthorizationStatus.notDetermined;
    }
  }

  Future<AuthorizationStatus> permissionStatus() async =>
      (await _messaging.getNotificationSettings()).authorizationStatus;

  Future<void> _saveToken(String uid, String token) => _db
          .collection('users')
          .doc(uid)
          .collection('devices')
          .doc(token.hashCode.toRadixString(16))
          .set({
        'token': token,
        'platform': 'android',
        'updatedAt': FieldValue.serverTimestamp()
      });

  Future<void> unregisterDevice(String uid) async {
    try {
      // ignore: deprecated_member_use
      final token = await _messaging.getToken();
      if (token != null) {
        await _db
            .collection('users')
            .doc(uid)
            .collection('devices')
            .doc(token.hashCode.toRadixString(16))
            .delete();
      }
      // ignore: deprecated_member_use
      await _messaging.deleteToken();
      // Stop FCM from silently creating a new token on next launch.
      await _messaging.setAutoInitEnabled(false);
    } catch (_) {}
  }

  Future<void> _guard(Future<void> Function() f) async {
    try {
      await f();
    } catch (e) {
      throw AppException.from(e);
    }
  }
}
