import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/router/app_router.dart';
import '../../../core/services/session_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../../family/data/family_repository.dart';
import '../../family/domain/family_models.dart';
import '../../routine/presentation/widgets/activity_summary_card.dart';
import '../../routine/presentation/widgets/activity_list.dart';

/// Activity tab: the user's own routine activity, plus care profiles in their
/// families whose activity has been shared with consent.
class ActivityScreen extends StatelessWidget {
  const ActivityScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = context.watch<SessionController>().uid;
    if (uid == null) return const Scaffold(body: KcLoading());
    final families = context.read<FamilyRepository>();
    return Scaffold(
      appBar: AppBar(title: const Text('Activity')),
      body: ListView(
        padding: const EdgeInsets.all(KcSpacing.md),
        children: [
          const ActivitySummaryCard(),
          const KcSectionHeader('Shared with you'),
          StreamBuilder<List<FamilyMember>>(
            stream: families.watchMyMemberships(uid),
            builder: (context, snap) {
              if (!snap.hasData) return const LinearProgressIndicator();
              if (snap.data!.isEmpty) {
                return const Text(
                    'Join or create a family to see shared activity.');
              }
              return Column(
                children: snap.data!
                    .map((m) => StreamBuilder<List<CareProfile>>(
                          stream: families.watchProfiles(m.familyId),
                          builder: (context, ps) {
                            final profiles = (ps.data ?? const <CareProfile>[])
                                .where((p) => p.linkedUserId != uid)
                                .toList();
                            return Column(
                              children: profiles
                                  .map((p) => Padding(
                                        padding:
                                            const EdgeInsets.only(bottom: 8),
                                        child: KcCard(
                                          padding: EdgeInsets.zero,
                                          onTap: p.sharingConsent.activity
                                              ? () => context.push(
                                                  '${Routes.routineHistory}?profileId=${p.id}&familyId=${p.familyId}')
                                              : null,
                                          child: ListTile(
                                            leading: const Icon(Icons.elderly),
                                            title: Text(p.displayName),
                                            subtitle: Text(p
                                                    .sharingConsent.activity
                                                ? 'Activity shared • tap to view'
                                                : 'Activity not shared'),
                                            trailing: Icon(
                                                p.sharingConsent.activity
                                                    ? Icons.chevron_right
                                                    : Icons.lock_outline),
                                          ),
                                        ),
                                      ))
                                  .toList(),
                            );
                          },
                        ))
                    .toList(),
              );
            },
          ),
          KcSectionHeader('Your recent activity',
              action: TextButton(
                  onPressed: () => context.push(Routes.routineHistory),
                  child: const Text('History'))),
          ActivityList(uid: uid, limit: 15),
        ],
      ),
    );
  }
}
