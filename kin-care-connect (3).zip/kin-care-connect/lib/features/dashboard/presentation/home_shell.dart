import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/services/session_controller.dart';
import '../../../core/services/settings_controller.dart';
import '../../notifications/data/notification_repository.dart';

/// Bottom navigation: Home, Family, Activity, Notifications, Profile.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.navigationShell});
  final StatefulNavigationShell navigationShell;

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  bool _registered = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final uid = context.read<SessionController>().uid;
    // Only if the user opted in to notifications on the Privacy choices
    // screen. Nobody is shown an unexplained permission prompt, and a
    // "no" is never asked again on its own (no nagging).
    if (!_registered &&
        uid != null &&
        context.read<SettingsController>().notificationsOptIn) {
      _registered = true;
      context.read<NotificationRepository>().registerDevice(uid);
    }
  }

  @override
  Widget build(BuildContext context) {
    final uid = context.watch<SessionController>().uid;
    return Scaffold(
      body: widget.navigationShell,
      bottomNavigationBar: StreamBuilder<int>(
        stream: uid == null
            ? const Stream.empty()
            : context.read<NotificationRepository>().watchUnreadCount(uid),
        builder: (context, snap) {
          final unread = snap.data ?? 0;
          return NavigationBar(
            selectedIndex: widget.navigationShell.currentIndex,
            onDestinationSelected: (i) => widget.navigationShell.goBranch(i,
                initialLocation: i == widget.navigationShell.currentIndex),
            destinations: [
              const NavigationDestination(
                  icon: Icon(Icons.home_outlined),
                  selectedIcon: Icon(Icons.home),
                  label: 'Home'),
              const NavigationDestination(
                  icon: Icon(Icons.diversity_3_outlined),
                  selectedIcon: Icon(Icons.diversity_3),
                  label: 'Family'),
              const NavigationDestination(
                  icon: Icon(Icons.timeline_outlined),
                  selectedIcon: Icon(Icons.timeline),
                  label: 'Activity'),
              NavigationDestination(
                icon: Badge(
                    isLabelVisible: unread > 0,
                    label: Text('$unread'),
                    child: const Icon(Icons.notifications_outlined)),
                selectedIcon: Badge(
                    isLabelVisible: unread > 0,
                    label: Text('$unread'),
                    child: const Icon(Icons.notifications)),
                label: 'Notifications',
                tooltip: unread > 0
                    ? 'Notifications, $unread unread'
                    : 'Notifications',
              ),
              const NavigationDestination(
                  icon: Icon(Icons.person_outline),
                  selectedIcon: Icon(Icons.person),
                  label: 'Profile'),
            ],
          );
        },
      ),
    );
  }
}
