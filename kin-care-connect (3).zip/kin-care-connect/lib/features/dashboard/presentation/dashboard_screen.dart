import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/router/app_router.dart';
import '../../../core/services/session_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../../auth/data/auth_repository.dart';
import '../../medical/data/medical_repository.dart';
import '../../medical/domain/medical_models.dart';
import '../../notifications/data/notification_repository.dart';
import '../../profile/presentation/widgets/avatar.dart';
import '../../reminders/data/reminder_repository.dart';
import '../../reminders/domain/reminder.dart';
import '../../routine/data/activity_repository.dart';
import '../../scam/data/scam_repository.dart';
import '../../scam/presentation/widgets/risk_chip.dart';

/// Module E: greeting header, six feature cards and recent information the
/// signed-in user is authorised to see (all queries are scoped to their uid;
/// rules reject anything else).
class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionController>();
    final user = session.user;
    final uid = session.uid;
    if (uid == null || (session.loading && user == null)) {
      return const Scaffold(body: KcLoading());
    }

    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(
                  KcSpacing.md, KcSpacing.md, KcSpacing.md, 0),
              sliver: SliverToBoxAdapter(
                child: Row(
                  children: [
                    Tooltip(
                      message: 'Open your profile',
                      child: Semantics(
                        button: true,
                        label: 'Open your profile',
                        excludeSemantics: true,
                        child: InkWell(
                          borderRadius: BorderRadius.circular(32),
                          onTap: () => context.go(Routes.profile),
                          child: UserAvatar(user: user, radius: 28),
                        ),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(Fmt.greeting(),
                              style: Theme.of(context).textTheme.bodyMedium),
                          Text(
                            user?.firstName.isNotEmpty == true
                                ? user!.firstName
                                : 'Welcome',
                            style: Theme.of(context)
                                .textTheme
                                .headlineSmall
                                ?.copyWith(fontWeight: FontWeight.w800),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                    StreamBuilder<int>(
                      stream: context
                          .read<NotificationRepository>()
                          .watchUnreadCount(uid),
                      builder: (context, s) {
                        final n = s.data ?? 0;
                        return IconButton.filledTonal(
                          iconSize: 28,
                          tooltip: n > 0
                              ? 'Notifications, $n unread'
                              : 'Notifications',
                          onPressed: () => context.go(Routes.notifications),
                          icon: Badge(
                              isLabelVisible: n > 0,
                              label: Text('$n'),
                              child: const Icon(Icons.notifications_outlined)),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
            const SliverToBoxAdapter(child: _VerifyEmailBanner()),
            SliverPadding(
              padding: const EdgeInsets.all(KcSpacing.md),
              sliver: SliverGrid.count(
                crossAxisCount: MediaQuery.sizeOf(context).width > 600 ? 3 : 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio:
                    MediaQuery.textScalerOf(context).scale(1) > 1.15
                        ? 0.78
                        : 0.98,
                children: [
                  KcFeatureCard(
                      title: 'Routine Monitor',
                      subtitle: 'Gentle, in-app activity awareness',
                      icon: Icons.monitor_heart_outlined,
                      onTap: () => context.push(Routes.routine)),
                  KcFeatureCard(
                      title: 'Medical Translator',
                      subtitle: 'Medical words in plain language',
                      icon: Icons.translate,
                      accent: KcColors.teal,
                      onTap: () => context.push(Routes.medical)),
                  KcFeatureCard(
                      title: 'Scam Shield',
                      subtitle: 'Check a suspicious message',
                      icon: Icons.shield_outlined,
                      accent: const Color(0xFF5B4BB7),
                      onTap: () => context.push(Routes.scam)),
                  KcFeatureCard(
                      title: 'Family Care',
                      subtitle: 'Coordinate with your family',
                      icon: Icons.diversity_3_outlined,
                      accent: const Color(0xFF2B7A4B),
                      onTap: () => context.go(Routes.family)),
                  KcFeatureCard(
                      title: 'Care Reminders',
                      subtitle: 'Medicines, visits and routines',
                      icon: Icons.alarm_outlined,
                      accent: const Color(0xFFB26A00),
                      onTap: () => context.push(Routes.reminders)),
                  KcFeatureCard(
                      title: 'Emergency Contacts',
                      subtitle: 'Call the people who matter',
                      icon: Icons.contact_phone_outlined,
                      accent: KcColors.riskHigh,
                      onTap: () => context.push(Routes.emergency)),
                ],
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: KcSpacing.md),
              sliver: SliverList.list(children: [
                _MonitoringStatusCard(uid: uid),
                KcSectionHeader('Upcoming reminders',
                    action: TextButton(
                        onPressed: () => context.push(Routes.reminders),
                        child: const Text('See all'))),
                _UpcomingReminders(uid: uid),
                KcSectionHeader('Recent activity',
                    action: TextButton(
                        onPressed: () => context.go(Routes.activity),
                        child: const Text('See all'))),
                _RecentActivity(uid: uid),
                KcSectionHeader('Recent medical summaries',
                    action: TextButton(
                        onPressed: () => context.push(Routes.medicalSummaries),
                        child: const Text('See all'))),
                _RecentSummaries(uid: uid),
                KcSectionHeader('Recent scam checks',
                    action: TextButton(
                        onPressed: () => context.push(Routes.scamHistory),
                        child: const Text('See all'))),
                _RecentScamChecks(uid: uid),
                const SizedBox(height: KcSpacing.xl),
              ]),
            ),
          ],
        ),
      ),
    );
  }
}

class _VerifyEmailBanner extends StatefulWidget {
  const _VerifyEmailBanner();
  @override
  State<_VerifyEmailBanner> createState() => _VerifyEmailBannerState();
}

class _VerifyEmailBannerState extends State<_VerifyEmailBanner> {
  bool _hidden = false;

  @override
  Widget build(BuildContext context) {
    final auth = context.read<AuthRepository>();
    if (_hidden || auth.emailVerified) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(
          KcSpacing.md, KcSpacing.md, KcSpacing.md, 0),
      child: KcCard(
        color: Theme.of(context).colorScheme.tertiaryContainer,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Please verify your email',
                style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            const Text(
                'We sent you a link. Verifying lets you join family groups safely.'),
            Wrap(
              spacing: 8,
              children: [
                TextButton(
                  onPressed: () => runGuarded(
                      context, auth.sendEmailVerification,
                      success: 'Verification email sent.'),
                  child: const Text('Resend email'),
                ),
                TextButton(
                  onPressed: () async {
                    final ok = await auth.reloadAndCheckVerified();
                    if (!context.mounted) return;
                    if (ok) {
                      setState(() => _hidden = true);
                      showSnack(context, 'Thanks! Your email is verified.');
                    } else {
                      showSnack(context,
                          'Not verified yet. Please tap the link in the email.');
                    }
                  },
                  child: const Text("I've verified"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _MonitoringStatusCard extends StatelessWidget {
  const _MonitoringStatusCard({required this.uid});
  final String uid;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<MonitoringState>(
      stream: context.read<ActivityRepository>().watchState(uid),
      builder: (context, snap) {
        final active = snap.data?.active ?? false;
        final color =
            active ? KcColors.riskLow : Theme.of(context).colorScheme.outline;
        return KcCard(
          onTap: () => context.push(Routes.routine),
          semanticLabel: active
              ? 'Routine monitoring is on while the app is open'
              : 'Routine monitoring is off',
          child: Row(
            children: [
              Icon(active ? Icons.radio_button_checked : Icons.radio_button_off,
                  color: color, size: 32),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(active ? 'Monitoring is ON' : 'Monitoring is OFF',
                        style: Theme.of(context).textTheme.titleMedium),
                    Text(active
                        ? 'Only while the app is open'
                        : 'Tap to learn more and start'),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right),
            ],
          ),
        );
      },
    );
  }
}

class _UpcomingReminders extends StatelessWidget {
  const _UpcomingReminders({required this.uid});
  final String uid;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Reminder>>(
      stream: context.read<ReminderRepository>().watchMine(uid, limit: 20),
      builder: (context, snap) {
        if (snap.hasError) return const Text('Reminders could not be loaded.');
        if (!snap.hasData) return const LinearProgressIndicator();
        final items = snap.data!
            .where((r) => r.status == CompletionStatus.pending)
            .take(3)
            .toList();
        if (items.isEmpty) return const _EmptyLine('No upcoming reminders.');
        return Column(
          children: items
              .map((r) => _Tile(
                    icon: Icons.alarm,
                    title: r.title,
                    subtitle: '${r.type.label} • ${Fmt.dateTime(r.nextDueAt)}',
                    trailing: r.isOverdue
                        ? const KcChip('Due', color: KcColors.riskMedium)
                        : null,
                    onTap: () => context.push(Routes.reminders),
                  ))
              .toList(),
        );
      },
    );
  }
}

class _RecentActivity extends StatelessWidget {
  const _RecentActivity({required this.uid});
  final String uid;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ActivityRecord>>(
      stream: context.read<ActivityRepository>().watchMine(uid, limit: 3),
      builder: (context, snap) {
        if (snap.hasError) return const Text('Activity could not be loaded.');
        if (!snap.hasData) return const LinearProgressIndicator();
        if (snap.data!.isEmpty) {
          return const _EmptyLine('No activity recorded yet.');
        }
        return Column(
          children: snap.data!
              .map((a) => _Tile(
                  icon: Icons.touch_app_outlined,
                  title: a.type.label,
                  subtitle: Fmt.relative(a.timestamp)))
              .toList(),
        );
      },
    );
  }
}

class _RecentSummaries extends StatelessWidget {
  const _RecentSummaries({required this.uid});
  final String uid;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<MedicalSummary>>(
      stream: context.read<MedicalRepository>().watchSummaries(uid, limit: 3),
      builder: (context, snap) {
        if (snap.hasError) return const Text('Summaries could not be loaded.');
        if (!snap.hasData) return const LinearProgressIndicator();
        if (snap.data!.isEmpty) {
          return const _EmptyLine('No saved medical summaries.');
        }
        return Column(
          children: snap.data!
              .map((s) => _Tile(
                  icon: Icons.description_outlined,
                  title: s.title,
                  subtitle: Fmt.date(s.createdAt),
                  onTap: () => context.push(Routes.summary(s.id))))
              .toList(),
        );
      },
    );
  }
}

class _RecentScamChecks extends StatelessWidget {
  const _RecentScamChecks({required this.uid});
  final String uid;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ScamCheckRecord>>(
      stream: context.read<ScamRepository>().watchHistory(uid, limit: 3),
      builder: (context, snap) {
        if (snap.hasError) {
          return const Text('Scam checks could not be loaded.');
        }
        if (!snap.hasData) return const LinearProgressIndicator();
        if (snap.data!.isEmpty) return const _EmptyLine('No scam checks yet.');
        return Column(
          children: snap.data!
              .map((c) => _Tile(
                    icon: Icons.shield_outlined,
                    title: c.indicatorTitles.isEmpty
                        ? 'No warning signs found'
                        : c.indicatorTitles.first,
                    subtitle:
                        '${c.inputType.toUpperCase()} • ${Fmt.relative(c.createdAt)}',
                    trailing: RiskChip(level: c.riskLevel),
                  ))
              .toList(),
        );
      },
    );
  }
}

class _Tile extends StatelessWidget {
  const _Tile(
      {required this.icon,
      required this.title,
      required this.subtitle,
      this.trailing,
      this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: KcCard(
        padding: EdgeInsets.zero,
        onTap: onTap,
        child: ListTile(
          leading: Icon(icon),
          title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text(subtitle),
          trailing: trailing,
        ),
      ),
    );
  }
}

class _EmptyLine extends StatelessWidget {
  const _EmptyLine(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Text(text,
            style: TextStyle(color: Theme.of(context).colorScheme.outline)),
      );
}
