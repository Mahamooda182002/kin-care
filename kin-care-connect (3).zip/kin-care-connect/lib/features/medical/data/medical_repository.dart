import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

import '../../../core/services/functions_service.dart';
import '../../../core/utils/app_exception.dart';
import '../domain/medical_models.dart';

class MedicalRepository {
  MedicalRepository(this._db, this._storage, this._functions);
  final FirebaseFirestore _db;
  final FirebaseStorage _storage;
  final FunctionsService _functions;

  CollectionReference<Map<String, dynamic>> get _summaries =>
      _db.collection('medicalSummaries');
  CollectionReference<Map<String, dynamic>> get _recordings =>
      _db.collection('recordings');

  // ---------- AI (server-side) ----------

  /// POST /api/medical/explain — explains terms, abbreviations, instructions.
  Future<MedicalExplanation> explain(String text,
      {String language = 'en'}) async {
    final r = await _functions.call('medicalExplain',
        {'text': text, 'language': language}, const Duration(seconds: 90));
    return MedicalExplanation.fromMap(r);
  }

  /// POST /api/medical/summarize — structured summary of longer notes or a transcript.
  Future<MedicalExplanation> summarize(String text,
      {String language = 'en'}) async {
    final r = await _functions.call('medicalSummarize',
        {'text': text, 'language': language}, const Duration(seconds: 90));
    return MedicalExplanation.fromMap(r);
  }

  /// POST /api/medical/transcribe — transcribes an uploaded recording. Returns
  /// the transcript text; it is shown for review/correction before any AI
  /// explanation runs.
  Future<String> transcribe(String recordingId,
      {String language = 'en'}) async {
    final r = await _functions.call(
        'medicalTranscribe',
        {'recordingId': recordingId, 'language': language},
        const Duration(seconds: 300));
    final t = (r['transcript'] as String?)?.trim() ?? '';
    if (t.isEmpty) {
      throw const AppException(
          'No speech could be recognised in this recording.');
    }
    return t;
  }

  // ---------- Recordings ----------

  Stream<List<RecordingItem>> watchRecordings(String uid) => _recordings
      .where('userId', isEqualTo: uid)
      .where('deletionStatus', isEqualTo: 'active')
      .orderBy('createdAt', descending: true)
      .snapshots()
      .map((s) => s.docs.map(RecordingItem.fromDoc).toList());

  /// Uploads an audio file the user recorded after giving consent.
  Future<String> uploadRecording(
      {required String uid,
      required File file,
      required int durationSeconds,
      required String consentReference,
      String? profileId}) async {
    try {
      final doc = _recordings.doc();
      final path = 'recordings/$uid/${doc.id}.m4a';
      // The consent record (metadata) is written first: storage.rules only
      // accept the audio when this document exists, belongs to the user,
      // names this exact path and carries the consent reference.
      await doc.set({
        'recordingId': doc.id,
        'userId': uid,
        'profileId': profileId,
        'storageReference': path,
        'consentReference': consentReference,
        'durationSeconds': durationSeconds,
        'transcriptionStatus': 'uploaded',
        'deletionStatus': 'active',
        'createdAt': FieldValue.serverTimestamp(),
      });
      try {
        await _storage
            .ref(path)
            .putFile(file, SettableMetadata(contentType: 'audio/mp4'));
      } catch (_) {
        // No audio, no record: remove the metadata so nothing dangles.
        try {
          await doc.delete();
        } catch (_) {}
        rethrow;
      }
      // Remove the local copy once safely uploaded.
      try {
        await file.delete();
      } catch (_) {}
      return doc.id;
    } catch (e) {
      throw AppException.from(e);
    }
  }

  Future<String> recordingDownloadUrl(String storagePath) async {
    try {
      return await _storage.ref(storagePath).getDownloadURL();
    } catch (e) {
      throw AppException.from(e);
    }
  }

  Future<void> deleteRecording(RecordingItem r) async {
    try {
      try {
        await _storage.ref(r.storageReference).delete();
      } on FirebaseException catch (e) {
        if (e.code != 'object-not-found') rethrow;
      }
      await _recordings.doc(r.id).update({
        'deletionStatus': 'deleted',
        'transcript': FieldValue.delete(),
        'deletedAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      throw AppException.from(e);
    }
  }

  // ---------- Summaries ----------

  Stream<List<MedicalSummary>> watchSummaries(String uid, {int limit = 50}) =>
      _summaries
          .where('userId', isEqualTo: uid)
          .orderBy('createdAt', descending: true)
          .limit(limit)
          .snapshots()
          .map((s) => s.docs.map(MedicalSummary.fromDoc).toList());

  Stream<MedicalSummary?> watchSummary(String id) => _summaries
      .doc(id)
      .snapshots()
      .map((d) => d.exists ? MedicalSummary.fromDoc(d) : null);

  Future<String> saveSummary({
    required String uid,
    required String title,
    required String originalText,
    required String summaryText,
    required String language,
    String? profileId,
    String? familyId,
    bool sharedWithFamily = false,
  }) async {
    try {
      final doc = _summaries.doc();
      await doc.set({
        'summaryId': doc.id,
        'userId': uid,
        'title': title.trim().isEmpty ? 'Medical summary' : title.trim(),
        'profileId': profileId,
        'familyId': familyId,
        'sharedWithFamily': sharedWithFamily && profileId != null,
        'originalText': originalText,
        'summaryText': summaryText,
        'language': language,
        'retentionStatus': 'keep',
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      return doc.id;
    } catch (e) {
      throw AppException.from(e);
    }
  }

  Future<void> updateSummary(String id,
      {required String title, required String summaryText}) async {
    try {
      await _summaries.doc(id).update({
        'title': title.trim(),
        'summaryText': summaryText,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      throw AppException.from(e);
    }
  }

  Future<void> deleteSummary(String id) async {
    try {
      await _summaries.doc(id).delete();
    } catch (e) {
      throw AppException.from(e);
    }
  }
}
