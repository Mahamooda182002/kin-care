import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../core/utils/app_exception.dart';
import '../../../../core/utils/formatters.dart';
import '../../../../core/widgets/kc_dialogs.dart';
import '../../../../core/widgets/kc_widgets.dart';
import '../../data/medical_repository.dart';
import '../../domain/medical_models.dart';
import '../ai_consent.dart';
import '../transcript_review_screen.dart';

/// Lists the user's recordings with play, transcribe and delete actions.
class RecordingsList extends StatefulWidget {
  const RecordingsList({super.key, required this.uid, required this.language});
  final String uid;
  final String language;

  @override
  State<RecordingsList> createState() => _RecordingsListState();
}

class _RecordingsListState extends State<RecordingsList> {
  final _player = AudioPlayer();
  String? _playingId;
  String? _busyId;

  @override
  void initState() {
    super.initState();
    _player.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _playingId = null);
    });
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  Future<void> _togglePlay(RecordingItem r) async {
    if (_playingId == r.id) {
      await _player.stop();
      setState(() => _playingId = null);
      return;
    }
    await runGuarded(context, () async {
      final url = await context
          .read<MedicalRepository>()
          .recordingDownloadUrl(r.storageReference);
      await _player.play(UrlSource(url));
      setState(() => _playingId = r.id);
    });
  }

  Future<void> _delete(RecordingItem r) async {
    final ok = await showConfirmDialog(context,
        title: 'Delete recording?',
        message: 'The audio and its transcript will be permanently deleted.',
        confirmLabel: 'Delete',
        destructive: true);
    if (!ok || !mounted) return;
    if (_playingId == r.id) await _player.stop();
    if (!mounted) return;
    await runGuarded(
        context, () => context.read<MedicalRepository>().deleteRecording(r),
        success: 'Recording deleted.');
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<RecordingItem>>(
      stream: context.read<MedicalRepository>().watchRecordings(widget.uid),
      builder: (context, snap) {
        if (snap.hasError) {
          return KcErrorView(message: AppException.from(snap.error!).message);
        }
        if (!snap.hasData) return const KcLoading();
        if (snap.data!.isEmpty) {
          return const KcEmptyView(
              icon: Icons.mic_off_outlined,
              title: 'No recordings',
              message: 'Recordings you make will appear here.');
        }
        return Column(
          children: snap.data!.map((r) {
            final busy = _busyId == r.id;
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: KcCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Recording • ${Fmt.dateTime(r.createdAt)}',
                        style: Theme.of(context).textTheme.titleMedium),
                    Text(
                        '${(r.durationSeconds / 60).floor()}m ${r.durationSeconds % 60}s • ${r.transcript != null ? 'Transcribed' : 'Not transcribed yet'}'),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        OutlinedButton.icon(
                          style: OutlinedButton.styleFrom(
                              minimumSize: const Size(0, 48)),
                          onPressed: () => _togglePlay(r),
                          icon: Icon(_playingId == r.id
                              ? Icons.stop
                              : Icons.play_arrow),
                          label: Text(_playingId == r.id ? 'Stop' : 'Play'),
                        ),
                        FilledButton.tonalIcon(
                          style: FilledButton.styleFrom(
                              minimumSize: const Size(0, 48)),
                          onPressed: busy ? null : () => _openTranscript(r),
                          icon: busy
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child:
                                      CircularProgressIndicator(strokeWidth: 2))
                              : const Icon(Icons.subtitles_outlined),
                          label: Text(r.transcript != null
                              ? 'Review transcript'
                              : 'Transcribe'),
                        ),
                        TextButton.icon(
                          onPressed: () => _delete(r),
                          icon: const Icon(Icons.delete_outline),
                          label: const Text('Delete'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
        );
      },
    );
  }

  Future<void> _openTranscript(RecordingItem r) async {
    if (!await ensureMedicalAiConsent(context)) return;
    if (!mounted) return;
    setState(() => _busyId = r.id);
    try {
      final text = r.transcript?.isNotEmpty == true
          ? r.transcript!
          : await context
              .read<MedicalRepository>()
              .transcribe(r.id, language: widget.language);
      if (!mounted) return;
      await Navigator.of(context).push(MaterialPageRoute<void>(
        builder: (_) =>
            TranscriptReviewScreen(transcript: text, language: widget.language),
      ));
    } catch (e) {
      if (mounted) {
        showSnack(context, AppException.from(e).message, error: true);
      }
    } finally {
      if (mounted) setState(() => _busyId = null);
    }
  }
}
