import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/router/app_router.dart';
import '../../../core/services/session_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_exception.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/validators.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../data/medical_repository.dart';
import '../domain/medical_models.dart';

class SummariesScreen extends StatelessWidget {
  const SummariesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = context.watch<SessionController>().uid;
    if (uid == null) return const Scaffold(body: KcLoading());
    return Scaffold(
      appBar: AppBar(title: const Text('Medical summaries')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => context.push(Routes.medical),
        icon: const Icon(Icons.add),
        label: const Text('New'),
      ),
      body: StreamBuilder<List<MedicalSummary>>(
        stream: context.read<MedicalRepository>().watchSummaries(uid),
        builder: (context, snap) {
          if (snap.hasError) {
            return KcErrorView(message: AppException.from(snap.error!).message);
          }
          if (!snap.hasData) return const KcLoading();
          if (snap.data!.isEmpty) {
            return const KcEmptyView(
                icon: Icons.description_outlined,
                title: 'No summaries yet',
                message: 'Explain some medical text and save it here.');
          }
          return ListView.separated(
            padding: const EdgeInsets.all(KcSpacing.md),
            itemCount: snap.data!.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, i) {
              final s = snap.data![i];
              return KcCard(
                padding: EdgeInsets.zero,
                onTap: () => context.push(Routes.summary(s.id)),
                child: ListTile(
                  leading: const Icon(Icons.description_outlined),
                  title: Text(s.title),
                  subtitle: Text(
                      'Created ${Fmt.date(s.createdAt)}${s.sharedWithFamily ? ' • Shared with family' : ''}'),
                  trailing: const Icon(Icons.chevron_right),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class SummaryDetailScreen extends StatefulWidget {
  const SummaryDetailScreen({super.key, required this.summaryId});
  final String summaryId;

  @override
  State<SummaryDetailScreen> createState() => _SummaryDetailScreenState();
}

class _SummaryDetailScreenState extends State<SummaryDetailScreen> {
  bool _editing = false;
  final _form = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _body = TextEditingController();

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final repo = context.read<MedicalRepository>();
    final uid = context.watch<SessionController>().uid;
    return StreamBuilder<MedicalSummary?>(
      stream: repo.watchSummary(widget.summaryId),
      builder: (context, snap) {
        if (snap.hasError) {
          return Scaffold(
              appBar: AppBar(),
              body:
                  KcErrorView(message: AppException.from(snap.error!).message));
        }
        if (!snap.hasData && snap.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: KcLoading());
        }
        final s = snap.data;
        if (s == null) {
          return Scaffold(
              appBar: AppBar(),
              body: const KcEmptyView(
                  icon: Icons.search_off, title: 'Summary not found'));
        }
        final isOwner = s.userId == uid;
        return Scaffold(
          appBar: AppBar(
            title: Text(_editing ? 'Edit summary' : s.title),
            actions: [
              if (isOwner && !_editing)
                IconButton(
                  tooltip: 'Edit',
                  icon: const Icon(Icons.edit_outlined),
                  onPressed: () => setState(() {
                    _title.text = s.title;
                    _body.text = s.summaryText;
                    _editing = true;
                  }),
                ),
              if (isOwner)
                IconButton(
                  tooltip: 'Delete',
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () async {
                    final ok = await showConfirmDialog(context,
                        title: 'Delete summary?',
                        message: 'This cannot be undone.',
                        confirmLabel: 'Delete',
                        destructive: true);
                    if (!ok || !context.mounted) return;
                    final done = await runGuarded(context, () async {
                      await repo.deleteSummary(s.id);
                      return true;
                    }, success: 'Summary deleted.');
                    if (done == true && context.mounted) context.pop();
                  },
                ),
            ],
          ),
          body: _editing
              ? Form(
                  key: _form,
                  child: ListView(
                      padding: const EdgeInsets.all(KcSpacing.md),
                      children: [
                        KcTextField(
                            label: 'Title',
                            controller: _title,
                            validator: (v) =>
                                Validators.required(v, field: 'Title')),
                        const SizedBox(height: 12),
                        KcTextField(
                            label: 'Summary',
                            controller: _body,
                            maxLines: 20,
                            minLines: 10,
                            validator: (v) =>
                                Validators.required(v, field: 'Summary')),
                        const SizedBox(height: 16),
                        KcButton(
                          label: 'Save changes',
                          onPressed: () async {
                            if (!_form.currentState!.validate()) return;
                            await runGuarded(
                                context,
                                () => repo.updateSummary(s.id,
                                    title: _title.text,
                                    summaryText: _body.text),
                                success: 'Saved.');
                            if (mounted) setState(() => _editing = false);
                          },
                        ),
                        TextButton(
                            onPressed: () => setState(() => _editing = false),
                            child: const Text('Cancel')),
                      ]),
                )
              : ListView(
                  padding: const EdgeInsets.all(KcSpacing.md),
                  children: [
                    Text(
                        'Created ${Fmt.dateTime(s.createdAt)}${s.updatedAt != null ? ' • Updated ${Fmt.dateTime(s.updatedAt!)}' : ''}'),
                    const SizedBox(height: 12),
                    const KcNotice(
                        text: medicalDisclaimer,
                        icon: Icons.health_and_safety_outlined),
                    const SizedBox(height: 12),
                    KcCard(child: SelectableText(s.summaryText)),
                    if (isOwner) ...[
                      const KcSectionHeader('Original text'),
                      KcCard(child: SelectableText(s.originalText)),
                    ],
                  ],
                ),
        );
      },
    );
  }
}
