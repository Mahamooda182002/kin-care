import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/router/app_router.dart';
import '../../../core/services/session_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/validators.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../../family/data/family_repository.dart';
import '../../family/domain/family_models.dart';
import '../data/medical_repository.dart';
import '../domain/medical_models.dart';

class MedicalResultArgs {
  const MedicalResultArgs(
      {required this.originalText,
      required this.explanation,
      required this.language,
      this.fromTranscript = false});
  final String originalText;
  final MedicalExplanation explanation;
  final String language;
  final bool fromTranscript;
}

/// Shows the structured explanation, clearly separating what came from the
/// user's own text from what the AI generated, then lets the user edit and
/// save it as a medical summary.
class MedicalResultScreen extends StatelessWidget {
  const MedicalResultScreen({super.key, required this.args});
  final MedicalResultArgs args;

  @override
  Widget build(BuildContext context) {
    final e = args.explanation;
    return Scaffold(
      appBar: AppBar(title: const Text('Simple explanation')),
      body: ListView(
        padding: const EdgeInsets.all(KcSpacing.md),
        children: [
          KcNotice(text: e.disclaimer, icon: Icons.health_and_safety_outlined),
          for (final s in e.safetyNotices) ...[
            const SizedBox(height: 8),
            KcNotice(
                text: s,
                tone: KcNoticeTone.warning,
                icon: Icons.warning_amber_outlined),
          ],
          if (e.summary.isNotEmpty) ...[
            const KcSectionHeader('Summary (AI explanation)'),
            KcCard(child: Text(e.summary)),
          ],
          if (e.terms.isNotEmpty) ...[
            const KcSectionHeader('Medical terms (AI explanation)'),
            ...e.terms.map((t) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: KcCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(t.term,
                            style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 6),
                        Text.rich(TextSpan(children: [
                          const TextSpan(
                              text: 'Simple explanation: ',
                              style: TextStyle(fontWeight: FontWeight.w700)),
                          TextSpan(text: t.simpleExplanation),
                        ])),
                        if (t.whatItMeans.isNotEmpty) ...[
                          const SizedBox(height: 4),
                          Text.rich(TextSpan(children: [
                            const TextSpan(
                                text: 'What it means: ',
                                style: TextStyle(fontWeight: FontWeight.w700)),
                            TextSpan(text: t.whatItMeans),
                          ])),
                        ],
                      ],
                    ),
                  ),
                )),
          ],
          if (e.abbreviations.isNotEmpty) ...[
            const KcSectionHeader('Abbreviations'),
            KcCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: e.abbreviations.entries
                    .map((a) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Text.rich(TextSpan(children: [
                            TextSpan(
                                text: '${a.key}: ',
                                style: const TextStyle(
                                    fontWeight: FontWeight.w700)),
                            TextSpan(text: a.value),
                          ])),
                        ))
                    .toList(),
              ),
            ),
          ],
          if (e.instructionsFromText.isNotEmpty || e.keyDates.isNotEmpty) ...[
            const KcSectionHeader('From your text'),
            KcCard(
              color: KcColors.blueLight,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                      'These lines were found in what you entered. Check them against the original.',
                      style: TextStyle(color: KcColors.ink)),
                  const SizedBox(height: 8),
                  ...e.instructionsFromText
                      .map((i) => _Bullet(i, color: KcColors.ink)),
                  ...e.keyDates.map((d) => _Bullet(
                      '${d.date}: ${d.description}',
                      icon: Icons.event,
                      color: KcColors.ink)),
                ],
              ),
            ),
          ],
          if (e.followUpActions.isNotEmpty) ...[
            const KcSectionHeader('Follow-up actions'),
            KcCard(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: e.followUpActions
                        .map(
                            (a) => _Bullet(a, icon: Icons.check_circle_outline))
                        .toList())),
          ],
          if (e.questionsForDoctor.isNotEmpty) ...[
            const KcSectionHeader('Questions to ask your doctor'),
            KcCard(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: e.questionsForDoctor
                        .map((q) => _Bullet(q, icon: Icons.help_outline))
                        .toList())),
          ],
          if (e.uncertainties.isNotEmpty) ...[
            const KcSectionHeader('Unclear or incomplete'),
            KcCard(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: e.uncertainties
                        .map((u) => _Bullet(u,
                            icon: Icons.report_gmailerrorred_outlined))
                        .toList())),
          ],
          const SizedBox(height: KcSpacing.lg),
          KcButton(
            label: 'Edit and save summary',
            icon: Icons.save_outlined,
            onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
              builder: (_) => SummaryEditorScreen(args: args),
            )),
          ),
          const SizedBox(height: KcSpacing.xl),
        ],
      ),
    );
  }
}

class _Bullet extends StatelessWidget {
  const _Bullet(this.text, {this.icon = Icons.circle, this.color});
  final String text;
  final IconData icon;
  final Color? color;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(
              padding: const EdgeInsets.only(top: 3),
              child: Icon(icon,
                  size: icon == Icons.circle ? 8 : 20, color: color)),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: TextStyle(color: color))),
        ]),
      );
}

/// Editable summary, optionally shared with a family care profile.
class SummaryEditorScreen extends StatefulWidget {
  const SummaryEditorScreen({super.key, required this.args});
  final MedicalResultArgs args;

  @override
  State<SummaryEditorScreen> createState() => _SummaryEditorScreenState();
}

class _SummaryEditorScreenState extends State<SummaryEditorScreen> {
  final _form = GlobalKey<FormState>();
  final _title = TextEditingController();
  late final _body =
      TextEditingController(text: widget.args.explanation.toEditableText());
  CareProfile? _shareWith;
  bool _saving = false;

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final uid = context.read<SessionController>().uid!;
    setState(() => _saving = true);
    final id = await runGuarded(
      context,
      () => context.read<MedicalRepository>().saveSummary(
            uid: uid,
            title: _title.text,
            originalText: widget.args.originalText,
            summaryText: _body.text,
            language: widget.args.language,
            profileId: _shareWith?.id,
            familyId: _shareWith?.familyId,
            sharedWithFamily: _shareWith != null,
          ),
      success: 'Summary saved.',
    );
    if (!mounted) return;
    setState(() => _saving = false);
    if (id != null) context.go(Routes.summary(id));
  }

  @override
  Widget build(BuildContext context) {
    final uid = context.watch<SessionController>().uid;
    return Scaffold(
      appBar: AppBar(title: const Text('Save summary')),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(KcSpacing.md),
          children: [
            KcTextField(
                label: 'Title',
                hint: 'e.g. Cardiology visit, 3 Nov',
                controller: _title,
                maxLength: 100,
                validator: (v) => Validators.required(v, field: 'Title')),
            const SizedBox(height: KcSpacing.sm),
            KcTextField(
                label: 'Summary',
                controller: _body,
                maxLines: 18,
                minLines: 10,
                validator: (v) =>
                    Validators.required(v, field: 'Summary') ??
                    Validators.maxLength(v, 20000)),
            const SizedBox(height: KcSpacing.md),
            if (uid != null)
              _ShareSelector(
                  uid: uid,
                  value: _shareWith,
                  onChanged: (p) => setState(() => _shareWith = p)),
            const SizedBox(height: KcSpacing.lg),
            KcButton(
                label: 'Save',
                icon: Icons.save,
                loading: _saving,
                onPressed: _save),
          ],
        ),
      ),
    );
  }
}

/// Lets the user choose a care profile to share with. Family members only see
/// it if that profile's medical-sharing consent is on (enforced by rules).
class _ShareSelector extends StatelessWidget {
  const _ShareSelector(
      {required this.uid, required this.value, required this.onChanged});
  final String uid;
  final CareProfile? value;
  final ValueChanged<CareProfile?> onChanged;

  @override
  Widget build(BuildContext context) {
    final fam = context.read<FamilyRepository>();
    return StreamBuilder<List<FamilyMember>>(
      stream: fam.watchMyMemberships(uid),
      builder: (context, ms) {
        final memberships = (ms.data ?? const <FamilyMember>[])
            .where((m) => m.role != FamilyRole.viewer)
            .toList();
        if (memberships.isEmpty) {
          return const Text('Saved privately to your account.');
        }
        return Column(
          children: memberships
              .map((m) => StreamBuilder<List<CareProfile>>(
                    stream: fam.watchProfiles(m.familyId),
                    builder: (context, ps) {
                      final profiles = ps.data ?? const <CareProfile>[];
                      if (profiles.isEmpty) return const SizedBox.shrink();
                      return DropdownButtonFormField<String?>(
                        initialValue: profiles.any((p) => p.id == value?.id)
                            ? value!.id
                            : null,
                        isExpanded: true,
                        decoration: const InputDecoration(
                            labelText:
                                'Share with family care profile (optional)'),
                        items: [
                          const DropdownMenuItem<String?>(
                              value: null, child: Text('Keep private')),
                          ...profiles.map((p) => DropdownMenuItem<String?>(
                                value: p.id,
                                child: Text(
                                    '${p.displayName}${p.sharingConsent.medical ? '' : ' (medical sharing not approved)'}'),
                              )),
                        ],
                        onChanged: (id) async {
                          if (id == null) return onChanged(null);
                          final p = profiles.firstWhere((x) => x.id == id);
                          final ok = await showConfirmDialog(context,
                              title: 'Share this summary?',
                              message:
                                  'Family administrators and assigned caregivers for ${p.displayName} will be able to read this summary'
                                  '${p.sharingConsent.medical ? '.' : ' once medical sharing is approved for this profile.'}',
                              confirmLabel: 'Share');
                          onChanged(ok ? p : null);
                        },
                      );
                    },
                  ))
              .toList(),
        );
      },
    );
  }
}
