import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:record/record.dart';

import '../../../core/services/session_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/theme/contrast.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../data/medical_repository.dart';

enum _RecState { idle, recording, paused, stopped, uploading }

/// Audio recording with explicit consent, clear status and
/// start / pause / resume / stop controls, then review (keep or discard).
class RecordingScreen extends StatefulWidget {
  const RecordingScreen({super.key});

  @override
  State<RecordingScreen> createState() => _RecordingScreenState();
}

class _RecordingScreenState extends State<RecordingScreen> {
  final _recorder = AudioRecorder();
  _RecState _state = _RecState.idle;
  String? _path;
  Duration _elapsed = Duration.zero;
  Timer? _timer;
  bool _consentGiven = false;
  String? _consentReference;

  static const maxDuration = Duration(minutes: 30);

  @override
  void dispose() {
    _timer?.cancel();
    _recorder.dispose();
    // Leaving without saving: don't leave an unsaved recording on the phone.
    if (_state != _RecState.uploading) _deleteLocalFile();
    super.dispose();
  }

  Future<bool> _askConsent() async {
    final ok = await showConfirmDialog(
      context,
      title: 'Consent to record',
      message: 'Before recording, confirm that:\n\n'
          '• Everyone in the conversation (including the doctor) knows it is being recorded and agrees.\n'
          '• The recording is only for helping you understand the medical information.\n\n'
          'The audio is stored privately in your account and deleted after 30 days, or sooner if you delete it.',
      confirmLabel: 'Everyone agrees',
      cancelLabel: 'Cancel',
      equalWeight: true,
    );
    if (ok) {
      _consentGiven = true;
      _consentReference =
          'in-app-consent:${DateTime.now().toUtc().toIso8601String()}';
    }
    return ok;
  }

  Future<void> _start() async {
    if (!_consentGiven && !await _askConsent()) return;
    if (!await _recorder.hasPermission()) {
      if (mounted) {
        showSnack(context,
            'Microphone permission is needed to record. You can allow it in Android settings.',
            error: true);
      }
      return;
    }
    final dir = await getTemporaryDirectory();
    _path = '${dir.path}/kcc_${DateTime.now().millisecondsSinceEpoch}.m4a';
    await _recorder.start(
        const RecordConfig(
            encoder: AudioEncoder.aacLc,
            sampleRate: 16000,
            numChannels: 1,
            bitRate: 64000),
        path: _path!);
    _elapsed = Duration.zero;
    _startTimer();
    setState(() => _state = _RecState.recording);
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() => _elapsed += const Duration(seconds: 1));
      if (_elapsed >= maxDuration) _stop();
    });
  }

  Future<void> _pause() async {
    await _recorder.pause();
    _timer?.cancel();
    setState(() => _state = _RecState.paused);
  }

  Future<void> _resume() async {
    await _recorder.resume();
    _startTimer();
    setState(() => _state = _RecState.recording);
  }

  Future<void> _stop() async {
    _timer?.cancel();
    final p = await _recorder.stop();
    if (p != null) _path = p;
    setState(() => _state = _RecState.stopped);
  }

  Future<void> _discard() async {
    final ok = await showConfirmDialog(context,
        title: 'Discard recording?',
        message: 'This recording will be deleted from your phone.',
        confirmLabel: 'Discard',
        destructive: true);
    if (!ok) return;
    if (_path != null) {
      try {
        await File(_path!).delete();
      } catch (_) {}
    }
    setState(() {
      _state = _RecState.idle;
      _path = null;
      _elapsed = Duration.zero;
    });
  }

  Future<void> _save() async {
    final uid = context.read<SessionController>().uid;
    if (uid == null || _path == null) return;
    setState(() => _state = _RecState.uploading);
    final id = await runGuarded(
      context,
      () => context.read<MedicalRepository>().uploadRecording(
            uid: uid,
            file: File(_path!),
            durationSeconds: _elapsed.inSeconds,
            consentReference: _consentReference ?? 'unknown',
          ),
      success: 'Recording saved. You can transcribe it from your recordings.',
    );
    if (id != null) {
      // Data minimisation: the upload succeeded, so remove the local copy.
      await _deleteLocalFile();
    }
    if (!mounted) return;
    if (id != null) {
      context.pop();
    } else {
      setState(() => _state = _RecState.stopped);
    }
  }

  Future<void> _deleteLocalFile() async {
    final path = _path;
    _path = null;
    if (path == null) return;
    try {
      final f = File(path);
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }

  String get _clock {
    final m = _elapsed.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = _elapsed.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '${_elapsed.inHours > 0 ? '${_elapsed.inHours}:' : ''}$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final (label, color) = switch (_state) {
      _RecState.idle => (
          'Ready to record',
          Theme.of(context).colorScheme.outline
        ),
      _RecState.recording => ('Recording…', KcColors.riskHigh),
      _RecState.paused => ('Paused', KcColors.riskMedium),
      _RecState.stopped => ('Recording finished', KcColors.teal),
      _RecState.uploading => ('Uploading…', KcColors.blue),
    };

    return PopScope(
      canPop: _state == _RecState.idle || _state == _RecState.stopped,
      child: Scaffold(
        appBar: AppBar(title: const Text('Record conversation')),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(KcSpacing.lg),
            child: Column(
              children: [
                const Spacer(),
                Semantics(
                  liveRegion: true,
                  label: '$label, $_clock',
                  child: Column(
                    children: [
                      Icon(
                          _state == _RecState.recording
                              ? Icons.mic
                              : Icons.mic_none,
                          size: 96,
                          color: color),
                      const SizedBox(height: 12),
                      Text(label,
                          style: Theme.of(context)
                              .textTheme
                              .titleLarge
                              ?.copyWith(
                                  color: ensureContrast(
                                      color,
                                      Theme.of(context)
                                          .scaffoldBackgroundColor))),
                      const SizedBox(height: 8),
                      Text(_clock,
                          style: Theme.of(context)
                              .textTheme
                              .displaySmall
                              ?.copyWith(fontFeatures: const [
                            FontFeature.tabularFigures()
                          ])),
                      Text('Maximum ${maxDuration.inMinutes} minutes',
                          style: Theme.of(context).textTheme.bodySmall),
                    ],
                  ),
                ),
                const Spacer(),
                ..._controls(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _controls() {
    switch (_state) {
      case _RecState.idle:
        return [
          KcButton(
              label: 'Start recording',
              icon: Icons.fiber_manual_record,
              onPressed: _start)
        ];
      case _RecState.recording:
        return [
          KcButton(
              label: 'Pause',
              icon: Icons.pause,
              variant: KcButtonVariant.tonal,
              onPressed: _pause),
          const SizedBox(height: 12),
          KcButton(label: 'Stop', icon: Icons.stop, onPressed: _stop),
        ];
      case _RecState.paused:
        return [
          KcButton(
              label: 'Resume',
              icon: Icons.play_arrow,
              variant: KcButtonVariant.tonal,
              onPressed: _resume),
          const SizedBox(height: 12),
          KcButton(label: 'Stop', icon: Icons.stop, onPressed: _stop),
        ];
      case _RecState.stopped:
        return [
          KcButton(
              label: 'Save recording',
              icon: Icons.cloud_upload_outlined,
              onPressed: _save),
          const SizedBox(height: 12),
          KcButton(
              label: 'Discard',
              icon: Icons.delete_outline,
              variant: KcButtonVariant.outlined,
              onPressed: _discard),
        ];
      case _RecState.uploading:
        return [const KcLoading()];
    }
  }
}
