import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/router/app_router.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_exception.dart';
import '../../../core/utils/validators.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../data/medical_repository.dart';
import 'medical_result_screen.dart';

/// Shows the speech-to-text transcript for review and correction BEFORE any
/// AI explanation is generated, so the app never claims to have analysed
/// audio it has not transcribed.
class TranscriptReviewScreen extends StatefulWidget {
  const TranscriptReviewScreen(
      {super.key, required this.transcript, required this.language});
  final String transcript;
  final String language;

  @override
  State<TranscriptReviewScreen> createState() => _TranscriptReviewScreenState();
}

class _TranscriptReviewScreenState extends State<TranscriptReviewScreen> {
  late final _text = TextEditingController(text: widget.transcript);
  final _form = GlobalKey<FormState>();
  bool _loading = false;
  String? _error;

  Future<void> _summarize() async {
    if (!_form.currentState!.validate()) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final r = await context
          .read<MedicalRepository>()
          .summarize(_text.text, language: widget.language);
      if (!mounted) return;
      context.push(Routes.medicalResult,
          extra: MedicalResultArgs(
              originalText: _text.text,
              explanation: r,
              language: widget.language,
              fromTranscript: true));
    } catch (e) {
      setState(() => _error = AppException.from(e).message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Review transcript')),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(KcSpacing.md),
          children: [
            const KcNotice(
              text:
                  'Automatic transcription can make mistakes, especially with medicine names. Please check and correct the text before continuing.',
              tone: KcNoticeTone.warning,
              icon: Icons.spellcheck,
            ),
            const SizedBox(height: KcSpacing.md),
            KcTextField(
              label: 'Transcript',
              controller: _text,
              maxLines: 16,
              minLines: 8,
              validator: (v) =>
                  Validators.required(v, field: 'Transcript') ??
                  Validators.maxLength(v, 20000),
            ),
            const SizedBox(height: KcSpacing.md),
            if (_error != null) ...[
              KcNotice(text: _error!, tone: KcNoticeTone.danger),
              const SizedBox(height: KcSpacing.md)
            ],
            KcButton(
                label: 'Summarise in simple words',
                icon: Icons.summarize_outlined,
                loading: _loading,
                onPressed: _summarize),
          ],
        ),
      ),
    );
  }
}
