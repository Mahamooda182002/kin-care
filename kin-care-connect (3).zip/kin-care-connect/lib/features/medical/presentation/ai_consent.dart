import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/services/session_controller.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../profile/data/profile_repository.dart';

/// Ensures the user has explicitly agreed to send text/audio to the AI
/// provider for medical explanations. Returns true when consent is in place.
Future<bool> ensureMedicalAiConsent(BuildContext context) async {
  final session = context.read<SessionController>();
  final user = session.user;
  if (user == null) return false;
  if (user.privacy.aiMedicalConsent) return true;
  final ok = await showConfirmDialog(
    context,
    title: 'Use AI to explain medical text?',
    message:
        'To explain or summarise, the text (or the transcript of a recording) is sent over an encrypted '
        'connection to our server and processed by an AI language/speech service. It is not used to '
        'diagnose you, and AI explanations can contain mistakes. You can turn this off any time in '
        'Settings › Privacy settings.\n\nDo you agree?',
    confirmLabel: 'I agree',
    cancelLabel: 'No, thanks',
    equalWeight: true,
  );
  if (!ok || !context.mounted) return false;
  // Only report consent when it was actually saved: the server re-checks it.
  final saved = await runGuarded<bool>(context, () async {
    await context
        .read<ProfileRepository>()
        .updatePrivacy(user.uid, user.privacy.copyWith(aiMedicalConsent: true));
    return true;
  });
  return saved ?? false;
}
