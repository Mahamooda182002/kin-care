import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/router/app_router.dart';
import '../../../core/services/session_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_exception.dart';
import '../../../core/utils/validators.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../data/medical_repository.dart';
import '../domain/medical_models.dart';
import 'ai_consent.dart';
import 'medical_result_screen.dart';
import 'widgets/recordings_list.dart';

/// Module G entry point: type or paste medical text, or record a conversation.
class MedicalTranslatorScreen extends StatefulWidget {
  const MedicalTranslatorScreen({super.key});

  @override
  State<MedicalTranslatorScreen> createState() =>
      _MedicalTranslatorScreenState();
}

class _MedicalTranslatorScreenState extends State<MedicalTranslatorScreen> {
  final _form = GlobalKey<FormState>();
  final _text = TextEditingController();
  String _language = 'en';
  bool _loading = false;
  String? _error;

  static const maxChars = 8000;

  Future<void> _run({required bool summarize}) async {
    setState(() => _error = null);
    if (!_form.currentState!.validate()) return;
    if (!await ensureMedicalAiConsent(context)) return;
    if (!mounted) return;
    setState(() => _loading = true);
    try {
      final repo = context.read<MedicalRepository>();
      final result = summarize
          ? await repo.summarize(_text.text, language: _language)
          : await repo.explain(_text.text, language: _language);
      if (!mounted) return;
      context.push(Routes.medicalResult,
          extra: MedicalResultArgs(
              originalText: _text.text,
              explanation: result,
              language: _language));
    } catch (e) {
      setState(() => _error = AppException.from(e).message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final uid = context.watch<SessionController>().uid;
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Medical Translator'),
          actions: [
            IconButton(
                tooltip: 'Saved summaries',
                icon: const Icon(Icons.folder_open_outlined),
                onPressed: () => context.push(Routes.medicalSummaries)),
          ],
          bottom: const TabBar(tabs: [
            Tab(icon: Icon(Icons.edit_note), text: 'Type or paste'),
            Tab(icon: Icon(Icons.mic_none), text: 'Record')
          ]),
        ),
        body: TabBarView(
          children: [
            Form(
              key: _form,
              child: ListView(
                padding: const EdgeInsets.all(KcSpacing.md),
                children: [
                  const KcNotice(
                      text: medicalDisclaimer,
                      icon: Icons.health_and_safety_outlined),
                  const SizedBox(height: KcSpacing.md),
                  KcTextField(
                    label:
                        'Medical words, doctor instructions or medicine information',
                    hint:
                        'e.g. "Hypertension. Take amlodipine 5 mg OD. Review in 2 weeks. HbA1c pending."',
                    controller: _text,
                    maxLines: 10,
                    minLines: 6,
                    maxLength: maxChars,
                    validator: (v) =>
                        Validators.required(v, field: 'Text') ??
                        Validators.maxLength(v, maxChars),
                  ),
                  const SizedBox(height: KcSpacing.sm),
                  DropdownButtonFormField<String>(
                    initialValue: _language,
                    decoration: const InputDecoration(
                        labelText: 'Explain in',
                        prefixIcon: Icon(Icons.language)),
                    items: supportedLanguages.entries
                        .map((e) => DropdownMenuItem(
                            value: e.key, child: Text(e.value)))
                        .toList(),
                    onChanged: (v) => setState(() => _language = v ?? 'en'),
                  ),
                  const SizedBox(height: KcSpacing.md),
                  if (_error != null) ...[
                    KcNotice(text: _error!, tone: KcNoticeTone.danger),
                    const SizedBox(height: KcSpacing.md)
                  ],
                  if (_loading)
                    const KcLoading(message: 'Explaining in simple words…')
                  else ...[
                    KcButton(
                        label: 'Explain in simple words',
                        icon: Icons.lightbulb_outline,
                        onPressed: () => _run(summarize: false)),
                    const SizedBox(height: KcSpacing.sm),
                    KcButton(
                        label: 'Summarise doctor instructions',
                        icon: Icons.summarize_outlined,
                        variant: KcButtonVariant.tonal,
                        onPressed: () => _run(summarize: true)),
                  ],
                ],
              ),
            ),
            ListView(
              padding: const EdgeInsets.all(KcSpacing.md),
              children: [
                const KcNotice(
                  text:
                      'Only record a conversation when everyone taking part has agreed. Recordings are stored privately and deleted automatically after 30 days, or sooner if you delete them.',
                  icon: Icons.record_voice_over_outlined,
                  tone: KcNoticeTone.warning,
                ),
                const SizedBox(height: KcSpacing.md),
                KcButton(
                    label: 'New recording',
                    icon: Icons.mic,
                    onPressed: () => context.push(Routes.medicalRecord)),
                const KcSectionHeader('Your recordings'),
                if (uid != null) RecordingsList(uid: uid, language: _language),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
