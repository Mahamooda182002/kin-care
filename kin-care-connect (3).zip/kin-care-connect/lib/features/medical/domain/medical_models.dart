import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../core/services/functions_service.dart';

class TermExplanation {
  const TermExplanation(
      {required this.term,
      required this.simpleExplanation,
      required this.whatItMeans});
  final String term;
  final String simpleExplanation;
  final String whatItMeans;
}

class KeyDate {
  const KeyDate({required this.date, required this.description});
  final String date;
  final String description;
}

/// Structured AI output. Fields under "fromYourText" are quoted or extracted
/// from what the user entered (facts); everything else is a generated plain-
/// language explanation and is labelled as such in the UI.
class MedicalExplanation {
  const MedicalExplanation({
    required this.summary,
    required this.terms,
    required this.abbreviations,
    required this.keyDates,
    required this.followUpActions,
    required this.questionsForDoctor,
    required this.instructionsFromText,
    required this.uncertainties,
    required this.safetyNotices,
    required this.language,
    required this.disclaimer,
  });

  final String summary;
  final List<TermExplanation> terms;
  final Map<String, String> abbreviations;
  final List<KeyDate> keyDates;
  final List<String> followUpActions;
  final List<String> questionsForDoctor;
  final List<String> instructionsFromText;
  final List<String> uncertainties;
  final List<String> safetyNotices;
  final String language;
  final String disclaimer;

  factory MedicalExplanation.fromMap(Map<String, dynamic> m) {
    final from = asMap(m['fromYourText']);
    return MedicalExplanation(
      summary: (m['summary'] ?? '').toString(),
      terms: asMapList(m['terms'])
          .map((t) => TermExplanation(
                term: (t['term'] ?? '').toString(),
                simpleExplanation: (t['simpleExplanation'] ?? '').toString(),
                whatItMeans: (t['whatItMeans'] ?? '').toString(),
              ))
          .toList(),
      abbreviations: {
        for (final a in asMapList(m['abbreviations']))
          (a['abbreviation'] ?? '').toString(): (a['meaning'] ?? '').toString(),
      },
      keyDates: asMapList(from['dates'])
          .map((d) => KeyDate(
              date: (d['date'] ?? '').toString(),
              description: (d['description'] ?? '').toString()))
          .toList(),
      instructionsFromText: asStringList(from['instructions']),
      followUpActions: asStringList(m['followUpActions']),
      questionsForDoctor: asStringList(m['questionsForDoctor']),
      uncertainties: asStringList(m['uncertainties']),
      safetyNotices: asStringList(m['safetyNotices']),
      language: (m['language'] ?? 'en').toString(),
      disclaimer: (m['disclaimer'] ?? medicalDisclaimer).toString(),
    );
  }

  /// Plain-text rendering used as the editable summary.
  String toEditableText() {
    final b = StringBuffer();
    if (summary.isNotEmpty) b.writeln('Summary:\n$summary\n');
    for (final t in terms) {
      b.writeln('Medical term: ${t.term}');
      b.writeln('Simple explanation: ${t.simpleExplanation}');
      if (t.whatItMeans.isNotEmpty) {
        b.writeln('What it means: ${t.whatItMeans}');
      }
      b.writeln();
    }
    if (abbreviations.isNotEmpty) {
      b.writeln('Abbreviations:');
      abbreviations.forEach((k, v) => b.writeln('• $k: $v'));
      b.writeln();
    }
    if (instructionsFromText.isNotEmpty) {
      b.writeln('Instructions (from your text):');
      for (final i in instructionsFromText) {
        b.writeln('• $i');
      }
      b.writeln();
    }
    if (keyDates.isNotEmpty) {
      b.writeln('Dates mentioned:');
      for (final d in keyDates) {
        b.writeln('• ${d.date}: ${d.description}');
      }
      b.writeln();
    }
    if (followUpActions.isNotEmpty) {
      b.writeln('Follow-up actions:');
      for (final a in followUpActions) {
        b.writeln('• $a');
      }
      b.writeln();
    }
    if (questionsForDoctor.isNotEmpty) {
      b.writeln('Questions to ask your doctor:');
      for (final q in questionsForDoctor) {
        b.writeln('• $q');
      }
    }
    return b.toString().trim();
  }
}

const medicalDisclaimer =
    'This explanation is for understanding only. It is not a diagnosis or '
    'medical advice. Do not start, stop or change any medicine or dose without '
    'talking to your doctor or pharmacist.';

class MedicalSummary {
  const MedicalSummary({
    required this.id,
    required this.userId,
    required this.title,
    required this.originalText,
    required this.summaryText,
    required this.language,
    required this.createdAt,
    this.updatedAt,
    this.profileId,
    this.familyId,
    this.sharedWithFamily = false,
    this.retentionStatus = 'keep',
  });

  final String id;
  final String userId;
  final String title;
  final String originalText;
  final String summaryText;
  final String language;
  final DateTime createdAt;
  final DateTime? updatedAt;
  final String? profileId;
  final String? familyId;
  final bool sharedWithFamily;
  final String retentionStatus;

  factory MedicalSummary.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? const {};
    return MedicalSummary(
      id: d.id,
      userId: (m['userId'] as String?) ?? '',
      title: (m['title'] as String?) ?? 'Medical summary',
      originalText: (m['originalText'] as String?) ?? '',
      summaryText: (m['summaryText'] as String?) ?? '',
      language: (m['language'] as String?) ?? 'en',
      createdAt: (m['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (m['updatedAt'] as Timestamp?)?.toDate(),
      profileId: m['profileId'] as String?,
      familyId: m['familyId'] as String?,
      sharedWithFamily: m['sharedWithFamily'] == true,
      retentionStatus: (m['retentionStatus'] as String?) ?? 'keep',
    );
  }
}

class RecordingItem {
  const RecordingItem(
      {required this.id,
      required this.storageReference,
      required this.createdAt,
      required this.durationSeconds,
      this.transcript,
      this.status = 'uploaded'});
  final String id;
  final String storageReference;
  final DateTime createdAt;
  final int durationSeconds;
  final String? transcript;
  final String status;

  factory RecordingItem.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? const {};
    return RecordingItem(
      id: d.id,
      storageReference: (m['storageReference'] as String?) ?? '',
      createdAt: (m['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      durationSeconds: (m['durationSeconds'] as num?)?.toInt() ?? 0,
      transcript: m['transcript'] as String?,
      status: (m['transcriptionStatus'] as String?) ?? 'uploaded',
    );
  }
}

/// Languages offered for translation of explanations.
const supportedLanguages = <String, String>{
  'en': 'English',
  'hi': 'Hindi',
  'ur': 'Urdu',
  'bn': 'Bengali',
  'ta': 'Tamil',
  'te': 'Telugu',
  'mr': 'Marathi',
  'kn': 'Kannada',
  'ml': 'Malayalam',
  'gu': 'Gujarati',
  'ar': 'Arabic',
  'es': 'Spanish',
  'fr': 'French',
};
