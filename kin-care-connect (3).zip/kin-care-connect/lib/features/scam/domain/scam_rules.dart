/// On-device scam warning-sign engine. Pure Dart, no network: the message
/// never leaves the phone when only this engine is used. The Cloud Function
/// runs an identical rule set (functions/src/scam/rules.ts) and can optionally
/// add an AI opinion when the user has given explicit consent.
///
/// The result is ADVISORY. It can produce false positives and false negatives
/// and never guarantees that a message is safe.
enum RiskLevel { low, medium, high }

extension RiskLevelX on RiskLevel {
  String get label => switch (this) {
        RiskLevel.low => 'Low',
        RiskLevel.medium => 'Medium',
        RiskLevel.high => 'High',
      };
  static RiskLevel parse(String? v) => RiskLevel.values
      .firstWhere((r) => r.name == v, orElse: () => RiskLevel.low);
}

class ScamIndicator {
  const ScamIndicator(
      {required this.id,
      required this.title,
      required this.explanation,
      required this.weight,
      this.matches = const []});
  final String id;
  final String title;
  final String explanation;
  final int weight;
  final List<String> matches;

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'explanation': explanation,
        'weight': weight,
        'matches': matches
      };
}

class ScamAnalysis {
  const ScamAnalysis({
    required this.riskLevel,
    required this.score,
    required this.indicators,
    required this.suspiciousPhrases,
    required this.urls,
    required this.explanation,
    required this.recommendedAction,
    required this.verificationAdvice,
    this.aiUsed = false,
    this.aiNote,
  });

  final RiskLevel riskLevel;
  final int score;
  final List<ScamIndicator> indicators;
  final List<String> suspiciousPhrases;
  final List<String> urls;
  final String explanation;
  final String recommendedAction;
  final List<String> verificationAdvice;
  final bool aiUsed;
  final String? aiNote;

  static const disclaimer =
      'This check is advisory only. It can miss scams or flag genuine messages, '
      'and it cannot guarantee a message is safe. When in doubt, contact the '
      'organisation using a number you already trust.';
}

class _Rule {
  const _Rule(
      this.id, this.title, this.explanation, this.weight, this.patterns);
  final String id;
  final String title;
  final String explanation;
  final int weight;
  final List<RegExp> patterns;
}

RegExp _r(String p) => RegExp(p, caseSensitive: false);

class ScamRules {
  ScamRules._();

  static final List<_Rule> _rules = [
    _Rule(
        'credentials',
        'Asks for OTP, PIN or password',
        'Banks, government offices and real companies never ask you to share a one-time code, PIN or password.',
        40, [
      _r(r'\b(otp|one[\s-]?time\s?(pass(word|code)?|code)|verification code|security code)\b'),
      _r(r'\b(pin|cvv|cvc|upi pin|atm pin)\b'),
      _r(r'\b(password|passcode|login details|net ?banking)\b'),
      _r(r'\bshare (the|your) code\b'),
    ]),
    _Rule(
        'urgency',
        'Creates urgency or pressure',
        'Scammers rush you so you act before thinking or checking with someone.',
        15, [
      _r(r'\b(urgent(ly)?|immediately|right away|asap|act now|final (notice|warning)|last chance)\b'),
      _r(r'\bwithin \d+\s?(minutes?|mins?|hours?|hrs?)\b'),
      _r(r'\b(today only|expires? (today|soon|in))\b'),
    ]),
    _Rule(
        'threat',
        'Threatens penalties, arrest or account closure',
        'Threats of arrest, fines, legal action or blocked accounts are a common pressure tactic.',
        20, [
      _r(r'\b(arrest(ed)?|police|warrant|legal action|court|lawsuit|jail)\b'),
      _r(r'\b(account|card|sim|number|kyc)\b.{0,30}\b(block(ed)?|suspend(ed)?|deactivat(ed|e)|clos(ed|e)|frozen)\b'),
      _r(r'\b(penalty|fine) of\b'),
    ]),
    _Rule(
        'payment',
        'Requests money or unusual payment',
        'Requests to pay by gift card, crypto, wire transfer or a payment link are strong warning signs.',
        25, [
      _r(r'\b(gift ?cards?|google play cards?|itunes cards?|steam cards?|amazon pay voucher)\b'),
      _r(r'\b(send|share|scratch)\b.{0,15}\bcodes?\b'),
      _r(r'\b(bitcoin|crypto(currency)?|usdt|wallet address)\b'),
      _r(r'\b(wire|bank) transfer\b|\bwestern union\b|\bmoneygram\b'),
      _r(r'\b(pay|send|transfer)\b.{0,25}(\$|₹|rs\.?|inr|usd|£|€)\s?\d'),
      _r(r'\b(processing|registration|release|customs|delivery) fee\b'),
      _r(r'\b(scan (the|this) qr|collect request|approve the request)\b'),
    ]),
    _Rule(
        'prize',
        'Too-good-to-be-true offer',
        'Unexpected prizes, lotteries, refunds or job offers are often used to lure people in.',
        15, [
      _r(r'\b(you (have )?won|winner|lottery|jackpot|lucky draw|prize|reward points)\b'),
      _r(r'\b(cash ?back|refund) (of|is) (pending|approved)\b'),
      _r(r'\b(work from home|earn \d+|part[\s-]?time job)\b'),
    ]),
    _Rule(
        'impersonation',
        'Claims to be a bank, government or family member',
        'Scammers pretend to be trusted organisations or relatives (for example "Hi Mum, new number").',
        15, [
      _r(r'\b(bank|income tax|irs|hmrc|customs|courier|fedex|dhl|amazon|microsoft|apple support|tech support)\b'),
      _r(r"\b(hi|hello) (mum|mom|dad|grandma|grandpa)\b|\bnew number\b|\bi lost my phone\b"),
    ]),
    _Rule(
        'secrecy',
        'Asks you to keep it secret',
        "Being told not to tell family or the bank is a classic sign of a scam.",
        20, [
      _r(r"\b(don'?t|do not) (tell|inform|share with) (anyone|your family|the bank|dad|mum|mom|your (son|daughter|husband|wife))\b"),
      _r(r'\bkeep (this|it) (confidential|secret|between us)\b'),
    ]),
    _Rule(
        'remote_access',
        'Asks you to install an app or give remote access',
        'Screen-sharing or remote-control apps let scammers see and control your phone.',
        30, [
      _r(r'\b(anydesk|teamviewer|quick ?support|rustdesk|screen ?shar(e|ing)|remote access)\b'),
      _r(r'\b(download|install) (this|the) (app|apk)\b|\.apk\b'),
    ]),
  ];

  static final RegExp _url = RegExp(
    r'''((https?:\/\/)?(www\.)?[a-z0-9\-]+(\.[a-z0-9\-]+)*\.(com|net|org|in|co|info|xyz|top|link|click|ly|io|me|app|site|online|shop|ru|cn|tk|ml|ga|cf|gq|live|biz)(\/[^\s<>"']*)?)''',
    caseSensitive: false,
  );

  static final List<RegExp> _riskyUrl = [
    _r(r'\b(bit\.ly|tinyurl|t\.co|goo\.gl|cutt\.ly|is\.gd|rb\.gy|shorturl)\b'),
    _r(r'\.(xyz|top|click|tk|ml|ga|cf|gq|zip|mov)\b'),
    RegExp(r'https?:\/\/\d{1,3}(\.\d{1,3}){3}'),
    _r(r'(paypa1|amaz0n|g00gle|faceb00k|micr0soft|app1e|sbi-|hdfc-|icici-|kyc-?update|secure-?login|verify-?account)'),
    _r(r'xn--'),
  ];

  /// Extracts URLs WITHOUT opening them.
  static List<String> extractUrls(String text) =>
      _url.allMatches(text).map((m) => m.group(0)!).toSet().toList();

  static ScamAnalysis analyze(String input) {
    final text = input.trim();
    final indicators = <ScamIndicator>[];
    final phrases = <String>{};
    var score = 0;

    for (final rule in _rules) {
      final matches = <String>{};
      for (final p in rule.patterns) {
        for (final m in p.allMatches(text)) {
          matches.add(m.group(0)!.trim());
        }
      }
      if (matches.isNotEmpty) {
        indicators.add(ScamIndicator(
          id: rule.id,
          title: rule.title,
          explanation: rule.explanation,
          weight: rule.weight,
          matches: matches.take(5).toList(),
        ));
        phrases.addAll(matches.take(5));
        score += rule.weight;
      }
    }

    final urls = extractUrls(text);
    if (urls.isNotEmpty) {
      final risky =
          urls.where((u) => _riskyUrl.any((r) => r.hasMatch(u))).toList();
      if (risky.isNotEmpty) {
        indicators.add(ScamIndicator(
          id: 'risky_link',
          title: 'Contains a suspicious-looking link',
          explanation:
              'Shortened links, unusual endings or look-alike names can hide fake websites. The link was not opened.',
          weight: 25,
          matches: risky.take(5).toList(),
        ));
        phrases.addAll(risky.take(5));
        score += 25;
      } else {
        indicators.add(ScamIndicator(
          id: 'link',
          title: 'Contains a link',
          explanation:
              'Links in unexpected messages can lead to fake websites. Type the official address yourself instead of tapping it. The link was not opened.',
          weight: 10,
          matches: urls.take(5).toList(),
        ));
        score += 10;
      }
    }

    // Combination boosts: credentials or payment together with urgency/threat.
    final ids = indicators.map((i) => i.id).toSet();
    if ((ids.contains('credentials') || ids.contains('payment')) &&
        (ids.contains('urgency') || ids.contains('threat'))) {
      score += 15;
    }

    final level = score >= 50
        ? RiskLevel.high
        : score >= 20
            ? RiskLevel.medium
            : RiskLevel.low;

    return ScamAnalysis(
      riskLevel: level,
      score: score > 100 ? 100 : score,
      indicators: indicators,
      suspiciousPhrases: phrases.toList(),
      urls: urls,
      explanation: _explain(level, indicators),
      recommendedAction: _action(level, ids),
      verificationAdvice: _advice(ids),
    );
  }

  static String _explain(RiskLevel level, List<ScamIndicator> ind) {
    if (ind.isEmpty) {
      return 'We did not find common warning signs. That does not mean the message is safe. Scams can look normal.';
    }
    final names = ind.map((i) => i.title.toLowerCase()).take(3).join('; ');
    switch (level) {
      case RiskLevel.high:
        return 'This message shows several strong warning signs of a scam: $names.';
      case RiskLevel.medium:
        return 'This message shows some warning signs: $names. Be careful.';
      case RiskLevel.low:
        return 'We found a minor warning sign: $names. Stay cautious.';
    }
  }

  static String _action(RiskLevel level, Set<String> ids) {
    if (level == RiskLevel.high) {
      return 'Do not reply, do not tap any links, and do not share codes or send money. Talk to a family member or call the organisation using a number you already trust.';
    }
    if (level == RiskLevel.medium) {
      return 'Pause before acting. Verify the sender through an official channel before replying, paying or tapping links.';
    }
    return 'No strong warning signs found, but stay alert. If anything feels off, check with someone you trust.';
  }

  static List<String> _advice(Set<String> ids) {
    final a = <String>[
      'Contact the organisation using the phone number on your card, bill or their official website. Not the number in the message.',
    ];
    if (ids.contains('credentials')) {
      a.add(
          'Never share OTPs, PINs or passwords with anyone, even if they say they are from your bank.');
    }
    if (ids.contains('payment')) {
      a.add(
          'Real organisations do not ask for payment by gift card, crypto or an unexpected payment link.');
    }
    if (ids.contains('impersonation')) {
      a.add(
          'If it claims to be a relative, call them on their old, known number to check.');
    }
    if (ids.contains('remote_access')) {
      a.add(
          'Do not install apps or share your screen at the request of someone who contacted you.');
    }
    if (ids.contains('link') || ids.contains('risky_link')) {
      a.add('Do not tap the link. Type the official website address yourself.');
    }
    a.add(
        'If you already shared details or money, contact your bank immediately and report it to your local cybercrime helpline.');
    return a;
  }
}
