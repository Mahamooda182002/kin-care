import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../core/services/functions_service.dart';
import '../../../core/utils/app_exception.dart';
import '../domain/scam_rules.dart';

class ScamCheckRecord {
  const ScamCheckRecord(
      {required this.id,
      required this.inputType,
      required this.riskLevel,
      required this.indicatorTitles,
      required this.createdAt,
      required this.aiUsed});
  final String id;
  final String inputType;
  final RiskLevel riskLevel;
  final List<String> indicatorTitles;
  final DateTime createdAt;
  final bool aiUsed;

  factory ScamCheckRecord.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? const {};
    return ScamCheckRecord(
      id: d.id,
      inputType: (m['inputType'] as String?) ?? 'sms',
      riskLevel: RiskLevelX.parse(m['riskLevel'] as String?),
      indicatorTitles: ((m['indicators'] as List?) ?? const [])
          .map((e) => e is Map ? (e['title']?.toString() ?? '') : e.toString())
          .where((s) => s.isNotEmpty)
          .toList(),
      createdAt: (m['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      aiUsed: m['aiUsed'] == true,
    );
  }
}

class ScamRepository {
  ScamRepository(this._db, this._functions);
  final FirebaseFirestore _db;
  final FunctionsService _functions;

  Stream<List<ScamCheckRecord>> watchHistory(String uid, {int limit = 30}) =>
      _db
          .collection('scamChecks')
          .where('userId', isEqualTo: uid)
          .orderBy('createdAt', descending: true)
          .limit(limit)
          .snapshots()
          .map((s) => s.docs.map(ScamCheckRecord.fromDoc).toList());

  /// On-device only: nothing is sent anywhere. Saves only the verdict
  /// (never the message text) to history when [saveToHistory] is true.
  Future<ScamAnalysis> analyzeOnDevice(
      String uid, String text, String inputType,
      {bool saveToHistory = true}) async {
    final result = ScamRules.analyze(text);
    if (saveToHistory) {
      try {
        await _db.collection('scamChecks').add({
          'userId': uid,
          'inputType': inputType,
          'riskLevel': result.riskLevel.name,
          'indicators': result.indicators
              .map((i) => {'id': i.id, 'title': i.title})
              .toList(),
          'recommendations': [result.recommendedAction],
          'aiUsed': false,
          'createdAt': FieldValue.serverTimestamp(),
        });
      } catch (e) {
        // History is optional; the analysis result is still shown.
      }
    }
    return result;
  }

  /// Server analysis (POST /api/scam/analyze). When [useAi] is true the text
  /// is sent to the configured AI provider. Only call after the user has
  /// given explicit consent in Privacy settings and on this screen.
  Future<ScamAnalysis> analyzeWithServer(String text, String inputType,
      {required bool useAi}) async {
    final r = await _functions.call('scamAnalyze', {
      'text': text,
      'inputType': inputType,
      'useAi': useAi,
    });
    try {
      return ScamAnalysis(
        riskLevel: RiskLevelX.parse(r['riskLevel'] as String?),
        score: (r['score'] as num?)?.toInt() ?? 0,
        indicators: asMapList(r['indicators'])
            .map((m) => ScamIndicator(
                  id: (m['id'] ?? '').toString(),
                  title: (m['title'] ?? '').toString(),
                  explanation: (m['explanation'] ?? '').toString(),
                  weight: (m['weight'] as num?)?.toInt() ?? 0,
                  matches: asStringList(m['matches']),
                ))
            .toList(),
        suspiciousPhrases: asStringList(r['suspiciousPhrases']),
        urls: asStringList(r['urls']),
        explanation: (r['explanation'] ?? '').toString(),
        recommendedAction: (r['recommendedAction'] ?? '').toString(),
        verificationAdvice: asStringList(r['verificationAdvice']),
        aiUsed: r['aiUsed'] == true,
        aiNote: r['aiNote'] as String?,
      );
    } catch (_) {
      throw const AppException(
          'The analysis result could not be read. Please try again.');
    }
  }

  Future<void> deleteCheck(String id) async {
    try {
      await _db.collection('scamChecks').doc(id).delete();
    } catch (e) {
      throw AppException.from(e);
    }
  }
}
