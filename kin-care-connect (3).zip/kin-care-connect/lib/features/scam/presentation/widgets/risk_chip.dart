import 'package:flutter/material.dart';

import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/kc_widgets.dart';
import '../../domain/scam_rules.dart';

/// Risk colour with enough contrast for the current theme brightness.
Color riskColor(RiskLevel l, [Brightness brightness = Brightness.light]) {
  final dark = brightness == Brightness.dark;
  return switch (l) {
    RiskLevel.low => dark ? KcColors.riskLowOnDark : KcColors.riskLow,
    RiskLevel.medium => dark ? KcColors.riskMediumOnDark : KcColors.riskMedium,
    RiskLevel.high => dark ? KcColors.riskHighOnDark : KcColors.riskHigh,
  };
}

class RiskChip extends StatelessWidget {
  const RiskChip({super.key, required this.level});
  final RiskLevel level;

  @override
  Widget build(BuildContext context) => Semantics(
      label: '${level.label} risk',
      child: ExcludeSemantics(
          child: KcChip(level.label,
              color: riskColor(level, Theme.of(context).brightness))));
}
