import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/theme/contrast.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../domain/scam_rules.dart';
import 'widgets/risk_chip.dart';

/// Results: risk category, suspicious phrases, explanation, next action and
/// verification advice. Links are shown as plain text and never opened.
class ScamResultScreen extends StatelessWidget {
  const ScamResultScreen({super.key, required this.analysis});
  final ScamAnalysis analysis;

  @override
  Widget build(BuildContext context) {
    final a = analysis;
    final color = riskColor(a.riskLevel, Theme.of(context).brightness);
    return Scaffold(
      appBar: AppBar(title: const Text('Check result')),
      body: ListView(
        padding: const EdgeInsets.all(KcSpacing.md),
        children: [
          Semantics(
            label: 'Risk level ${a.riskLevel.label}',
            child: KcCard(
              color: color.withValues(alpha: 0.10),
              child: Row(
                children: [
                  Icon(
                    switch (a.riskLevel) {
                      RiskLevel.high => Icons.gpp_bad_outlined,
                      RiskLevel.medium => Icons.gpp_maybe_outlined,
                      RiskLevel.low => Icons.gpp_good_outlined,
                    },
                    color: color,
                    size: 56,
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('${a.riskLevel.label} risk',
                            style: Theme.of(context)
                                .textTheme
                                .headlineSmall
                                ?.copyWith(
                                    color: ensureContrast(
                                        color,
                                        Color.alphaBlend(
                                            color.withValues(alpha: 0.10),
                                            Theme.of(context)
                                                .colorScheme
                                                .surface)),
                                    fontWeight: FontWeight.w800)),
                        Text(a.aiUsed
                            ? 'Warning-sign rules + AI review'
                            : 'Checked on this phone'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const KcSectionHeader('What we found'),
          KcCard(child: Text(a.explanation)),
          if (a.aiNote != null && a.aiNote!.isNotEmpty) ...[
            const KcSectionHeader('AI review'),
            KcCard(child: Text(a.aiNote!)),
          ],
          if (a.suspiciousPhrases.isNotEmpty) ...[
            const KcSectionHeader('Suspicious phrases'),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: a.suspiciousPhrases
                  .map((p) => KcChip('"$p"', color: color))
                  .toList(),
            ),
          ],
          if (a.indicators.isNotEmpty) ...[
            const KcSectionHeader('Risk indicators'),
            ...a.indicators.map((i) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: KcCard(
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(i.title,
                              style: Theme.of(context).textTheme.titleMedium),
                          const SizedBox(height: 4),
                          Text(i.explanation),
                        ]),
                  ),
                )),
          ],
          if (a.urls.isNotEmpty) ...[
            const KcSectionHeader('Links in the message (not opened)'),
            KcCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: a.urls
                    .map((u) => ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: const Icon(Icons.link_off),
                          title: Text(u,
                              style: const TextStyle(fontFamily: 'monospace')),
                          trailing: IconButton(
                            tooltip: 'Copy link text',
                            icon: const Icon(Icons.copy),
                            onPressed: () {
                              Clipboard.setData(ClipboardData(text: u));
                              showSnack(context,
                                  'Link copied as text. Do not open it unless you are sure.');
                            },
                          ),
                        ))
                    .toList(),
              ),
            ),
          ],
          const KcSectionHeader('Recommended next step'),
          KcNotice(
              text: a.recommendedAction,
              tone: a.riskLevel == RiskLevel.high
                  ? KcNoticeTone.danger
                  : KcNoticeTone.warning,
              icon: Icons.directions_outlined),
          const KcSectionHeader('How to verify'),
          KcCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: a.verificationAdvice
                  .map((v) => Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Icon(Icons.verified_user_outlined,
                                  size: 20),
                              const SizedBox(width: 10),
                              Expanded(child: Text(v)),
                            ]),
                      ))
                  .toList(),
            ),
          ),
          const SizedBox(height: KcSpacing.md),
          const KcNotice(text: ScamAnalysis.disclaimer),
          const SizedBox(height: KcSpacing.xl),
        ],
      ),
    );
  }
}
