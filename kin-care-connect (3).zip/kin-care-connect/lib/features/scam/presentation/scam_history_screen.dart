import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/services/session_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_exception.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../data/scam_repository.dart';
import 'widgets/risk_chip.dart';

/// Past checks. Only the verdict is stored, never the message text.
class ScamHistoryScreen extends StatelessWidget {
  const ScamHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = context.watch<SessionController>().uid;
    if (uid == null) return const Scaffold(body: KcLoading());
    final repo = context.read<ScamRepository>();
    return Scaffold(
      appBar: AppBar(title: const Text('Past scam checks')),
      body: StreamBuilder<List<ScamCheckRecord>>(
        stream: repo.watchHistory(uid, limit: 100),
        builder: (context, snap) {
          if (snap.hasError) {
            return KcErrorView(message: AppException.from(snap.error!).message);
          }
          if (!snap.hasData) return const KcLoading();
          if (snap.data!.isEmpty) {
            return const KcEmptyView(
                icon: Icons.shield_outlined, title: 'No checks yet');
          }
          return ListView(
            padding: const EdgeInsets.all(KcSpacing.md),
            children: [
              const Text(
                  'For your privacy, the message text is not saved. Only the result is kept.'),
              const SizedBox(height: 12),
              ...snap.data!.map((c) => Dismissible(
                    key: ValueKey(c.id),
                    direction: DismissDirection.endToStart,
                    confirmDismiss: (_) => showConfirmDialog(context,
                        title: 'Delete this check?',
                        message: 'It will be removed from your history.',
                        confirmLabel: 'Delete',
                        destructive: true),
                    onDismissed: (_) =>
                        runGuarded(context, () => repo.deleteCheck(c.id)),
                    background: Container(
                      alignment: Alignment.centerRight,
                      padding: const EdgeInsets.only(right: 24),
                      color: Theme.of(context).colorScheme.errorContainer,
                      child: const Icon(Icons.delete_outline),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: KcCard(
                        padding: EdgeInsets.zero,
                        child: ListTile(
                          title: Text(
                              c.indicatorTitles.isEmpty
                                  ? 'No warning signs found'
                                  : c.indicatorTitles.join(', '),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis),
                          subtitle: Text(
                              '${c.inputType.toUpperCase()} • ${Fmt.dateTime(c.createdAt)}${c.aiUsed ? ' • AI' : ''}'),
                          trailing: RiskChip(level: c.riskLevel),
                        ),
                      ),
                    ),
                  )),
            ],
          );
        },
      ),
    );
  }
}
