import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/router/app_router.dart';
import '../../../core/services/session_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_exception.dart';
import '../../../core/utils/validators.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../../profile/data/profile_repository.dart';
import '../data/scam_repository.dart';
import '../domain/scam_rules.dart';

/// Module H: paste SMS / WhatsApp / email text, a URL or a payment request.
class ScamShieldScreen extends StatefulWidget {
  const ScamShieldScreen({super.key});

  @override
  State<ScamShieldScreen> createState() => _ScamShieldScreenState();
}

class _ScamShieldScreenState extends State<ScamShieldScreen> {
  final _form = GlobalKey<FormState>();
  final _text = TextEditingController();
  String _type = 'sms';
  bool _useAi = false;
  bool _loading = false;
  String? _error;

  static const types = {
    'sms': ('SMS', Icons.sms_outlined),
    'whatsapp': ('WhatsApp', Icons.chat_outlined),
    'email': ('Email', Icons.email_outlined),
    'url': ('Link / URL', Icons.link),
    'payment': ('Payment request', Icons.payments_outlined),
  };

  Future<void> _analyze() async {
    setState(() => _error = null);
    if (!_form.currentState!.validate()) return;
    final session = context.read<SessionController>();
    final uid = session.uid!;
    final repo = context.read<ScamRepository>();

    if (_useAi && !(session.user?.privacy.aiScamConsent ?? false)) {
      final ok = await showConfirmDialog(
        context,
        title: 'Send this message to an AI service?',
        message:
            'For a deeper check, the text you pasted is sent over an encrypted connection to our server and an AI language service. '
            'Remove personal details you do not want shared. The message text is not saved. '
            'You can change this in Settings › Privacy.',
        confirmLabel: 'I agree',
        cancelLabel: 'Use on-device check',
        equalWeight: true,
      );
      if (!mounted) return;
      if (!ok) {
        setState(() => _useAi = false);
      } else {
        final p = session.user!.privacy;
        final saved = await runGuarded<bool>(context, () async {
          await context
              .read<ProfileRepository>()
              .updatePrivacy(uid, p.copyWith(aiScamConsent: true));
          return true;
        });
        if (saved != true) return;
      }
    }
    if (!mounted) return;

    setState(() => _loading = true);
    try {
      final ScamAnalysis result = _useAi
          ? await repo.analyzeWithServer(_text.text, _type, useAi: true)
          : await repo.analyzeOnDevice(uid, _text.text, _type);
      if (!mounted) return;
      context.push(Routes.scamResult, extra: result);
    } catch (e) {
      setState(() => _error =
          '${AppException.from(e).message} You can still use the on-device check.');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Scam Shield'),
        actions: [
          IconButton(
              tooltip: 'Past checks',
              icon: const Icon(Icons.history),
              onPressed: () => context.push(Routes.scamHistory))
        ],
      ),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(KcSpacing.md),
          children: [
            const Text(
                'Paste a message you are unsure about. We will look for common warning signs.'),
            const SizedBox(height: KcSpacing.md),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: types.entries
                  .map((e) => ChoiceChip(
                        avatar: Icon(e.value.$2, size: 20),
                        label: Text(e.value.$1),
                        selected: _type == e.key,
                        onSelected: (_) => setState(() => _type = e.key),
                      ))
                  .toList(),
            ),
            const SizedBox(height: KcSpacing.md),
            KcTextField(
              label: _type == 'url'
                  ? 'Paste the link (it will NOT be opened)'
                  : 'Paste the message',
              controller: _text,
              maxLines: 10,
              minLines: 5,
              maxLength: 5000,
              validator: (v) =>
                  Validators.required(v, field: 'Message') ??
                  Validators.maxLength(v, 5000),
            ),
            KcCard(
              padding: EdgeInsets.zero,
              child: SwitchListTile(
                title: const Text('Deeper check with AI'),
                subtitle: const Text(
                    'Off: checked only on this phone. On: text is sent to an AI service with your consent.'),
                value: _useAi,
                onChanged: (v) => setState(() => _useAi = v),
              ),
            ),
            const SizedBox(height: KcSpacing.md),
            const KcNotice(
                text: ScamAnalysis.disclaimer, icon: Icons.info_outline),
            const SizedBox(height: KcSpacing.md),
            if (_error != null) ...[
              KcNotice(text: _error!, tone: KcNoticeTone.danger),
              const SizedBox(height: KcSpacing.md)
            ],
            KcButton(
                label: 'Check message',
                icon: Icons.shield_outlined,
                loading: _loading,
                onPressed: _analyze),
          ],
        ),
      ),
    );
  }
}
