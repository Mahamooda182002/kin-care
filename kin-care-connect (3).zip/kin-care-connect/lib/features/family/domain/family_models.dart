import 'package:cloud_firestore/cloud_firestore.dart';

/// Permission levels from the brief (Module I).
enum FamilyRole { admin, caregiver, viewer, elderly }

extension FamilyRoleX on FamilyRole {
  String get label => switch (this) {
        FamilyRole.admin => 'Family administrator',
        FamilyRole.caregiver => 'Caregiver',
        FamilyRole.viewer => 'Read-only family member',
        FamilyRole.elderly => 'Elderly account holder',
      };
  String get value => name;
  static FamilyRole parse(String? v) => FamilyRole.values
      .firstWhere((r) => r.name == v, orElse: () => FamilyRole.viewer);

  bool get canManageFamily => this == FamilyRole.admin;
  bool get canEditCare =>
      this == FamilyRole.admin || this == FamilyRole.caregiver;
}

enum InvitationStatus { pending, accepted, rejected, revoked }

InvitationStatus parseInvitationStatus(String? v) => InvitationStatus.values
    .firstWhere((s) => s.name == v, orElse: () => InvitationStatus.pending);

DateTime? _ts(Object? v) => v is Timestamp ? v.toDate() : null;

class Family {
  const Family(
      {required this.id,
      required this.name,
      required this.createdBy,
      this.createdAt});
  final String id;
  final String name;
  final String createdBy;
  final DateTime? createdAt;

  factory Family.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? const {};
    return Family(
      id: d.id,
      name: (m['familyName'] as String?) ?? 'Family',
      createdBy: (m['createdBy'] as String?) ?? '',
      createdAt: _ts(m['createdAt']),
    );
  }
}

class FamilyMember {
  const FamilyMember({
    required this.membershipId,
    required this.familyId,
    required this.userId,
    required this.role,
    required this.status,
    this.displayName,
    this.email,
    this.createdAt,
  });

  final String membershipId;
  final String familyId;
  final String userId;
  final FamilyRole role;
  final InvitationStatus status;
  final String? displayName;
  final String? email;
  final DateTime? createdAt;

  /// Membership ids are deterministic so security rules can look them up.
  static String idFor(String familyId, String uid) => '${familyId}_$uid';

  factory FamilyMember.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? const {};
    return FamilyMember(
      membershipId: d.id,
      familyId: (m['familyId'] as String?) ?? '',
      userId: (m['userId'] as String?) ?? '',
      role: FamilyRoleX.parse(m['role'] as String?),
      status: parseInvitationStatus(m['invitationStatus'] as String?),
      displayName: m['displayName'] as String?,
      email: m['email'] as String?,
      createdAt: _ts(m['createdAt']),
    );
  }
}

/// What the elderly person (or the admin, when no elderly account is linked)
/// has explicitly agreed to share with the family group.
class SharingConsent {
  const SharingConsent(
      {this.activity = false, this.medical = false, this.reminders = false});
  final bool activity;
  final bool medical;
  final bool reminders;

  factory SharingConsent.fromMap(Map<String, dynamic>? m) => SharingConsent(
        activity: m?['activity'] == true,
        medical: m?['medical'] == true,
        reminders: m?['reminders'] == true,
      );
  Map<String, dynamic> toMap() =>
      {'activity': activity, 'medical': medical, 'reminders': reminders};
  SharingConsent copyWith({bool? activity, bool? medical, bool? reminders}) =>
      SharingConsent(
        activity: activity ?? this.activity,
        medical: medical ?? this.medical,
        reminders: reminders ?? this.reminders,
      );
}

class CareProfile {
  const CareProfile({
    required this.id,
    required this.familyId,
    required this.displayName,
    required this.createdBy,
    this.linkedUserId,
    this.caregiverIds = const [],
    this.sharingConsent = const SharingConsent(),
    this.notes,
    this.createdAt,
  });

  final String id;
  final String familyId;
  final String displayName;
  final String createdBy;
  final String? linkedUserId;
  final List<String> caregiverIds;
  final SharingConsent sharingConsent;
  final String? notes;
  final DateTime? createdAt;

  /// Who may change consent: the linked elderly account if there is one,
  /// otherwise a family administrator (enforced in firestore.rules).
  bool consentControlledBy(String uid, FamilyRole? role) =>
      linkedUserId != null ? linkedUserId == uid : role == FamilyRole.admin;

  factory CareProfile.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? const {};
    return CareProfile(
      id: d.id,
      familyId: (m['familyId'] as String?) ?? '',
      displayName: (m['displayName'] as String?) ?? 'Care profile',
      createdBy: (m['createdBy'] as String?) ?? '',
      linkedUserId: m['linkedUserId'] as String?,
      caregiverIds: ((m['caregiverIds'] as List?) ?? const [])
          .map((e) => e.toString())
          .toList(),
      sharingConsent: SharingConsent.fromMap(
          (m['sharingConsent'] as Map?)?.cast<String, dynamic>()),
      notes: m['notes'] as String?,
      createdAt: _ts(m['createdAt']),
    );
  }
}

class Invitation {
  const Invitation({
    required this.id,
    required this.familyId,
    required this.familyName,
    required this.inviteeEmail,
    required this.role,
    required this.invitedByName,
    required this.status,
    this.profileId,
    this.createdAt,
  });

  final String id;
  final String familyId;
  final String familyName;
  final String inviteeEmail;
  final FamilyRole role;
  final String invitedByName;
  final InvitationStatus status;
  final String? profileId;
  final DateTime? createdAt;

  factory Invitation.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? const {};
    return Invitation(
      id: d.id,
      familyId: (m['familyId'] as String?) ?? '',
      familyName: (m['familyName'] as String?) ?? 'A family',
      inviteeEmail: (m['inviteeEmail'] as String?) ?? '',
      role: FamilyRoleX.parse(m['role'] as String?),
      invitedByName: (m['invitedByName'] as String?) ?? 'A family member',
      status: parseInvitationStatus(m['status'] as String?),
      profileId: m['profileId'] as String?,
      createdAt: _ts(m['createdAt']),
    );
  }
}
