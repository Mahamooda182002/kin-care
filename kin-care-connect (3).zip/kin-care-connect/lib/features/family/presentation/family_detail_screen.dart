import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/router/app_router.dart';
import '../../../core/services/session_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_exception.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/utils/validators.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../data/family_repository.dart';
import '../domain/family_models.dart';
import 'family_screen.dart';

class FamilyDetailScreen extends StatelessWidget {
  const FamilyDetailScreen({super.key, required this.familyId});
  final String familyId;

  @override
  Widget build(BuildContext context) {
    final uid = context.watch<SessionController>().uid;
    if (uid == null) return const Scaffold(body: KcLoading());
    final repo = context.read<FamilyRepository>();

    return StreamBuilder<FamilyMember?>(
      stream: repo.watchMyMembership(familyId, uid),
      builder: (context, ms) {
        if (ms.hasError) {
          return Scaffold(
              appBar: AppBar(),
              body: KcErrorView(message: AppException.from(ms.error!).message));
        }
        if (!ms.hasData && ms.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: KcLoading());
        }
        final me = ms.data;
        if (me == null || me.status != InvitationStatus.accepted) {
          return Scaffold(
              appBar: AppBar(),
              body: const KcEmptyView(
                  icon: Icons.lock_outline,
                  title: 'You are not a member of this family'));
        }
        final isAdmin = me.role == FamilyRole.admin;
        return StreamBuilder<Family?>(
          stream: repo.watchFamily(familyId),
          builder: (context, fs) {
            final family = fs.data;
            return Scaffold(
              appBar: AppBar(
                title: Text(family?.name ?? 'Family'),
                actions: [
                  PopupMenuButton<String>(
                    tooltip: 'Family options',
                    onSelected: (v) => _menu(context, v, me, family),
                    itemBuilder: (_) => [
                      if (isAdmin)
                        const PopupMenuItem(
                            value: 'rename', child: Text('Rename family')),
                      const PopupMenuItem(
                          value: 'leave', child: Text('Leave family')),
                    ],
                  ),
                ],
              ),
              floatingActionButton: isAdmin
                  ? FloatingActionButton.extended(
                      onPressed: () => _invite(context),
                      icon: const Icon(Icons.person_add_alt_1_outlined),
                      label: const Text('Invite'),
                    )
                  : null,
              body: ListView(
                padding: const EdgeInsets.all(KcSpacing.md),
                children: [
                  KcNotice(
                      text:
                          'Your role: ${me.role.label}. ${_roleHelp(me.role)}'),
                  KcSectionHeader('Care profiles',
                      action: isAdmin
                          ? TextButton.icon(
                              onPressed: () => _addProfile(context, uid),
                              icon: const Icon(Icons.add),
                              label: const Text('Add'))
                          : null),
                  StreamBuilder<List<CareProfile>>(
                    stream: repo.watchProfiles(familyId),
                    builder: (context, ps) {
                      if (ps.hasError) {
                        return Text(AppException.from(ps.error!).message);
                      }
                      if (!ps.hasData) return const LinearProgressIndicator();
                      if (ps.data!.isEmpty) {
                        return Text(isAdmin
                            ? 'Add a profile for the elderly family member you care for.'
                            : 'No care profiles yet.');
                      }
                      return Column(
                        children: ps.data!
                            .map((p) => Padding(
                                  padding: const EdgeInsets.only(bottom: 8),
                                  child: KcCard(
                                    padding: EdgeInsets.zero,
                                    onTap: () => context.push(
                                        Routes.careProfile(familyId, p.id)),
                                    child: ListTile(
                                      leading: const CircleAvatar(
                                          backgroundColor: KcColors.tealLight,
                                          child: Icon(Icons.elderly,
                                              color: KcColors.teal)),
                                      title: Text(p.displayName),
                                      subtitle: Text(p.linkedUserId != null
                                          ? 'Linked to their own account'
                                          : 'Managed by family'),
                                      trailing: const Icon(Icons.chevron_right),
                                    ),
                                  ),
                                ))
                            .toList(),
                      );
                    },
                  ),
                  const KcSectionHeader('Members'),
                  StreamBuilder<List<FamilyMember>>(
                    stream: repo.watchMembers(familyId),
                    builder: (context, snap) {
                      if (!snap.hasData) return const LinearProgressIndicator();
                      final members = snap.data!
                          .where((m) => m.status == InvitationStatus.accepted)
                          .toList();
                      return Column(
                        children: members
                            .map((m) => Padding(
                                  padding: const EdgeInsets.only(bottom: 8),
                                  child: KcCard(
                                    padding: EdgeInsets.zero,
                                    child: ListTile(
                                      leading: ExcludeSemantics(
                                          child: CircleAvatar(
                                              child: Text(
                                                  (m.displayName?.isNotEmpty ==
                                                              true
                                                          ? m.displayName![0]
                                                          : '?')
                                                      .toUpperCase()))),
                                      title: Text(
                                          '${m.displayName ?? m.email ?? 'Member'}${m.userId == uid ? ' (you)' : ''}'),
                                      subtitle: Text(m.role.label),
                                      trailing: isAdmin && m.userId != uid
                                          ? PopupMenuButton<String>(
                                              tooltip: 'Manage member',
                                              onSelected: (v) =>
                                                  _memberAction(context, m, v),
                                              itemBuilder: (_) => [
                                                ...FamilyRole.values
                                                    .where((r) => r != m.role)
                                                    .map((r) => PopupMenuItem(
                                                        value: 'role:${r.name}',
                                                        child: Text(
                                                            'Make ${r.label.toLowerCase()}'))),
                                                const PopupMenuItem(
                                                    value: 'remove',
                                                    child: Text(
                                                        'Remove from family')),
                                              ],
                                            )
                                          : null,
                                    ),
                                  ),
                                ))
                            .toList(),
                      );
                    },
                  ),
                  if (isAdmin) ...[
                    const KcSectionHeader('Pending invitations'),
                    StreamBuilder<List<Invitation>>(
                      stream: repo.watchFamilyInvitations(familyId),
                      builder: (context, snap) {
                        final list = snap.data ?? const <Invitation>[];
                        if (list.isEmpty) {
                          return const Text('No pending invitations.');
                        }
                        return Column(
                          children: list
                              .map((i) => ListTile(
                                    leading: const Icon(Icons.mail_outline),
                                    title: Text(i.inviteeEmail),
                                    subtitle: Text(
                                        '${i.role.label}${i.createdAt != null ? ' • sent ${Fmt.relative(i.createdAt!)}' : ''}'),
                                    trailing: TextButton(
                                      onPressed: () async {
                                        final ok = await showConfirmDialog(
                                            context,
                                            title: 'Revoke invitation?',
                                            message:
                                                '${i.inviteeEmail} will no longer be able to join.',
                                            confirmLabel: 'Revoke',
                                            destructive: true);
                                        if (ok && context.mounted) {
                                          await runGuarded(context,
                                              () => repo.revokeInvitation(i.id),
                                              success: 'Invitation revoked.');
                                        }
                                      },
                                      child: const Text('Revoke'),
                                    ),
                                  ))
                              .toList(),
                        );
                      },
                    ),
                  ],
                  const SizedBox(height: 96),
                ],
              ),
            );
          },
        );
      },
    );
  }

  String _roleHelp(FamilyRole r) => switch (r) {
        FamilyRole.admin =>
          'You can invite and remove members, change roles and manage care profiles.',
        FamilyRole.caregiver =>
          'You can manage reminders and see information shared for profiles you are assigned to.',
        FamilyRole.viewer =>
          'You can see information the family has chosen to share.',
        FamilyRole.elderly =>
          'You decide what is shared about you with your family.',
      };

  Future<void> _menu(
      BuildContext context, String v, FamilyMember me, Family? family) async {
    final repo = context.read<FamilyRepository>();
    if (v == 'rename') {
      final name = await showNameDialog(context,
          title: 'Rename family',
          label: 'Family name',
          initial: family?.name ?? '');
      if (name != null && context.mounted) {
        await runGuarded(context, () => repo.renameFamily(familyId, name),
            success: 'Family renamed.');
      }
    } else if (v == 'leave') {
      final ok = await showConfirmDialog(context,
          title: 'Leave this family?',
          message: me.role == FamilyRole.admin
              ? 'If you are the only administrator, make someone else an administrator first, or the family cannot be managed.'
              : 'You will lose access to shared information.',
          confirmLabel: 'Leave',
          destructive: true);
      if (!ok || !context.mounted) return;
      final done = await runGuarded(context, () async {
        await repo.removeMember(familyId, me.userId);
        return true;
      }, success: 'You left the family.');
      if (done == true && context.mounted) context.go(Routes.family);
    }
  }

  Future<void> _memberAction(
      BuildContext context, FamilyMember m, String v) async {
    final repo = context.read<FamilyRepository>();
    if (v == 'remove') {
      final ok = await showConfirmDialog(context,
          title: 'Remove ${m.displayName ?? 'member'}?',
          message:
              'They will immediately lose access to everything shared in this family.',
          confirmLabel: 'Remove',
          destructive: true);
      if (ok && context.mounted) {
        await runGuarded(context, () => repo.removeMember(familyId, m.userId),
            success: 'Member removed.');
      }
    } else if (v.startsWith('role:')) {
      final role = FamilyRoleX.parse(v.substring(5));
      final ok = await showConfirmDialog(context,
          title: 'Change role?',
          message:
              '${m.displayName ?? 'This member'} will become: ${role.label}.',
          confirmLabel: 'Change');
      if (ok && context.mounted) {
        await runGuarded(
            context, () => repo.changeRole(familyId, m.userId, role),
            success: 'Role updated.');
      }
    }
  }

  Future<void> _addProfile(BuildContext context, String uid) async {
    final name = await showNameDialog(context,
        title: 'Add care profile', label: 'Name of the person you care for');
    if (name == null || !context.mounted) return;
    final id = await runGuarded(
        context,
        () => context
            .read<FamilyRepository>()
            .addCareProfile(familyId: familyId, uid: uid, displayName: name),
        success: 'Care profile added.');
    if (id != null && context.mounted) {
      context.push(Routes.careProfile(familyId, id));
    }
  }

  Future<void> _invite(BuildContext context) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => Provider<FamilyRepository>.value(
          value: context.read<FamilyRepository>(),
          child: _InviteSheet(familyId: familyId)),
    );
  }
}

class _InviteSheet extends StatefulWidget {
  const _InviteSheet({required this.familyId});
  final String familyId;
  @override
  State<_InviteSheet> createState() => _InviteSheetState();
}

class _InviteSheetState extends State<_InviteSheet> {
  final _form = GlobalKey<FormState>();
  final _email = TextEditingController();
  FamilyRole _role = FamilyRole.caregiver;
  String? _profileId;
  bool _loading = false;
  String? _error;

  @override
  void dispose() {
    _email.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (!_form.currentState!.validate()) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      await context.read<FamilyRepository>().invite(
            familyId: widget.familyId,
            email: _email.text,
            role: _role,
            profileId: _role == FamilyRole.elderly ? _profileId : null,
          );
      if (!mounted) return;
      Navigator.pop(context);
      showSnack(context, 'Invitation sent to ${_email.text.trim()}.');
    } catch (e) {
      setState(() => _error = AppException.from(e).message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(KcSpacing.lg, 0, KcSpacing.lg,
          MediaQuery.viewInsetsOf(context).bottom + KcSpacing.lg),
      child: Form(
        key: _form,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Invite a family member',
                style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            const Text(
                'They will see the invitation in the app after signing up with this email.'),
            const SizedBox(height: KcSpacing.md),
            KcTextField(
                label: 'Email',
                controller: _email,
                validator: Validators.email,
                keyboardType: TextInputType.emailAddress,
                prefixIcon: Icons.email_outlined),
            const SizedBox(height: KcSpacing.md),
            DropdownButtonFormField<FamilyRole>(
              initialValue: _role,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Permission level'),
              items: FamilyRole.values
                  .map((r) => DropdownMenuItem(value: r, child: Text(r.label)))
                  .toList(),
              onChanged: (r) =>
                  setState(() => _role = r ?? FamilyRole.caregiver),
            ),
            if (_role == FamilyRole.elderly) ...[
              const SizedBox(height: KcSpacing.md),
              StreamBuilder<List<CareProfile>>(
                stream: context
                    .read<FamilyRepository>()
                    .watchProfiles(widget.familyId),
                builder: (context, snap) {
                  final profiles = (snap.data ?? const <CareProfile>[])
                      .where((p) => p.linkedUserId == null)
                      .toList();
                  return DropdownButtonFormField<String?>(
                    initialValue: _profileId,
                    isExpanded: true,
                    decoration: const InputDecoration(
                        labelText: 'Link to care profile (optional)'),
                    items: [
                      const DropdownMenuItem<String?>(
                          value: null, child: Text('Do not link')),
                      ...profiles.map((p) => DropdownMenuItem<String?>(
                          value: p.id, child: Text(p.displayName))),
                    ],
                    onChanged: (v) => setState(() => _profileId = v),
                  );
                },
              ),
              const SizedBox(height: 8),
              const Text(
                  'Once linked, they control what is shared about them.'),
            ],
            const SizedBox(height: KcSpacing.md),
            if (_error != null) ...[
              KcNotice(text: _error!, tone: KcNoticeTone.danger),
              const SizedBox(height: KcSpacing.md)
            ],
            KcButton(
                label: 'Send invitation',
                icon: Icons.send,
                loading: _loading,
                onPressed: _send),
          ],
        ),
      ),
    );
  }
}
