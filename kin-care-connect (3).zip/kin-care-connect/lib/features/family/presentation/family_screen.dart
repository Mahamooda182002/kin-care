import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/router/app_router.dart';
import '../../../core/services/session_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_exception.dart';
import '../../../core/utils/validators.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../../auth/data/auth_repository.dart';
import '../data/family_repository.dart';
import '../domain/family_models.dart';

/// Module I: family groups the user belongs to plus pending invitations.
class FamilyScreen extends StatelessWidget {
  const FamilyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionController>();
    final uid = session.uid;
    final email = context.read<AuthRepository>().currentEmail;
    if (uid == null) return const Scaffold(body: KcLoading());
    final repo = context.read<FamilyRepository>();

    return Scaffold(
      appBar: AppBar(title: const Text('Family')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _createFamily(context),
        icon: const Icon(Icons.group_add_outlined),
        label: const Text('Create family'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(KcSpacing.md),
        children: [
          if (email != null)
            StreamBuilder<List<Invitation>>(
              stream: repo.watchMyInvitations(email),
              builder: (context, snap) {
                final invites = snap.data ?? const <Invitation>[];
                if (invites.isEmpty) return const SizedBox.shrink();
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const KcSectionHeader('Invitations'),
                    ...invites.map((i) => _InvitationCard(invitation: i)),
                  ],
                );
              },
            ),
          const KcSectionHeader('Your families'),
          StreamBuilder<List<FamilyMember>>(
            stream: repo.watchMyMemberships(uid),
            builder: (context, snap) {
              if (snap.hasError) {
                return KcErrorView(
                    message: AppException.from(snap.error!).message);
              }
              if (!snap.hasData) return const KcLoading();
              if (snap.data!.isEmpty) {
                return const KcEmptyView(
                  icon: Icons.diversity_3_outlined,
                  title: 'No family groups yet',
                  message:
                      'Create a family group and invite relatives, or accept an invitation sent to your email.',
                );
              }
              return Column(
                children: snap.data!
                    .map((m) => StreamBuilder<Family?>(
                          stream: repo.watchFamily(m.familyId),
                          builder: (context, fs) {
                            final f = fs.data;
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: KcCard(
                                padding: EdgeInsets.zero,
                                onTap: () => context
                                    .push(Routes.familyDetail(m.familyId)),
                                child: ListTile(
                                  leading: const CircleAvatar(
                                      child: Icon(Icons.family_restroom)),
                                  title: Text(f?.name ?? 'Loading…'),
                                  subtitle: Text('Your role: ${m.role.label}'),
                                  trailing: const Icon(Icons.chevron_right),
                                ),
                              ),
                            );
                          },
                        ))
                    .toList(),
              );
            },
          ),
          const SizedBox(height: 80),
        ],
      ),
    );
  }

  Future<void> _createFamily(BuildContext context) async {
    final name = await showDialog<String>(
        context: context,
        builder: (_) => const _NameDialog(
            title: 'Create family group',
            label: 'Family name',
            hint: 'e.g. The Khan Family'));
    if (name == null || !context.mounted) return;
    final session = context.read<SessionController>();
    final user = session.user;
    final id = await runGuarded(
      context,
      () => context.read<FamilyRepository>().createFamily(
          uid: session.uid!,
          name: name,
          displayName: user?.fullName ?? '',
          email: user?.email ?? ''),
      success: 'Family group created.',
    );
    if (id != null && context.mounted) context.push(Routes.familyDetail(id));
  }
}

class _InvitationCard extends StatefulWidget {
  const _InvitationCard({required this.invitation});
  final Invitation invitation;
  @override
  State<_InvitationCard> createState() => _InvitationCardState();
}

class _InvitationCardState extends State<_InvitationCard> {
  bool _busy = false;

  Future<void> _respond(bool accept) async {
    final auth = context.read<AuthRepository>();
    if (accept && !auth.emailVerified) {
      final verified = await auth.reloadAndCheckVerified();
      if (!verified) {
        if (mounted) {
          showSnack(context,
              'Please verify your email first (check your inbox), then try again.',
              error: true);
        }
        return;
      }
    }
    if (!mounted) return;
    setState(() => _busy = true);
    await runGuarded(
        context,
        () => context
            .read<FamilyRepository>()
            .respondToInvitation(widget.invitation.id, accept: accept),
        success: accept
            ? 'You joined ${widget.invitation.familyName}.'
            : 'Invitation declined.');
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final i = widget.invitation;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: KcCard(
        color: KcColors.tealLight,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${i.invitedByName} invited you to join ${i.familyName}',
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(color: KcColors.ink)),
            const SizedBox(height: 4),
            Text('Role: ${i.role.label}',
                style: const TextStyle(color: KcColors.ink)),
            const SizedBox(height: 12),
            if (_busy)
              const LinearProgressIndicator()
            else
              Row(children: [
                Expanded(
                    child: KcButton(
                        label: 'Accept', onPressed: () => _respond(true))),
                const SizedBox(width: 12),
                Expanded(
                    child: KcButton(
                        label: 'Decline',
                        variant: KcButtonVariant.outlined,
                        onPressed: () => _respond(false))),
              ]),
          ],
        ),
      ),
    );
  }
}

class _NameDialog extends StatefulWidget {
  const _NameDialog(
      {required this.title, required this.label, this.hint, this.initial = ''});
  final String title;
  final String label;
  final String? hint;
  final String initial;
  @override
  State<_NameDialog> createState() => _NameDialogState();
}

class _NameDialogState extends State<_NameDialog> {
  late final _c = TextEditingController(text: widget.initial);
  final _form = GlobalKey<FormState>();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.title),
      content: Form(
        key: _form,
        child: KcTextField(
          label: widget.label,
          hint: widget.hint,
          controller: _c,
          maxLength: 60,
          validator: (v) => Validators.required(v, field: widget.label),
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel')),
        FilledButton(
          style: FilledButton.styleFrom(minimumSize: const Size(100, 48)),
          onPressed: () {
            if (_form.currentState!.validate()) {
              Navigator.pop(context, _c.text.trim());
            }
          },
          child: const Text('Save'),
        ),
      ],
    );
  }
}

Future<String?> showNameDialog(BuildContext context,
        {required String title, required String label, String initial = ''}) =>
    showDialog<String>(
        context: context,
        builder: (_) =>
            _NameDialog(title: title, label: label, initial: initial));
