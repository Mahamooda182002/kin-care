import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/router/app_router.dart';
import '../../../core/services/session_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_exception.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../data/family_repository.dart';
import '../domain/family_models.dart';
import 'family_screen.dart';

/// Care profile: sharing consent, caregiver assignment and shortcuts to
/// shared activity and reminders.
class CareProfileScreen extends StatelessWidget {
  const CareProfileScreen(
      {super.key, required this.familyId, required this.profileId});
  final String familyId;
  final String profileId;

  @override
  Widget build(BuildContext context) {
    final uid = context.watch<SessionController>().uid;
    if (uid == null) return const Scaffold(body: KcLoading());
    final repo = context.read<FamilyRepository>();

    return StreamBuilder<FamilyMember?>(
      stream: repo.watchMyMembership(familyId, uid),
      builder: (context, ms) {
        final me = ms.data;
        return StreamBuilder<CareProfile?>(
          stream: repo.watchProfile(profileId),
          builder: (context, ps) {
            if (ps.hasError) {
              return Scaffold(
                  appBar: AppBar(),
                  body: KcErrorView(
                      message: AppException.from(ps.error!).message));
            }
            if (!ps.hasData && ps.connectionState == ConnectionState.waiting) {
              return const Scaffold(body: KcLoading());
            }
            final p = ps.data;
            if (p == null) {
              return Scaffold(
                  appBar: AppBar(),
                  body: const KcEmptyView(
                      icon: Icons.search_off, title: 'Profile not found'));
            }
            final isAdmin = me?.role == FamilyRole.admin;
            final controlsConsent = p.consentControlledBy(uid, me?.role);
            final c = p.sharingConsent;

            Future<void> setConsent(SharingConsent n, String what) async {
              final ok = await showConfirmDialog(context,
                  title: 'Change sharing?',
                  message:
                      'You are about to $what. Family members with access to this profile will be affected immediately.',
                  confirmLabel: 'Confirm');
              if (ok && context.mounted) {
                await runGuarded(
                    context, () => repo.updateConsent(p.id, n, uid),
                    success: 'Sharing updated.');
              }
            }

            return Scaffold(
              appBar: AppBar(
                title: Text(p.displayName),
                actions: [
                  if (isAdmin)
                    PopupMenuButton<String>(
                      tooltip: 'Care profile options',
                      onSelected: (v) async {
                        if (v == 'rename') {
                          final name = await showNameDialog(context,
                              title: 'Rename profile',
                              label: 'Name',
                              initial: p.displayName);
                          if (name != null && context.mounted) {
                            await runGuarded(
                                context,
                                () => repo.updateCareProfile(p.id,
                                    displayName: name, notes: p.notes));
                          }
                        } else if (v == 'delete') {
                          final ok = await showConfirmDialog(context,
                              title: 'Delete care profile?',
                              message:
                                  'Reminders and shared items linked to this profile will no longer be shared.',
                              confirmLabel: 'Delete',
                              destructive: true);
                          if (!ok || !context.mounted) return;
                          final done = await runGuarded(context, () async {
                            await repo.deleteCareProfile(p.id);
                            return true;
                          });
                          if (done == true && context.mounted) context.pop();
                        }
                      },
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'rename', child: Text('Rename')),
                        PopupMenuItem(
                            value: 'delete', child: Text('Delete profile')),
                      ],
                    ),
                ],
              ),
              body: ListView(
                padding: const EdgeInsets.all(KcSpacing.md),
                children: [
                  KcNotice(
                    text: p.linkedUserId != null
                        ? (p.linkedUserId == uid
                            ? 'This is your profile. You decide what your family can see.'
                            : 'This person has their own account and controls what is shared.')
                        : 'No elderly account is linked yet. The family administrator manages sharing until one is linked.',
                  ),
                  const KcSectionHeader('Sharing approvals'),
                  KcCard(
                    padding: EdgeInsets.zero,
                    child: Column(
                      children: [
                        SwitchListTile(
                          title: const Text('Share routine activity'),
                          subtitle: const Text(
                              'In-app activity only. Never health or emergency detection.'),
                          value: c.activity,
                          onChanged: controlsConsent
                              ? (v) => setConsent(
                                  c.copyWith(activity: v),
                                  v
                                      ? 'share routine activity'
                                      : 'stop sharing routine activity')
                              : null,
                        ),
                        SwitchListTile(
                          title: const Text('Share medical summaries'),
                          subtitle: const Text(
                              'Only summaries someone chooses to share with this profile'),
                          value: c.medical,
                          onChanged: controlsConsent
                              ? (v) => setConsent(
                                  c.copyWith(medical: v),
                                  v
                                      ? 'share medical summaries'
                                      : 'stop sharing medical summaries')
                              : null,
                        ),
                        SwitchListTile(
                          title: const Text('Share care reminders'),
                          subtitle: const Text(
                              'Lets assigned caregivers see and manage reminders'),
                          value: c.reminders,
                          onChanged: controlsConsent
                              ? (v) => setConsent(
                                  c.copyWith(reminders: v),
                                  v
                                      ? 'share care reminders'
                                      : 'stop sharing care reminders')
                              : null,
                        ),
                      ],
                    ),
                  ),
                  if (!controlsConsent)
                    const Padding(
                      padding: EdgeInsets.only(top: 8),
                      child: Text(
                          'Only the person themselves (or the family administrator, if no account is linked) can change sharing.'),
                    ),
                  const KcSectionHeader('Shared information'),
                  KcCard(
                    padding: EdgeInsets.zero,
                    child: Column(children: [
                      ListTile(
                        leading: const Icon(Icons.timeline),
                        title: const Text('Activity'),
                        trailing: Icon(c.activity
                            ? Icons.chevron_right
                            : Icons.lock_outline),
                        enabled: c.activity,
                        onTap: () => context.push(
                            '${Routes.routineHistory}?profileId=${p.id}&familyId=${p.familyId}'),
                      ),
                      ListTile(
                        leading: const Icon(Icons.alarm),
                        title: const Text('Care reminders'),
                        trailing: Icon(c.reminders
                            ? Icons.chevron_right
                            : Icons.lock_outline),
                        enabled: c.reminders,
                        onTap: () => context
                            .push('${Routes.reminders}?profileId=${p.id}'),
                      ),
                    ]),
                  ),
                  if (isAdmin) ...[
                    const KcSectionHeader('Assigned caregivers'),
                    StreamBuilder<List<FamilyMember>>(
                      stream: repo.watchMembers(familyId),
                      builder: (context, snap) {
                        final caregivers = (snap.data ?? const <FamilyMember>[])
                            .where((m) =>
                                m.status == InvitationStatus.accepted &&
                                (m.role == FamilyRole.caregiver ||
                                    m.role == FamilyRole.admin))
                            .toList();
                        if (caregivers.isEmpty) {
                          return const Text(
                              'Invite a caregiver to assign them.');
                        }
                        return KcCard(
                          padding: EdgeInsets.zero,
                          child: Column(
                            children: caregivers
                                .map((m) => CheckboxListTile(
                                      title: Text(
                                          m.displayName ?? m.email ?? 'Member'),
                                      subtitle: Text(m.role.label),
                                      value: p.caregiverIds.contains(m.userId),
                                      onChanged: (v) => runGuarded(
                                          context,
                                          () => repo.setCaregiverAssigned(
                                              p.id, m.userId, v ?? false)),
                                    ))
                                .toList(),
                          ),
                        );
                      },
                    ),
                  ],
                  const SizedBox(height: KcSpacing.xl),
                ],
              ),
            );
          },
        );
      },
    );
  }
}
