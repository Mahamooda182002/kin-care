import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../core/services/functions_service.dart';
import '../../../core/utils/app_exception.dart';
import '../domain/family_models.dart';

/// Family groups, memberships, care profiles and invitations.
///
/// Permissions are enforced by firestore.rules and Cloud Functions; the UI
/// only hides actions as a convenience.
class FamilyRepository {
  FamilyRepository(this._db, this._functions);
  final FirebaseFirestore _db;
  final FunctionsService _functions;

  CollectionReference<Map<String, dynamic>> get _families =>
      _db.collection('families');
  CollectionReference<Map<String, dynamic>> get _members =>
      _db.collection('familyMembers');
  CollectionReference<Map<String, dynamic>> get _profiles =>
      _db.collection('careProfiles');

  /// Accepted memberships of the current user.
  Stream<List<FamilyMember>> watchMyMemberships(String uid) => _members
      .where('userId', isEqualTo: uid)
      .where('invitationStatus', isEqualTo: 'accepted')
      .snapshots()
      .map((s) => s.docs.map(FamilyMember.fromDoc).toList());

  Stream<Family?> watchFamily(String familyId) => _families
      .doc(familyId)
      .snapshots()
      .map((d) => d.exists ? Family.fromDoc(d) : null);

  Stream<List<FamilyMember>> watchMembers(String familyId) => _members
      .where('familyId', isEqualTo: familyId)
      .snapshots()
      .map((s) => s.docs.map(FamilyMember.fromDoc).toList());

  Stream<FamilyMember?> watchMyMembership(String familyId, String uid) =>
      _members
          .doc(FamilyMember.idFor(familyId, uid))
          .snapshots()
          .map((d) => d.exists ? FamilyMember.fromDoc(d) : null);

  Stream<List<CareProfile>> watchProfiles(String familyId) => _profiles
      .where('familyId', isEqualTo: familyId)
      .snapshots()
      .map((s) => s.docs.map(CareProfile.fromDoc).toList());

  Stream<CareProfile?> watchProfile(String profileId) => _profiles
      .doc(profileId)
      .snapshots()
      .map((d) => d.exists ? CareProfile.fromDoc(d) : null);

  /// Care profiles linked to this user's own (elderly) account.
  Stream<List<CareProfile>> watchProfilesLinkedTo(String uid) => _profiles
      .where('linkedUserId', isEqualTo: uid)
      .snapshots()
      .map((s) => s.docs.map(CareProfile.fromDoc).toList());

  /// Pending invitations addressed to this email (rules check the token email).
  Stream<List<Invitation>> watchMyInvitations(String email) => _db
      .collection('invitations')
      .where('inviteeEmail', isEqualTo: email.toLowerCase())
      .where('status', isEqualTo: 'pending')
      .snapshots()
      .map((s) => s.docs.map(Invitation.fromDoc).toList());

  Stream<List<Invitation>> watchFamilyInvitations(String familyId) => _db
      .collection('invitations')
      .where('familyId', isEqualTo: familyId)
      .where('status', isEqualTo: 'pending')
      .snapshots()
      .map((s) => s.docs.map(Invitation.fromDoc).toList());

  /// Creates a family and the creator's admin membership atomically.
  Future<String> createFamily(
      {required String uid,
      required String name,
      required String displayName,
      required String email}) async {
    try {
      final famRef = _families.doc();
      final batch = _db.batch();
      batch.set(famRef, {
        'familyId': famRef.id,
        'familyName': name.trim(),
        'createdBy': uid,
        'createdAt': FieldValue.serverTimestamp(),
      });
      batch.set(_members.doc(FamilyMember.idFor(famRef.id, uid)), {
        'membershipId': FamilyMember.idFor(famRef.id, uid),
        'familyId': famRef.id,
        'userId': uid,
        'role': 'admin',
        'permissions': {'manageFamily': true, 'editCare': true},
        'invitationStatus': 'accepted',
        'displayName': displayName,
        'email': email.toLowerCase(),
        'createdAt': FieldValue.serverTimestamp(),
      });
      await batch.commit();
      return famRef.id;
    } catch (e) {
      throw AppException.from(e);
    }
  }

  Future<void> renameFamily(String familyId, String name) =>
      _guard(() => _families.doc(familyId).update({'familyName': name.trim()}));

  Future<String> addCareProfile(
      {required String familyId,
      required String uid,
      required String displayName,
      String? notes}) async {
    try {
      final ref = _profiles.doc();
      await ref.set({
        'profileId': ref.id,
        'familyId': familyId,
        'displayName': displayName.trim(),
        'notes': (notes == null || notes.trim().isEmpty) ? null : notes.trim(),
        'createdBy': uid,
        'linkedUserId': null,
        'caregiverIds': <String>[],
        // Nothing is shared until explicitly approved.
        'sharingConsent': const SharingConsent().toMap(),
        'createdAt': FieldValue.serverTimestamp(),
      });
      return ref.id;
    } catch (e) {
      throw AppException.from(e);
    }
  }

  Future<void> updateCareProfile(String profileId,
          {required String displayName, String? notes}) =>
      _guard(() => _profiles.doc(profileId).update({
            'displayName': displayName.trim(),
            'notes':
                (notes == null || notes.trim().isEmpty) ? null : notes.trim(),
          }));

  Future<void> deleteCareProfile(String profileId) =>
      _guard(() => _profiles.doc(profileId).delete());

  Future<void> setCaregiverAssigned(
          String profileId, String caregiverUid, bool assigned) =>
      _guard(() => _profiles.doc(profileId).update({
            'caregiverIds': assigned
                ? FieldValue.arrayUnion([caregiverUid])
                : FieldValue.arrayRemove([caregiverUid]),
          }));

  Future<void> updateConsent(
          String profileId, SharingConsent consent, String uid) =>
      _guard(() => _profiles.doc(profileId).update({
            'sharingConsent': consent.toMap(),
            'consentUpdatedBy': uid,
            'consentUpdatedAt': FieldValue.serverTimestamp(),
          }));

  Future<void> changeRole(String familyId, String memberUid, FamilyRole role) =>
      _guard(
          () => _members.doc(FamilyMember.idFor(familyId, memberUid)).update({
                'role': role.value,
                'permissions': {
                  'manageFamily': role == FamilyRole.admin,
                  'editCare': role.canEditCare,
                },
              }));

  /// Admin removes a member, or a member leaves. Rules allow both.
  Future<void> removeMember(String familyId, String memberUid) => _guard(
      () => _members.doc(FamilyMember.idFor(familyId, memberUid)).delete());

  Future<void> invite(
      {required String familyId,
      required String email,
      required FamilyRole role,
      String? profileId}) async {
    await _functions.call('familyInvite', {
      'familyId': familyId,
      'email': email.trim().toLowerCase(),
      'role': role.value,
      if (profileId != null) 'profileId': profileId,
    });
  }

  Future<void> respondToInvitation(String invitationId,
      {required bool accept}) async {
    await _functions.call('familyAcceptInvitation',
        {'invitationId': invitationId, 'accept': accept});
  }

  Future<void> revokeInvitation(String invitationId) async {
    await _functions
        .call('familyRevokeInvitation', {'invitationId': invitationId});
  }

  Future<void> _guard(Future<void> Function() f) async {
    try {
      await f();
    } catch (e) {
      throw AppException.from(e);
    }
  }
}
