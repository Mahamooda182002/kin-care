import 'package:flutter/material.dart';

import '../../domain/app_user.dart';

class UserAvatar extends StatelessWidget {
  const UserAvatar({super.key, required this.user, this.radius = 24});
  final AppUser? user;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final img = user?.profileImage;
    return Semantics(
      label: img != null
          ? 'Profile picture of ${user?.fullName ?? 'you'}'
          : 'Initials of ${user?.fullName ?? 'you'}',
      image: true,
      excludeSemantics: true,
      child: CircleAvatar(
        radius: radius,
        backgroundColor: scheme.primaryContainer,
        foregroundImage: img != null ? NetworkImage(img) : null,
        // If the picture cannot load, the initials stay visible.
        onForegroundImageError: img != null ? (_, __) {} : null,
        child: Text(
          user?.initials ?? '?',
          style: TextStyle(
              color: scheme.onPrimaryContainer,
              fontWeight: FontWeight.w700,
              fontSize: radius * 0.7),
        ),
      ),
    );
  }
}
