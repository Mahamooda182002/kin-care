import 'dart:io';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../../core/services/session_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/validators.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../data/profile_repository.dart';
import '../domain/app_user.dart';
import 'widgets/avatar.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});
  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  AccountRole _role = AccountRole.caregiver;
  bool _initialised = false;
  bool _saving = false;
  bool _uploading = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final u = context.read<SessionController>().user;
    if (!_initialised && u != null) {
      _name.text = u.fullName;
      _role = u.role;
      _initialised = true;
    }
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final hasPhoto =
        context.read<SessionController>().user?.profileImage != null;
    // null = dismissed, 'remove' = delete the current photo.
    final choice = await showModalBottomSheet<Object>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: const Text('Take a photo'),
              onTap: () => Navigator.pop(ctx, ImageSource.camera)),
          ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: const Text('Choose from gallery'),
              onTap: () => Navigator.pop(ctx, ImageSource.gallery)),
          if (hasPhoto)
            ListTile(
                leading: const Icon(Icons.delete_outline),
                title: const Text('Remove photo'),
                onTap: () => Navigator.pop(ctx, 'remove')),
        ]),
      ),
    );
    if (choice == null || !mounted) return;
    final uid = context.read<SessionController>().uid!;
    if (choice == 'remove') {
      setState(() => _uploading = true);
      await runGuarded(context,
          () => context.read<ProfileRepository>().removeProfileImage(uid),
          success: 'Profile picture removed.');
      if (mounted) setState(() => _uploading = false);
      return;
    }
    final x = await ImagePicker().pickImage(
        source: choice as ImageSource,
        maxWidth: 800,
        maxHeight: 800,
        imageQuality: 80);
    if (x == null || !mounted) return;
    setState(() => _uploading = true);
    await runGuarded(
        context,
        () => context
            .read<ProfileRepository>()
            .uploadProfileImage(uid, File(x.path)),
        success: 'Profile picture updated.');
    if (mounted) setState(() => _uploading = false);
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final uid = context.read<SessionController>().uid!;
    setState(() => _saving = true);
    final ok = await runGuarded(context, () async {
      await context
          .read<ProfileRepository>()
          .updateProfile(uid, fullName: _name.text, role: _role);
      return true;
    }, success: 'Profile saved.');
    if (!mounted) return;
    setState(() => _saving = false);
    if (ok == true) context.pop();
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<SessionController>().user;
    return Scaffold(
      appBar: AppBar(title: const Text('Edit profile')),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(KcSpacing.md),
          children: [
            Center(
              child: Stack(children: [
                UserAvatar(user: user, radius: 52),
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: _uploading
                      ? const CircularProgressIndicator(
                          semanticsLabel: 'Updating profile picture')
                      : IconButton.filled(
                          tooltip: 'Change profile picture',
                          onPressed: _pickImage,
                          icon: const Icon(Icons.photo_camera)),
                ),
              ]),
            ),
            const SizedBox(height: KcSpacing.lg),
            KcTextField(
                label: 'Full name',
                controller: _name,
                validator: Validators.fullName,
                prefixIcon: Icons.person_outline),
            const SizedBox(height: KcSpacing.md),
            KcTextField(
                label: 'Email',
                controller: TextEditingController(text: user?.email ?? ''),
                enabled: false,
                prefixIcon: Icons.email_outlined),
            const SizedBox(height: KcSpacing.md),
            Text('I am using Kin Care Connect as',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            SegmentedButton<AccountRole>(
              segments: const [
                ButtonSegment(
                    value: AccountRole.elderly,
                    icon: Icon(Icons.elderly),
                    label: Text('Elderly member')),
                ButtonSegment(
                    value: AccountRole.caregiver,
                    icon: Icon(Icons.volunteer_activism_outlined),
                    label: Text('Caregiver')),
              ],
              selected: {_role},
              onSelectionChanged: (s) => setState(() => _role = s.first),
            ),
            const SizedBox(height: 8),
            const Text(
                'You can also have different roles in each family group (for example, a caregiver for your mother and an administrator of your own family).'),
            const SizedBox(height: KcSpacing.lg),
            KcButton(label: 'Save changes', loading: _saving, onPressed: _save),
          ],
        ),
      ),
    );
  }
}
