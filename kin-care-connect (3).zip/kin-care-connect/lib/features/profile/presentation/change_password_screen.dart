import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_exception.dart';
import '../../../core/utils/validators.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../../auth/data/auth_repository.dart';

class ChangePasswordScreen extends StatefulWidget {
  const ChangePasswordScreen({super.key});
  @override
  State<ChangePasswordScreen> createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  final _form = GlobalKey<FormState>();
  final _current = TextEditingController();
  final _new = TextEditingController();
  final _confirm = TextEditingController();
  bool _loading = false;
  String? _error;

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    if (_current.text == _new.text) {
      setState(() => _error = 'Your new password must be different.');
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      await context.read<AuthRepository>().changePassword(
          currentPassword: _current.text, newPassword: _new.text);
      if (!mounted) return;
      showSnack(context, 'Password changed.');
      context.pop();
    } catch (e) {
      setState(() => _error = AppException.from(e).message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _current.dispose();
    _new.dispose();
    _confirm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Change password')),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(KcSpacing.md),
          children: [
            KcPasswordField(
                label: 'Current password',
                controller: _current,
                validator: (v) => (v == null || v.isEmpty)
                    ? 'Enter your current password.'
                    : null),
            const SizedBox(height: KcSpacing.md),
            KcPasswordField(
                label: 'New password',
                controller: _new,
                validator: Validators.password,
                autofillHints: const [AutofillHints.newPassword]),
            const SizedBox(height: KcSpacing.md),
            KcPasswordField(
                label: 'Confirm new password',
                controller: _confirm,
                validator: (v) => Validators.confirmPassword(v, _new.text),
                autofillHints: const [AutofillHints.newPassword]),
            const SizedBox(height: KcSpacing.lg),
            if (_error != null) ...[
              KcNotice(text: _error!, tone: KcNoticeTone.danger),
              const SizedBox(height: KcSpacing.md)
            ],
            KcButton(
                label: 'Change password',
                loading: _loading,
                onPressed: _submit),
          ],
        ),
      ),
    );
  }
}
