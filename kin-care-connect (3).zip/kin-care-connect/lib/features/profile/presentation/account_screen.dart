import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../../../core/config/business_info.dart';
import '../../../core/router/app_router.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/app_exception.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../../auth/data/auth_repository.dart';
import '../data/profile_repository.dart';

/// Account management: export data and delete account.
class AccountScreen extends StatefulWidget {
  const AccountScreen({super.key});
  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  bool _exporting = false;
  bool _deleting = false;

  Future<void> _export() async {
    setState(() => _exporting = true);
    final json = await runGuarded(
        context, () => context.read<ProfileRepository>().exportData());
    if (mounted) setState(() => _exporting = false);
    if (json == null || !mounted) return;
    await SharePlus.instance
        .share(ShareParams(text: json, subject: 'My Kin Care Connect data'));
  }

  Future<void> _delete() async {
    final ok = await showConfirmDialog(
      context,
      title: 'Delete your account?',
      message:
          'This permanently deletes your profile, reminders, medical summaries, recordings, scam-check history, emergency contacts, notifications, activity records, family memberships and invitations, your profile picture and your sign-in account. Families you administer alone are deleted too, with their care profiles. This cannot be undone.\n\nYou may want to export your data first.',
      confirmLabel: 'Continue',
      destructive: true,
    );
    if (!ok || !mounted) return;
    final password = await showDialog<String>(
        context: context, builder: (_) => const _PasswordDialog());
    if (password == null || !mounted) return;
    setState(() => _deleting = true);
    try {
      await context.read<AuthRepository>().reauthenticate(password);
      if (!mounted) return;
      await context.read<ProfileRepository>().deleteAccount();
      if (!mounted) return;
      await context.read<AuthRepository>().signOut();
    } catch (e) {
      if (mounted) {
        showSnack(context, AppException.from(e).message, error: true);
      }
    } finally {
      if (mounted) setState(() => _deleting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Account')),
      body: ListView(
        padding: const EdgeInsets.all(KcSpacing.md),
        children: [
          const KcSectionHeader('Your data'),
          const Text(
              'Download a copy of the information Kin Care Connect stores about you (JSON format).'),
          const SizedBox(height: 12),
          KcButton(
              label: 'Export my data',
              icon: Icons.download_outlined,
              variant: KcButtonVariant.tonal,
              loading: _exporting,
              onPressed: _export),
          const KcSectionHeader('Delete account'),
          const KcNotice(
              text:
                  'Deleting your account removes your data from our live database and file storage straight away, and deletes your sign-in. Any backup copies (if the operator has enabled backups) are removed when those backups expire.',
              tone: KcNoticeTone.warning),
          const SizedBox(height: 12),
          KcButton(
              label: 'Delete my account',
              icon: Icons.delete_forever_outlined,
              variant: KcButtonVariant.danger,
              loading: _deleting,
              onPressed: _delete),
          const SizedBox(height: KcSpacing.md),
          const Text(
              'Can\'t sign in? You can also ask for deletion by emailing '
              '${BusinessInfo.supportEmail} from your account\'s email address.'),
          TextButton(
              onPressed: () => context.push(Routes.legal('deletion')),
              child: const Text('What gets deleted')),
        ],
      ),
    );
  }
}

class _PasswordDialog extends StatefulWidget {
  const _PasswordDialog();
  @override
  State<_PasswordDialog> createState() => _PasswordDialogState();
}

class _PasswordDialogState extends State<_PasswordDialog> {
  final _c = TextEditingController();
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: const Text('Confirm with your password'),
        content: KcPasswordField(label: 'Password', controller: _c),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          FilledButton(
            style: FilledButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.error,
                minimumSize: const Size(100, 48)),
            onPressed: () =>
                _c.text.isEmpty ? null : Navigator.pop(context, _c.text),
            child: const Text('Delete account'),
          ),
        ],
      );
}
