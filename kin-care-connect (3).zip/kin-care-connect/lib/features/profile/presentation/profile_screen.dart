import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/router/app_router.dart';
import '../../../core/services/session_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../../auth/data/auth_repository.dart';
import '../../notifications/data/notification_repository.dart';
import '../domain/app_user.dart';
import 'widgets/avatar.dart';

/// Module D overview + entry to Settings (Module M).
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  static Future<void> logout(BuildContext context) async {
    final ok = await showConfirmDialog(context,
        title: 'Log out?',
        message: 'You will need your email and password to sign in again.',
        confirmLabel: 'Log out');
    if (!ok || !context.mounted) return;
    final uid = context.read<SessionController>().uid;
    if (uid != null) {
      await context.read<NotificationRepository>().unregisterDevice(uid);
    }
    if (!context.mounted) return;
    await context.read<AuthRepository>().signOut();
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<SessionController>().user;
    if (user == null) return const Scaffold(body: KcLoading());
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: ListView(
        padding: const EdgeInsets.all(KcSpacing.md),
        children: [
          KcCard(
            child: Row(children: [
              UserAvatar(user: user, radius: 36),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(user.fullName,
                          style: Theme.of(context).textTheme.titleLarge),
                      Text(user.email),
                      const SizedBox(height: 6),
                      KcChip(user.role.label),
                    ]),
              ),
            ]),
          ),
          const SizedBox(height: KcSpacing.md),
          KcCard(
            padding: EdgeInsets.zero,
            child: Column(children: [
              _Item(
                  icon: Icons.edit_outlined,
                  label: 'Edit profile',
                  onTap: () => context.push(Routes.editProfile)),
              _Item(
                  icon: Icons.accessibility_new,
                  label: 'Accessibility',
                  onTap: () => context.push(Routes.accessibility)),
              _Item(
                  icon: Icons.notifications_outlined,
                  label: 'Notifications',
                  onTap: () => context.push(Routes.notificationSettings)),
              _Item(
                  icon: Icons.lock_outline,
                  label: 'Change password',
                  onTap: () => context.push(Routes.changePassword)),
              _Item(
                  icon: Icons.contact_phone_outlined,
                  label: 'Emergency contacts',
                  onTap: () => context.push(Routes.emergency)),
              _Item(
                  icon: Icons.settings_outlined,
                  label: 'All settings',
                  onTap: () => context.push(Routes.settings)),
            ]),
          ),
          const SizedBox(height: KcSpacing.md),
          KcButton(
              label: 'Log out',
              icon: Icons.logout,
              variant: KcButtonVariant.outlined,
              onPressed: () => logout(context)),
        ],
      ),
    );
  }
}

class _Item extends StatelessWidget {
  const _Item({required this.icon, required this.label, required this.onTap});
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => ListTile(
      leading: Icon(icon),
      title: Text(label),
      trailing: const Icon(Icons.chevron_right),
      onTap: onTap);
}
