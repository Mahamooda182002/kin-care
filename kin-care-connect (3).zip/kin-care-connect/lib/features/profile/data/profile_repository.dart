import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

import '../../../core/config/legal_versions.dart';
import '../../../core/services/functions_service.dart';
import '../../../core/utils/app_exception.dart';
import '../domain/app_user.dart';

class ProfileRepository {
  ProfileRepository(this._db, this._storage, this._functions);
  final FirebaseFirestore _db;
  final FirebaseStorage _storage;
  final FunctionsService _functions;

  DocumentReference<Map<String, dynamic>> _doc(String uid) =>
      _db.collection('users').doc(uid);

  Stream<AppUser?> watch(String uid) =>
      _doc(uid).snapshots().map((s) => s.exists ? AppUser.fromDoc(s) : null);

  Future<void> updateProfile(String uid,
      {required String fullName, required AccountRole role}) async {
    try {
      await _doc(uid).update({
        'fullName': fullName.trim(),
        // Data minimisation: the account phone number is no longer collected.
        // Remove any value stored by earlier versions.
        'phone': FieldValue.delete(),
        'role': role.value,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      throw AppException.from(e);
    }
  }

  Future<void> updateAccessibility(String uid,
          {required bool largeText, required bool highContrast}) =>
      _guard(() => _doc(uid).update({
            'accessibilitySettings': {
              'largeText': largeText,
              'highContrast': highContrast
            },
            'updatedAt': FieldValue.serverTimestamp(),
          }));

  Future<void> updateNotificationPrefs(String uid, NotificationPrefs prefs) =>
      _guard(() => _doc(uid).update({
            'notificationPrefs': prefs.toMap(),
            'updatedAt': FieldValue.serverTimestamp(),
          }));

  Future<void> updatePrivacy(String uid, PrivacySettings p) =>
      _guard(() => _doc(uid).update({
            'privacy': {
              ...p.toMap(),
              'policyVersion': LegalVersions.privacy,
              'updatedAt': FieldValue.serverTimestamp(),
            },
            'updatedAt': FieldValue.serverTimestamp(),
          }));

  /// Uploads a profile picture (JPEG/PNG, max 5 MB enforced by storage rules).
  Future<void> uploadProfileImage(String uid, File file) async {
    try {
      final ext = file.path.toLowerCase().endsWith('.png') ? 'png' : 'jpg';
      final ref = _storage.ref('profileImages/$uid/avatar.$ext');
      await ref.putFile(
          file,
          SettableMetadata(
              contentType: ext == 'png' ? 'image/png' : 'image/jpeg'));
      final url = await ref.getDownloadURL();
      await _doc(uid).update(
          {'profileImage': url, 'updatedAt': FieldValue.serverTimestamp()});
    } catch (e) {
      throw AppException.from(e);
    }
  }

  /// Deletes the profile picture from Storage and the profile.
  Future<void> removeProfileImage(String uid) async {
    try {
      for (final ext in ['jpg', 'png']) {
        try {
          await _storage.ref('profileImages/$uid/avatar.$ext').delete();
        } on FirebaseException catch (e) {
          if (e.code != 'object-not-found') rethrow;
        }
      }
      await _doc(uid).update(
          {'profileImage': null, 'updatedAt': FieldValue.serverTimestamp()});
    } catch (e) {
      throw AppException.from(e);
    }
  }

  /// Server-side export of everything the user owns, as JSON text.
  Future<String> exportData() async {
    final r = await _functions.call('accountExportData');
    return (r['json'] as String?) ?? '{}';
  }

  /// Server-side deletion of the user's data and auth account. The caller must
  /// re-authenticate first (see AuthRepository.reauthenticate).
  Future<void> deleteAccount() async {
    await _functions.call(
        'accountDelete', {'confirm': true}, const Duration(seconds: 120));
  }

  Future<void> _guard(Future<void> Function() f) async {
    try {
      await f();
    } catch (e) {
      throw AppException.from(e);
    }
  }
}
