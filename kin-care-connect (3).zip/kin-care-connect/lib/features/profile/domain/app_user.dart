import 'package:cloud_firestore/cloud_firestore.dart';

enum AccountRole { elderly, caregiver }

extension AccountRoleX on AccountRole {
  String get label =>
      this == AccountRole.elderly ? 'Elderly member' : 'Family caregiver';
  String get value => name;
  static AccountRole parse(String? v) =>
      v == 'elderly' ? AccountRole.elderly : AccountRole.caregiver;
}

class NotificationPrefs {
  const NotificationPrefs({
    this.reminders = true,
    this.familyInvitations = true,
    this.activityUpdates = true,
    this.reminderCompletion = true,
    this.securityEvents = true,
    this.showDetailsOnLockScreen = false,
  });

  final bool reminders;
  final bool familyInvitations;
  final bool activityUpdates;
  final bool reminderCompletion;
  final bool securityEvents;
  final bool showDetailsOnLockScreen;

  factory NotificationPrefs.fromMap(Map<String, dynamic>? m) {
    m ??= const {};
    bool b(String k, bool d) => m![k] is bool ? m[k] as bool : d;
    return NotificationPrefs(
      reminders: b('reminders', true),
      familyInvitations: b('familyInvitations', true),
      activityUpdates: b('activityUpdates', true),
      reminderCompletion: b('reminderCompletion', true),
      securityEvents: b('securityEvents', true),
      showDetailsOnLockScreen: b('showDetailsOnLockScreen', false),
    );
  }

  /// True when every category is switched off.
  bool get allOff =>
      !reminders &&
      !familyInvitations &&
      !activityUpdates &&
      !reminderCompletion &&
      !securityEvents;

  /// Every category on or off in one step; the lock-screen setting is kept.
  NotificationPrefs withAll(bool on) => NotificationPrefs(
        reminders: on,
        familyInvitations: on,
        activityUpdates: on,
        reminderCompletion: on,
        securityEvents: on,
        showDetailsOnLockScreen: showDetailsOnLockScreen,
      );

  Map<String, dynamic> toMap() => {
        'reminders': reminders,
        'familyInvitations': familyInvitations,
        'activityUpdates': activityUpdates,
        'reminderCompletion': reminderCompletion,
        'securityEvents': securityEvents,
        'showDetailsOnLockScreen': showDetailsOnLockScreen,
      };
}

class PrivacySettings {
  const PrivacySettings({
    this.aiMedicalConsent = false,
    this.aiScamConsent = false,
    this.recordingConsentAcknowledged = false,
    this.updatedAt,
  });
  final bool aiMedicalConsent;
  final bool aiScamConsent;
  final bool recordingConsentAcknowledged;

  /// When these choices were last changed (server time), if known.
  final DateTime? updatedAt;

  PrivacySettings copyWith(
          {bool? aiMedicalConsent,
          bool? aiScamConsent,
          bool? recordingConsentAcknowledged}) =>
      PrivacySettings(
        aiMedicalConsent: aiMedicalConsent ?? this.aiMedicalConsent,
        aiScamConsent: aiScamConsent ?? this.aiScamConsent,
        recordingConsentAcknowledged:
            recordingConsentAcknowledged ?? this.recordingConsentAcknowledged,
      );

  factory PrivacySettings.fromMap(Map<String, dynamic>? m) => PrivacySettings(
        aiMedicalConsent: m?['aiMedicalConsent'] == true,
        aiScamConsent: m?['aiScamConsent'] == true,
        recordingConsentAcknowledged:
            m?['recordingConsentAcknowledged'] == true,
        updatedAt: (m?['updatedAt'] is Timestamp)
            ? (m!['updatedAt'] as Timestamp).toDate()
            : null,
      );

  Map<String, dynamic> toMap() => {
        'aiMedicalConsent': aiMedicalConsent,
        'aiScamConsent': aiScamConsent,
        'recordingConsentAcknowledged': recordingConsentAcknowledged,
      };
}

class AppUser {
  const AppUser({
    required this.uid,
    required this.fullName,
    required this.email,
    this.role = AccountRole.caregiver,
    this.profileImage,
    this.largeText = false,
    this.highContrast = false,
    this.notificationPrefs = const NotificationPrefs(),
    this.privacy = const PrivacySettings(),
    this.createdAt,
    this.termsVersion,
    this.termsAcceptedAt,
  });

  final String uid;
  final String fullName;
  final String email;
  final AccountRole role;
  final String? profileImage;
  final bool largeText;
  final bool highContrast;
  final NotificationPrefs notificationPrefs;
  final PrivacySettings privacy;
  final DateTime? createdAt;

  /// Version of the Terms + Privacy Policy accepted, and when.
  final String? termsVersion;
  final DateTime? termsAcceptedAt;

  String get firstName => fullName.trim().split(RegExp(r'\s+')).first;

  String get initials {
    final parts = fullName
        .trim()
        .split(RegExp(r'\s+'))
        .where((p) => p.isNotEmpty)
        .toList();
    if (parts.isEmpty) return '?';
    if (parts.length == 1) return parts.first[0].toUpperCase();
    return (parts.first[0] + parts.last[0]).toUpperCase();
  }

  factory AppUser.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? const {};
    final a = (d['accessibilitySettings'] as Map?)?.cast<String, dynamic>() ??
        const {};
    final c = (d['consents'] as Map?)?.cast<String, dynamic>() ?? const {};
    return AppUser(
      uid: doc.id,
      fullName: (d['fullName'] as String?) ?? '',
      email: (d['email'] as String?) ?? '',
      role: AccountRoleX.parse(d['role'] as String?),
      profileImage: d['profileImage'] as String?,
      largeText: a['largeText'] == true,
      highContrast: a['highContrast'] == true,
      notificationPrefs: NotificationPrefs.fromMap(
          (d['notificationPrefs'] as Map?)?.cast<String, dynamic>()),
      privacy: PrivacySettings.fromMap(
          (d['privacy'] as Map?)?.cast<String, dynamic>()),
      createdAt: (d['createdAt'] as Timestamp?)?.toDate(),
      termsVersion: c['termsVersion'] as String?,
      termsAcceptedAt: (c['acceptedAt'] is Timestamp)
          ? (c['acceptedAt'] as Timestamp).toDate()
          : null,
    );
  }
}
