import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/config/app_config.dart';
import '../../../core/config/business_info.dart';
import '../../../core/config/legal_versions.dart';
import '../../../core/router/app_router.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/kc_logo.dart';
import '../../../core/widgets/kc_widgets.dart';

/// About & Contact: who runs the app, how to reach them (support and the
/// Grievance Officer required by the DPDP Act), what the app costs (nothing),
/// and links to every legal text. All business details come from
/// lib/core/config/business_info.dart.
class AboutContactScreen extends StatelessWidget {
  const AboutContactScreen({super.key});

  static Future<void> _mail(String to, String subject) =>
      launchUrl(Uri(scheme: 'mailto', path: to, query: 'subject=$subject'));

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    Widget row(String label, String value) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: MergeSemantics(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: text.titleSmall),
                SelectableText(value, style: text.bodyLarge),
              ],
            ),
          ),
        );
    Widget link(IconData icon, String label, VoidCallback onTap) => ListTile(
          leading: Icon(icon),
          title: Text(label),
          trailing: const Icon(Icons.chevron_right),
          onTap: onTap,
        );

    return Scaffold(
      appBar: AppBar(title: const Text('About & contact')),
      body: ListView(
        padding: const EdgeInsets.all(KcSpacing.lg),
        children: [
          if (BusinessInfo.hasPlaceholders) ...[
            const KcNotice(
              tone: KcNoticeTone.warning,
              icon: Icons.construction_outlined,
              text: 'Setup incomplete: the operator has not filled in the '
                  'business details yet (lib/core/config/business_info.dart). '
                  'Do not publish this build.',
            ),
            const SizedBox(height: KcSpacing.md),
          ],
          const Center(child: KcLogo(size: 88)),
          const SizedBox(height: KcSpacing.md),
          Center(
            child: Semantics(
              header: true,
              child: Text(BusinessInfo.appName, style: text.headlineSmall),
            ),
          ),
          const Center(child: Text('Caring Together. Living Safer.')),
          const Center(child: Text('Version ${AppConfig.appVersion}')),
          const SizedBox(height: KcSpacing.lg),
          const KcNotice(
            icon: Icons.volunteer_activism_outlined,
            text: 'Free to use: no ads, no in-app purchases, no subscriptions '
                'and no hidden fees. The cost of AI features is paid by the '
                'operator, never by you.',
          ),
          const SizedBox(height: KcSpacing.md),
          const Text(
              'Kin Care Connect helps families coordinate care: reminders, '
              'emergency contacts, plain-language explanations of medical '
              'information and warning signs of possible scams. Explanations '
              'and scam checks are advisory and can be wrong; they never '
              'replace doctors, pharmacists, your bank or emergency services.'),
          const KcSectionHeader('Who runs this app'),
          KcCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                row('Operator', BusinessInfo.companyName),
                row('Legal entity', BusinessInfo.legalEntity),
                row('Address', BusinessInfo.postalAddress),
                row('Support email', BusinessInfo.supportEmail),
                row('Website', BusinessInfo.website),
              ],
            ),
          ),
          const KcSectionHeader('Grievance Officer'),
          KcCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                    'For complaints about how your personal data is handled '
                    '(Digital Personal Data Protection Act, 2023).'),
                const SizedBox(height: 6),
                row('Name', BusinessInfo.grievanceOfficerName),
                row('Email', BusinessInfo.grievanceOfficerEmail),
                row('Response time', BusinessInfo.grievanceResponseTime),
              ],
            ),
          ),
          const SizedBox(height: KcSpacing.md),
          KcButton(
            label: 'Email support',
            icon: Icons.email_outlined,
            variant: KcButtonVariant.tonal,
            onPressed: () =>
                _mail(BusinessInfo.supportEmail, 'Kin Care Connect help'),
          ),
          const SizedBox(height: KcSpacing.sm),
          KcButton(
            label: 'Email the Grievance Officer',
            icon: Icons.report_outlined,
            variant: KcButtonVariant.outlined,
            onPressed: () => _mail(BusinessInfo.grievanceOfficerEmail,
                'Kin Care Connect grievance'),
          ),
          const KcSectionHeader('Legal'),
          KcCard(
            padding: EdgeInsets.zero,
            child: Column(children: [
              link(Icons.gavel_outlined, 'Terms of Service',
                  () => context.push(Routes.legal('terms'))),
              link(Icons.policy_outlined, 'Privacy Policy',
                  () => context.push(Routes.legal('privacy'))),
              link(Icons.storage_outlined, 'Cookie & Local Storage Policy',
                  () => context.push(Routes.legal('storage'))),
              link(Icons.delete_outline, 'How to delete your account',
                  () => context.push(Routes.legal('deletion'))),
            ]),
          ),
          const SizedBox(height: KcSpacing.md),
          Text(
            'Kin Care Connect is for adults aged ${LegalVersions.minimumAge} '
            'and over. Built with Flutter and Firebase.',
            style: text.bodyMedium,
          ),
          const SizedBox(height: KcSpacing.lg),
        ],
      ),
    );
  }
}
