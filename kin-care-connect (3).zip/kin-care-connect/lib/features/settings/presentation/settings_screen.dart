import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/router/app_router.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../../profile/presentation/profile_screen.dart';

/// Module M.
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Widget item(IconData i, String label, VoidCallback onTap) => ListTile(
        leading: Icon(i),
        title: Text(label),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap);
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(KcSpacing.md),
        children: [
          const KcSectionHeader('Account'),
          KcCard(
            padding: EdgeInsets.zero,
            child: Column(children: [
              item(Icons.edit_outlined, 'Edit profile',
                  () => context.push(Routes.editProfile)),
              item(Icons.lock_outline, 'Change password',
                  () => context.push(Routes.changePassword)),
              item(Icons.download_outlined, 'Data export',
                  () => context.push(Routes.account)),
              item(Icons.delete_outline, 'Delete account',
                  () => context.push(Routes.account)),
            ]),
          ),
          const KcSectionHeader('Preferences'),
          KcCard(
            padding: EdgeInsets.zero,
            child: Column(children: [
              item(Icons.accessibility_new, 'Accessibility',
                  () => context.push(Routes.accessibility)),
              item(Icons.notifications_outlined, 'Notification preferences',
                  () => context.push(Routes.notificationSettings)),
              item(Icons.privacy_tip_outlined, 'Privacy settings',
                  () => context.push(Routes.privacy)),
              item(Icons.fact_check_outlined, 'Privacy choices',
                  () => context.push(Routes.privacyChoicesReview)),
            ]),
          ),
          const KcSectionHeader('About'),
          KcCard(
            padding: EdgeInsets.zero,
            child: Column(children: [
              item(Icons.gavel_outlined, 'Terms of Service',
                  () => context.push(Routes.legal('terms'))),
              item(Icons.policy_outlined, 'Privacy Policy',
                  () => context.push(Routes.legal('privacy'))),
              item(Icons.storage_outlined, 'Cookie & Local Storage Policy',
                  () => context.push(Routes.legal('storage'))),
              item(Icons.help_outline, 'Help and support',
                  () => context.push(Routes.legal('help'))),
              item(Icons.info_outline, 'About & contact',
                  () => context.push(Routes.aboutContact)),
            ]),
          ),
          const SizedBox(height: KcSpacing.lg),
          KcButton(
              label: 'Log out',
              icon: Icons.logout,
              variant: KcButtonVariant.outlined,
              onPressed: () => ProfileScreen.logout(context)),
          const SizedBox(height: KcSpacing.lg),
        ],
      ),
    );
  }
}
