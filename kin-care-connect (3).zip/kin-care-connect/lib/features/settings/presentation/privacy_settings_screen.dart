import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../core/config/business_info.dart';
import '../../../core/router/app_router.dart';
import '../../../core/services/settings_controller.dart';
import '../../../core/utils/formatters.dart';
import '../../../core/services/session_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/kc_dialogs.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../../profile/data/profile_repository.dart';
import '../../profile/domain/app_user.dart';

class PrivacySettingsScreen extends StatelessWidget {
  const PrivacySettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<SessionController>().user;
    if (user == null) return const Scaffold(body: KcLoading());
    final p = user.privacy;
    final settings = context.watch<SettingsController>();
    Future<void> save(PrivacySettings n) => runGuarded(context,
        () => context.read<ProfileRepository>().updatePrivacy(user.uid, n),
        success: 'Privacy settings saved.');

    return Scaffold(
      appBar: AppBar(title: const Text('Privacy settings')),
      body: ListView(
        padding: const EdgeInsets.all(KcSpacing.md),
        children: [
          const KcNotice(
              text:
                  'You are in control. Nothing is sent to AI services or shared with family unless you allow it.'),
          const KcSectionHeader('AI processing'),
          KcCard(
            padding: EdgeInsets.zero,
            child: Column(children: [
              SwitchListTile(
                title: const Text('Medical Translator AI'),
                subtitle: const Text(
                    'Send medical text and recordings to our server and an AI service to explain them'),
                value: p.aiMedicalConsent,
                onChanged: (v) => save(p.copyWith(aiMedicalConsent: v)),
              ),
              SwitchListTile(
                title: const Text('Scam Shield AI'),
                subtitle: const Text(
                    'Allow "Deeper check with AI". Off means checks run only on this phone'),
                value: p.aiScamConsent,
                onChanged: (v) => save(p.copyWith(aiScamConsent: v)),
              ),
            ]),
          ),
          const KcSectionHeader('Notifications on this phone'),
          KcCard(
            padding: EdgeInsets.zero,
            child: ListTile(
              title: Text(settings.notificationsOptIn
                  ? 'You chose to receive notifications'
                  : 'You chose not to receive notifications'),
              subtitle: const Text(
                  'Change which notifications you get, or turn them all off, in Notification preferences.'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => context.push(Routes.notificationSettings),
            ),
          ),
          const KcSectionHeader('Your consent record'),
          KcCard(
            child: Text(
              [
                if (user.termsVersion != null)
                  'Terms of Service and Privacy Policy: version ${user.termsVersion}'
                      '${user.termsAcceptedAt != null ? ', accepted ${Fmt.date(user.termsAcceptedAt!)}' : ''}.',
                if (p.updatedAt != null)
                  'AI choices last changed ${Fmt.date(p.updatedAt!)}.',
                if (settings.privacyChoicesAt != null)
                  'Privacy choices on this phone: notice version ${settings.privacyChoicesVersion}, '
                      'answered ${Fmt.date(settings.privacyChoicesAt!.toLocal())}.',
                'No cookies, advertising IDs or analytics are used.',
              ].join('\n'),
            ),
          ),
          const SizedBox(height: KcSpacing.sm),
          KcButton(
              label: 'Review my privacy choices',
              variant: KcButtonVariant.outlined,
              onPressed: () => context.push(Routes.privacyChoicesReview)),
          const KcSectionHeader('Data retention'),
          const KcCard(
            child: Text(
              '• Audio recordings are deleted automatically after 30 days.\n'
              '• Scam-check results (never the message text) are kept for 180 days.\n'
              '• Notifications are kept for 90 days.\n'
              '• Medical summaries and reminders stay until you delete them or your account.',
            ),
          ),
          const KcSectionHeader('Family sharing'),
          const KcCard(
              child: Text(
                  'What your family can see is controlled per care profile in Family › your profile › Sharing approvals.')),
          const SizedBox(height: KcSpacing.md),
          KcButton(
              label: 'Export or delete my data',
              variant: KcButtonVariant.tonal,
              onPressed: () => context.push(Routes.account)),
          const SizedBox(height: KcSpacing.sm),
          const SizedBox(height: KcSpacing.sm),
          const Text(
              'Can\'t use the app? Email ${BusinessInfo.supportEmail} from your '
              'account\'s email address to ask for a copy or deletion of your data.'),
          TextButton(
              onPressed: () => context.push(Routes.legal('privacy')),
              child: const Text('Read the Privacy Policy')),
          TextButton(
              onPressed: () => context.push(Routes.legal('storage')),
              child: const Text('Read the Cookie & Local Storage Policy')),
        ],
      ),
    );
  }
}
