import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/services/session_controller.dart';
import '../../../core/services/settings_controller.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../../profile/data/profile_repository.dart';

class AccessibilitySettingsScreen extends StatelessWidget {
  const AccessibilitySettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsController>();
    final uid = context.watch<SessionController>().uid;

    Future<void> sync() async {
      if (uid == null) return;
      try {
        await context.read<ProfileRepository>().updateAccessibility(uid,
            largeText: settings.largeText, highContrast: settings.highContrast);
      } catch (_) {
        // Device setting still applies even if sync fails.
      }
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Accessibility')),
      body: ListView(
        padding: const EdgeInsets.all(KcSpacing.md),
        children: [
          KcCard(
            padding: EdgeInsets.zero,
            child: Column(children: [
              SwitchListTile(
                title: const Text('Large text'),
                subtitle: const Text('Makes all text about 30% bigger'),
                value: settings.largeText,
                onChanged: (v) async {
                  await settings.setLargeText(v);
                  await sync();
                },
              ),
              SwitchListTile(
                title: const Text('High contrast'),
                subtitle: const Text('Stronger colours and outlines'),
                value: settings.highContrast,
                onChanged: (v) async {
                  await settings.setHighContrast(v);
                  await sync();
                },
              ),
            ]),
          ),
          const KcSectionHeader('Theme'),
          KcCard(
            child: SegmentedButton<ThemeMode>(
              segments: const [
                ButtonSegment(
                    value: ThemeMode.system,
                    icon: Icon(Icons.brightness_auto),
                    label: Text('System')),
                ButtonSegment(
                    value: ThemeMode.light,
                    icon: Icon(Icons.light_mode),
                    label: Text('Light')),
                ButtonSegment(
                    value: ThemeMode.dark,
                    icon: Icon(Icons.dark_mode),
                    label: Text('Dark')),
              ],
              selected: {settings.themeMode},
              onSelectionChanged: (s) => settings.setThemeMode(s.first),
            ),
          ),
          const SizedBox(height: KcSpacing.md),
          KcCard(
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Preview', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              const Text(
                  'This is how text will look across the app. Buttons are large and easy to tap.'),
            ]),
          ),
          const SizedBox(height: KcSpacing.md),
          const Text(
              'Kin Care Connect also follows your phone\'s font size and TalkBack screen reader settings.'),
        ],
      ),
    );
  }
}
