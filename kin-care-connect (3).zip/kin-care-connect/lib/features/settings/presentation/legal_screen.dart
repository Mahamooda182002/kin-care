import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/config/business_info.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/kc_widgets.dart';
import '../../legal/legal_texts.dart';
import 'about_contact_screen.dart';

/// Terms of Service, Privacy Policy, Cookie & Local Storage Policy, account
/// deletion, help, and About & Contact.
///
/// The legal texts live in lib/features/legal/legal_texts.dart (TEMPLATE —
/// needs lawyer review) and read business details from
/// lib/core/config/business_info.dart. The same texts are exported to
/// docs/legal/*.md.
class LegalScreen extends StatelessWidget {
  const LegalScreen({super.key, required this.doc});
  final String doc;

  @override
  Widget build(BuildContext context) {
    if (doc == 'about') return const AboutContactScreen();
    if (doc == 'help') return const _HelpScreen();
    final d = legalDocById(doc) ?? privacyPolicy;
    final text = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(title: Text(d.title)),
      body: SelectionArea(
        child: ListView(
          padding: const EdgeInsets.all(KcSpacing.lg),
          children: [
            const KcNotice(
                text: LegalDoc.templateNotice,
                tone: KcNoticeTone.warning,
                icon: Icons.gavel_outlined),
            const SizedBox(height: KcSpacing.md),
            Text(d.lastUpdatedLine, style: text.bodyMedium),
            for (final s in d.sections) ...[
              const SizedBox(height: KcSpacing.lg),
              Semantics(
                header: true,
                child: Text(s.heading, style: text.titleLarge),
              ),
              const SizedBox(height: KcSpacing.sm),
              Text(s.body, style: text.bodyLarge),
            ],
            const SizedBox(height: KcSpacing.xl),
          ],
        ),
      ),
    );
  }
}

class _HelpScreen extends StatelessWidget {
  const _HelpScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Help and support')),
      body: ListView(
        padding: const EdgeInsets.all(KcSpacing.lg),
        children: [
          SelectableText(_help, style: Theme.of(context).textTheme.bodyLarge),
          const SizedBox(height: KcSpacing.lg),
          KcButton(
            label: 'Email support',
            icon: Icons.email_outlined,
            onPressed: () => launchUrl(Uri(
                scheme: 'mailto',
                path: BusinessInfo.supportEmail,
                query: 'subject=Kin Care Connect help')),
          ),
        ],
      ),
    );
  }
}

const _help = '''Getting started
1. Create a family group from the Family tab.
2. Add a care profile for the person you look after.
3. Invite relatives by email and choose their permission level.
4. Add reminders and emergency contacts.

Medical Translator
Type or paste medical words or doctor instructions, then tap "Explain in simple words". You can also record a conversation (with everyone's agreement), check the transcript and then summarise it. Explanations can contain mistakes; always check with your doctor or pharmacist.

Scam Shield
Paste a message. The basic check runs on your phone. A deeper AI check is optional. Both look for warning signs and can be wrong.

Routine Monitor
Only records while the app is open and monitoring is on. It is not a fall or emergency detector.

Cost
The app is free. There are no ads, in-app purchases or fees.

Need more help? Email us using the button below.''';
