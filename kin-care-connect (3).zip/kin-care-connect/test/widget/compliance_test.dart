import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:go_router/go_router.dart';
import 'package:kin_care_connect/core/config/business_info.dart';
import 'package:kin_care_connect/core/config/legal_versions.dart';
import 'package:kin_care_connect/core/services/settings_controller.dart';
import 'package:kin_care_connect/core/theme/app_theme.dart';
import 'package:kin_care_connect/features/auth/data/auth_repository.dart';
import 'package:kin_care_connect/features/auth/presentation/register_screen.dart';
import 'package:kin_care_connect/features/privacy/privacy_choices_screen.dart';
import 'package:kin_care_connect/features/settings/presentation/about_contact_screen.dart';
import 'package:kin_care_connect/features/settings/presentation/legal_screen.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../helpers/fakes.dart';

/// Minimal router so screens can navigate in tests.
Widget _app(Widget home,
    {required SettingsController settings,
    AuthRepository? auth,
    ThemeData? theme}) {
  final router = GoRouter(routes: [
    GoRoute(path: '/', builder: (_, __) => home),
    for (final p in ['/onboarding', '/login', '/home'])
      GoRoute(path: p, builder: (_, __) => Scaffold(body: Text('PAGE $p'))),
    GoRoute(
        path: '/settings/legal/:doc',
        builder: (_, s) => LegalScreen(doc: s.pathParameters['doc']!)),
  ]);
  return MultiProvider(
    providers: [
      ChangeNotifierProvider<SettingsController>.value(value: settings),
      if (auth != null) Provider<AuthRepository>.value(value: auth),
    ],
    child: MaterialApp.router(
        theme: theme ?? AppTheme.light(), routerConfig: router),
  );
}

Future<SettingsController> _settings(
    [Map<String, Object> init = const {}]) async {
  SharedPreferences.setMockInitialValues(init);
  return SettingsController(await SharedPreferences.getInstance());
}

/// A tall phone-shaped view so whole screens are built (ListView is lazy).
void _tall(WidgetTester tester) {
  tester.view.physicalSize = const Size(1080, 4200);
  tester.view.devicePixelRatio = 1.5;
  addTearDown(tester.view.reset);
}

final _createButton = find.descendant(
    of: find.byType(FilledButton), matching: find.text('Create account'));

void main() {
  group('Privacy choices (first run)', () {
    testWidgets('nothing is pre-ticked', (tester) async {
      final s = await _settings();
      expect(s.needsPrivacyChoices, isTrue);
      await tester.pumpWidget(_app(const PrivacyChoicesScreen(), settings: s));
      final boxes = tester
          .widgetList<CheckboxListTile>(find.byType(CheckboxListTile))
          .toList();
      expect(boxes, hasLength(2));
      expect(boxes.every((b) => b.value == false), isTrue);
      expect(find.text('Your privacy choices'), findsOneWidget);
      // Not a fake cookie banner: the app says it uses no cookies.
      expect(find.textContaining('no cookies'), findsOneWidget);
    });

    testWidgets('Accept all and Decline all have equal weight', (tester) async {
      _tall(tester);
      final s = await _settings();
      await tester.pumpWidget(_app(const PrivacyChoicesScreen(), settings: s));
      final accept = tester.getSize(find.byKey(const Key('acceptAll')));
      final decline = tester.getSize(find.byKey(const Key('declineAll')));
      expect(accept, decline);
      expect(accept.height, greaterThanOrEqualTo(48));
      // Same button type for both.
      expect(
          find.descendant(
              of: find.byKey(const Key('acceptAll')),
              matching: find.byType(FilledButton)),
          findsOneWidget);
      expect(
          find.descendant(
              of: find.byKey(const Key('declineAll')),
              matching: find.byType(FilledButton)),
          findsOneWidget);
    });

    testWidgets('Decline all stores the answer with version and timestamp',
        (tester) async {
      _tall(tester);
      final s = await _settings();
      s.now = () => DateTime.utc(2026, 11, 3, 7);
      await tester.pumpWidget(_app(const PrivacyChoicesScreen(), settings: s));
      await tester.tap(find.byKey(const Key('declineAll')));
      await tester.pumpAndSettle();
      expect(s.needsPrivacyChoices, isFalse);
      expect(s.privacyChoicesVersion, LegalVersions.privacyChoices);
      expect(s.privacyChoicesAt, DateTime.utc(2026, 11, 3, 7));
      expect(s.notificationsOptIn, isFalse);
      expect(s.aiOptIn, isFalse);
      // First run continues to onboarding.
      expect(find.text('PAGE /onboarding'), findsOneWidget);
    });

    testWidgets('individual choices can be saved', (tester) async {
      _tall(tester);
      final s = await _settings({'onboardingComplete': true});
      await tester.pumpWidget(_app(const PrivacyChoicesScreen(), settings: s));
      await tester.tap(find.byKey(const Key('choiceNotifications')));
      await tester.pump();
      await tester.ensureVisible(find.byKey(const Key('saveChoices')));
      await tester.tap(find.byKey(const Key('saveChoices')));
      await tester.pumpAndSettle();
      expect(s.notificationsOptIn, isTrue);
      expect(s.aiOptIn, isFalse);
      expect(s.privacyChoicesRecord['version'], LegalVersions.privacyChoices);
      expect(find.text('PAGE /login'), findsOneWidget);
    });

    testWidgets('meets tap-target, label and text-contrast guidelines',
        (tester) async {
      final handle = tester.ensureSemantics();
      _tall(tester);
      final s = await _settings();
      await tester.pumpWidget(_app(const PrivacyChoicesScreen(), settings: s));
      await expectLater(tester, meetsGuideline(androidTapTargetGuideline));
      await expectLater(tester, meetsGuideline(labeledTapTargetGuideline));
      await expectLater(tester, meetsGuideline(textContrastGuideline));
      handle.dispose();
    });

    testWidgets('keyboard / D-pad: Tab reaches both choices and buttons',
        (tester) async {
      _tall(tester);
      final s = await _settings();
      await tester.pumpWidget(_app(const PrivacyChoicesScreen(), settings: s));
      final reached = <String>{};
      for (var i = 0; i < 20; i++) {
        await tester.sendKeyEvent(LogicalKeyboardKey.tab);
        await tester.pump();
        final focus = FocusManager.instance.primaryFocus?.context;
        if (focus == null) continue;
        for (final k in [
          'choiceNotifications',
          'choiceAi',
          'declineAll',
          'acceptAll',
          'saveChoices'
        ]) {
          final f = find.byKey(Key(k));
          if (f.evaluate().isEmpty) continue;
          final el = f.evaluate().first;
          var found = false;
          focus.visitAncestorElements((a) {
            if (a == el) found = true;
            return !found;
          });
          if (found) reached.add(k);
        }
      }
      expect(
          reached,
          containsAll(<String>[
            'choiceNotifications',
            'choiceAi',
            'declineAll',
            'acceptAll',
          ]));
    });
  });

  group('Registration consent and age gate', () {
    Future<FakeAuthRepository> pumpRegister(WidgetTester tester) async {
      _tall(tester);
      final s = await _settings();
      await s.savePrivacyChoices(notifications: false, ai: true);
      final auth = FakeAuthRepository();
      await tester
          .pumpWidget(_app(const RegisterScreen(), settings: s, auth: auth));
      return auth;
    }

    Future<void> fillValidForm(WidgetTester tester) async {
      final fields = find.byType(TextFormField);
      await tester.enterText(fields.at(0), 'Asha Rao');
      await tester.enterText(fields.at(1), 'asha@example.com');
      await tester.enterText(fields.at(2), 'goodpass1');
      await tester.enterText(fields.at(3), 'goodpass1');
    }

    testWidgets('no phone field; both checkboxes start unticked',
        (tester) async {
      await pumpRegister(tester);
      expect(find.textContaining('Phone'), findsNothing);
      final age =
          tester.widget<CheckboxListTile>(find.byKey(const Key('ageCheckbox')));
      final terms = tester
          .widget<CheckboxListTile>(find.byKey(const Key('termsCheckbox')));
      expect(age.value, isFalse);
      expect(terms.value, isFalse);
      expect(find.textContaining('no in-app purchases'), findsOneWidget);
    });

    testWidgets('blocks sign-up without the 18+ confirmation', (tester) async {
      final auth = await pumpRegister(tester);
      await fillValidForm(tester);
      await tester.tap(find.byKey(const Key('termsCheckbox')));
      await tester.tap(_createButton);
      await tester.pumpAndSettle();
      expect(auth.lastRegister, isNull);
      expect(find.textContaining('18 or older'), findsOneWidget);
    });

    testWidgets('blocks sign-up without accepting Terms + Privacy',
        (tester) async {
      final auth = await pumpRegister(tester);
      await fillValidForm(tester);
      await tester.tap(find.byKey(const Key('ageCheckbox')));
      await tester.tap(_createButton);
      await tester.pumpAndSettle();
      expect(auth.lastRegister, isNull);
      expect(find.textContaining('Terms of Service and Privacy Policy to'),
          findsOneWidget);
    });

    testWidgets('registers with both consents and the privacy choices',
        (tester) async {
      final auth = await pumpRegister(tester);
      await fillValidForm(tester);
      await tester.tap(find.byKey(const Key('ageCheckbox')));
      await tester.tap(find.byKey(const Key('termsCheckbox')));
      await tester.tap(_createButton);
      await tester.pumpAndSettle();
      final r = auth.lastRegister!;
      expect(r['acceptedTerms'], isTrue);
      expect(r['confirmedAdult'], isTrue);
      expect(r['aiOptIn'], isTrue);
      expect(r['notificationsOptIn'], isFalse);
      expect((r['privacyChoices'] as Map)['version'],
          LegalVersions.privacyChoices);
    });

    testWidgets('under-18 path shows a respectful message and clears input',
        (tester) async {
      final auth = await pumpRegister(tester);
      await fillValidForm(tester);
      await tester.tap(find.text('I am under 18'));
      await tester.pumpAndSettle();
      expect(find.text('Kin Care Connect is for adults'), findsOneWidget);
      expect(find.textContaining('Nothing you typed has been saved'),
          findsOneWidget);
      await tester.tap(find.text('OK'));
      await tester.pumpAndSettle();
      expect(find.text('asha@example.com'), findsNothing);
      expect(auth.lastRegister, isNull);
    });

    testWidgets('register form meets tap-target and label guidelines',
        (tester) async {
      final handle = tester.ensureSemantics();
      await pumpRegister(tester);
      await expectLater(tester, meetsGuideline(androidTapTargetGuideline));
      await expectLater(tester, meetsGuideline(labeledTapTargetGuideline));
      handle.dispose();
    });
  });

  group('Legal and About screens', () {
    testWidgets('privacy policy shows template notice and header semantics',
        (tester) async {
      final handle = tester.ensureSemantics();
      final s = await _settings();
      await tester
          .pumpWidget(_app(const LegalScreen(doc: 'privacy'), settings: s));
      expect(find.textContaining('Template — needs lawyer review'),
          findsOneWidget);
      expect(find.text('Who we are'), findsOneWidget);
      expect(tester.getSemantics(find.text('Who we are')),
          isSemantics(label: 'Who we are', isHeader: true));
      handle.dispose();
    });

    testWidgets('storage policy and deletion page render', (tester) async {
      final s = await _settings();
      await tester
          .pumpWidget(_app(const LegalScreen(doc: 'storage'), settings: s));
      expect(find.text('Cookie & Local Storage Policy'), findsOneWidget);
      await tester
          .pumpWidget(_app(const LegalScreen(doc: 'deletion'), settings: s));
      expect(find.text('Without the app'), findsOneWidget);
    });

    testWidgets('About & contact reads business_info and flags placeholders',
        (tester) async {
      _tall(tester);
      final s = await _settings();
      await tester.pumpWidget(_app(const AboutContactScreen(), settings: s));
      expect(find.text(BusinessInfo.companyName), findsOneWidget);
      expect(find.text(BusinessInfo.grievanceOfficerEmail), findsOneWidget);
      expect(find.textContaining('no in-app purchases'), findsOneWidget);
      expect(BusinessInfo.hasPlaceholders, isTrue);
      expect(find.textContaining('Setup incomplete'), findsOneWidget);
    });
  });

  testWidgets('high-contrast theme passes the text-contrast guideline',
      (tester) async {
    final handle = tester.ensureSemantics();
    final s = await _settings();
    await tester.pumpWidget(_app(const PrivacyChoicesScreen(),
        settings: s, theme: AppTheme.highContrastLight()));
    await expectLater(tester, meetsGuideline(textContrastGuideline));
    await tester.pumpWidget(_app(const PrivacyChoicesScreen(),
        settings: s, theme: AppTheme.highContrastDark()));
    await tester.pumpAndSettle();
    await expectLater(tester, meetsGuideline(textContrastGuideline));
    handle.dispose();
  });
}
