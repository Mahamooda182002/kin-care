import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:go_router/go_router.dart';
import 'package:kin_care_connect/core/services/settings_controller.dart';
import 'package:kin_care_connect/core/theme/app_theme.dart';
import 'package:kin_care_connect/core/widgets/kc_widgets.dart';
import 'package:kin_care_connect/features/auth/data/auth_repository.dart';
import 'package:kin_care_connect/features/auth/presentation/login_screen.dart';
import 'package:kin_care_connect/features/onboarding/onboarding_screen.dart';
import 'package:provider/provider.dart';
import 'package:provider/single_child_widget.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../helpers/fakes.dart';

Widget _routerApp(Widget home, {List<SingleChildWidget> providers = const []}) {
  final router = GoRouter(routes: [
    GoRoute(path: '/', builder: (_, __) => home),
    GoRoute(
        path: '/register',
        builder: (_, __) => const Scaffold(body: Text('REGISTER PAGE'))),
    GoRoute(
        path: '/forgot-password',
        builder: (_, __) => const Scaffold(body: Text('FORGOT PAGE'))),
  ]);
  final app = MaterialApp.router(theme: AppTheme.light(), routerConfig: router);
  return providers.isEmpty
      ? app
      : MultiProvider(providers: providers, child: app);
}

void main() {
  testWidgets('KcButton shows a spinner and is disabled while loading',
      (tester) async {
    var taps = 0;
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
          body:
              KcButton(label: 'Save', loading: true, onPressed: () => taps++)),
    ));
    expect(find.byType(CircularProgressIndicator), findsOneWidget);
    await tester.tap(find.byType(KcButton));
    expect(taps, 0);
  });

  testWidgets('KcButton fires when not loading and exposes semantics',
      (tester) async {
    var taps = 0;
    await tester.pumpWidget(MaterialApp(
        home:
            Scaffold(body: KcButton(label: 'Save', onPressed: () => taps++))));
    await tester.tap(find.text('Save'));
    expect(taps, 1);
    expect(find.bySemanticsLabel('Save'), findsOneWidget);
  });

  testWidgets('Onboarding: next through 3 pages, then Get Started',
      (tester) async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final settings = SettingsController(prefs);
    await tester.pumpWidget(ChangeNotifierProvider.value(
        value: settings, child: _routerApp(const OnboardingScreen())));
    expect(find.text('Family Care'), findsOneWidget);
    expect(find.text('Skip'), findsOneWidget);
    await tester.tap(find.text('Next'));
    await tester.pumpAndSettle();
    expect(find.text('Medical Understanding'), findsOneWidget);
    await tester.tap(find.text('Next'));
    await tester.pumpAndSettle();
    expect(find.text('Scam Warnings'), findsOneWidget);
    expect(find.text('Get Started'), findsOneWidget);
    await tester.tap(find.text('Get Started'));
    await tester.pumpAndSettle();
    expect(settings.onboardingComplete, isTrue);
    expect(find.text('REGISTER PAGE'), findsOneWidget);
  });

  testWidgets('Login validates fields before calling the repository',
      (tester) async {
    final auth = FakeAuthRepository();
    await tester.pumpWidget(Provider<AuthRepository>.value(
        value: auth, child: _routerApp(const LoginScreen())));
    await tester.tap(find.text('Sign in'));
    await tester.pump();
    expect(find.text('Email is required.'), findsOneWidget);
    expect(find.text('Password is required.'), findsOneWidget);
    expect(auth.lastEmail, isNull);
  });

  testWidgets('Login shows a clear error message on failure', (tester) async {
    final auth = FakeAuthRepository()..failSignIn = true;
    await tester.pumpWidget(Provider<AuthRepository>.value(
        value: auth, child: _routerApp(const LoginScreen())));
    await tester.enterText(
        find.byType(TextFormField).at(0), 'maha@example.com');
    await tester.enterText(find.byType(TextFormField).at(1), 'goodpass1');
    await tester.tap(find.text('Sign in'));
    await tester.pumpAndSettle();
    expect(auth.lastEmail, 'maha@example.com');
    expect(find.text('Email or password is incorrect.'), findsOneWidget);
  });

  testWidgets('Large text setting scales text', (tester) async {
    SharedPreferences.setMockInitialValues({'largeText': true});
    final settings = SettingsController(await SharedPreferences.getInstance());
    expect(settings.textScaleFactor, greaterThan(1.0));
  });
}
