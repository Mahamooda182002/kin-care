import 'dart:async';

import 'package:kin_care_connect/core/utils/app_exception.dart';
import 'package:kin_care_connect/features/auth/data/auth_repository.dart';

class FakeAuthRepository implements AuthRepository {
  String? lastEmail;
  bool failSignIn = false;
  final _ctrl = StreamController<String?>.broadcast();

  @override
  Stream<String?> authStateChanges() => _ctrl.stream;
  @override
  String? get currentUid => null;
  @override
  String? get currentEmail => null;
  @override
  bool get emailVerified => false;

  @override
  Future<void> signIn({required String email, required String password}) async {
    lastEmail = email;
    if (failSignIn) throw const AppException('Email or password is incorrect.');
  }

  /// Arguments of the last register() call, or null if never called.
  Map<String, Object?>? lastRegister;

  @override
  Future<void> register({
    required String fullName,
    required String email,
    required String password,
    required bool acceptedTerms,
    required bool confirmedAdult,
    bool aiOptIn = false,
    bool notificationsOptIn = false,
    Map<String, Object?>? privacyChoices,
  }) async {
    lastRegister = {
      'fullName': fullName,
      'email': email,
      'acceptedTerms': acceptedTerms,
      'confirmedAdult': confirmedAdult,
      'aiOptIn': aiOptIn,
      'notificationsOptIn': notificationsOptIn,
      'privacyChoices': privacyChoices,
    };
  }

  @override
  Future<void> sendPasswordReset(String email) async {}
  @override
  Future<void> confirmPasswordReset(
      {required String code, required String newPassword}) async {}
  @override
  Future<void> changePassword(
      {required String currentPassword, required String newPassword}) async {}
  @override
  Future<void> reauthenticate(String password) async {}
  @override
  Future<void> sendEmailVerification() async {}
  @override
  Future<bool> reloadAndCheckVerified() async => false;
  @override
  Future<void> signOut() async {}
}
