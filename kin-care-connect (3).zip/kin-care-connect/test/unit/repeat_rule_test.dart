import 'package:flutter_test/flutter_test.dart';
import 'package:kin_care_connect/features/reminders/domain/repeat_rule.dart';

void main() {
  final start = DateTime(2026, 11, 3, 8, 0); // Tuesday 08:00

  test('non-repeating returns null', () {
    expect(RepeatRule.none.nextAfter(start, start), isNull);
  });

  test('daily advances to the next day at the same time', () {
    const r = RepeatRule(frequency: RepeatFrequency.daily);
    expect(r.nextAfter(start, start), DateTime(2026, 11, 4, 8, 0));
    expect(r.nextAfter(start, DateTime(2026, 11, 10, 9, 0)),
        DateTime(2026, 11, 11, 8, 0));
  });

  test('every 2 days keeps alignment', () {
    const r = RepeatRule(frequency: RepeatFrequency.daily, interval: 2);
    expect(r.nextAfter(start, DateTime(2026, 11, 4, 7, 0)),
        DateTime(2026, 11, 5, 8, 0));
  });

  test('before start returns start', () {
    const r = RepeatRule(frequency: RepeatFrequency.daily);
    expect(r.nextAfter(start, DateTime(2026, 11, 1)), start);
  });

  test('weekly on Mon/Thu', () {
    const r = RepeatRule(frequency: RepeatFrequency.weekly, weekdays: [1, 4]);
    expect(r.nextAfter(start, start), DateTime(2026, 11, 5, 8, 0)); // Thu
    expect(r.nextAfter(start, DateTime(2026, 11, 5, 8, 0)),
        DateTime(2026, 11, 9, 8, 0)); // Mon
  });

  test('weekly with no days uses the start weekday', () {
    const r = RepeatRule(frequency: RepeatFrequency.weekly);
    expect(r.nextAfter(start, start), DateTime(2026, 11, 10, 8, 0));
  });

  test('every 2 weeks skips the off week', () {
    const r = RepeatRule(frequency: RepeatFrequency.weekly, interval: 2);
    expect(r.nextAfter(start, start), DateTime(2026, 11, 17, 8, 0));
  });

  test('monthly clamps to the end of short months', () {
    final jan31 = DateTime(2027, 1, 31, 9, 0);
    const r = RepeatRule(frequency: RepeatFrequency.monthly);
    expect(r.nextAfter(jan31, jan31), DateTime(2027, 2, 28, 9, 0));
  });

  test('round-trips through a map', () {
    const r = RepeatRule(
        frequency: RepeatFrequency.weekly, interval: 3, weekdays: [2, 5]);
    final back = RepeatRule.fromMap(r.toMap());
    expect(back.frequency, RepeatFrequency.weekly);
    expect(back.interval, 3);
    expect(back.weekdays, [2, 5]);
    expect(back.describe(), 'Every 3 weeks on Tue, Fri');
  });
}
