import 'package:flutter_test/flutter_test.dart';
import 'package:kin_care_connect/features/scam/domain/scam_rules.dart';

void main() {
  test('classic bank OTP scam is HIGH risk', () {
    final r = ScamRules.analyze(
      'URGENT: Your SBI account will be blocked today. Share the OTP sent to your phone '
      'immediately to verify KYC: http://sbi-kyc-update.xyz/login',
    );
    expect(r.riskLevel, RiskLevel.high);
    final ids = r.indicators.map((i) => i.id).toSet();
    expect(
        ids, containsAll(['credentials', 'urgency', 'threat', 'risky_link']));
    expect(r.urls, isNotEmpty);
    expect(r.recommendedAction, contains('Do not'));
  });

  test('gift card payment request is flagged', () {
    final r = ScamRules.analyze(
        'Hi Mum, new number. I lost my phone. Can you buy Google Play cards and send me the codes? Do not tell dad.');
    expect(r.riskLevel, RiskLevel.high);
    expect(r.indicators.map((i) => i.id),
        containsAll(['payment', 'impersonation', 'secrecy']));
  });

  test('ordinary message is LOW but never declared safe', () {
    final r = ScamRules.analyze(
        'See you at lunch on Sunday. I will bring the mangoes.');
    expect(r.riskLevel, RiskLevel.low);
    expect(r.indicators, isEmpty);
    expect(r.explanation.toLowerCase(),
        contains('does not mean the message is safe'));
  });

  test('plain link is MEDIUM-ish but noted, never opened', () {
    final r =
        ScamRules.analyze('Your parcel is waiting, track here bit.ly/abc123');
    expect(r.indicators.any((i) => i.id == 'risky_link'), isTrue);
    expect(r.riskLevel, isNot(RiskLevel.low));
  });

  test('remote access request is flagged', () {
    final r = ScamRules.analyze(
        'This is Microsoft support. Please install AnyDesk so we can fix your computer.');
    expect(r.indicators.map((i) => i.id), contains('remote_access'));
  });

  test('extractUrls finds links without opening them', () {
    expect(ScamRules.extractUrls('go to https://example.com/x and www.test.in'),
        hasLength(2));
  });

  test('disclaimer never guarantees safety', () {
    expect(ScamAnalysis.disclaimer.toLowerCase(), contains('cannot guarantee'));
  });
}
