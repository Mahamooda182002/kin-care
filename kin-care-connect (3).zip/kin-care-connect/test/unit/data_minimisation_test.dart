import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:kin_care_connect/core/config/legal_versions.dart';
import 'package:kin_care_connect/features/auth/data/auth_repository.dart';
import 'package:kin_care_connect/features/profile/domain/app_user.dart';

void main() {
  const ts = 'SERVER_TIMESTAMP';
  Map<String, Object?> doc({bool ai = false, bool notif = false}) =>
      FirebaseAuthRepository.newUserDoc(
        uid: 'u1',
        fullName: ' Asha Rao ',
        email: 'Asha@Example.com ',
        timestamp: ts,
        aiOptIn: ai,
        notificationsOptIn: notif,
        privacyChoices: const {
          'version': LegalVersions.privacyChoices,
          'decidedAt': '2026-11-03T07:00:00.000Z',
          'notifications': false,
          'ai': false,
        },
      );

  test('new user document has no phone, password or date of birth', () {
    final d = doc();
    for (final k in ['phone', 'password', 'dob', 'dateOfBirth']) {
      expect(d.containsKey(k), isFalse, reason: k);
    }
    expect(d['email'], 'asha@example.com');
    expect(d['fullName'], 'Asha Rao');
  });

  test('records consent version, timestamp and 18+ confirmation', () {
    final c = doc()['consents'] as Map;
    expect(c['termsVersion'], LegalVersions.terms);
    expect(c['privacyVersion'], LegalVersions.privacy);
    expect(c['acceptedAt'], ts);
    expect(c['ageConfirmed'], isTrue);
    expect(c['minimumAge'], 18);
    expect(
        (c['privacyChoices'] as Map)['version'], LegalVersions.privacyChoices);
  });

  test('AI is off and notifications are off unless the user opted in', () {
    final off = doc();
    final p = off['privacy'] as Map;
    expect(p['aiMedicalConsent'], isFalse);
    expect(p['aiScamConsent'], isFalse);
    expect(p['updatedAt'], ts);
    final n = off['notificationPrefs'] as Map;
    expect(n.values.every((v) => v == false), isTrue);

    final on = doc(ai: true, notif: true);
    expect((on['privacy'] as Map)['aiMedicalConsent'], isTrue);
    final n2 = on['notificationPrefs'] as Map;
    expect(n2['reminders'], isTrue);
    // Lock-screen details are never on by default.
    expect(n2['showDetailsOnLockScreen'], isFalse);
  });

  test('user document keys are exactly those the Firestore rules allow', () {
    final rules = File('firestore.rules').readAsStringSync();
    final m = RegExp(r'function userKeys\(\) \{\s*return \[([^\]]*)\]')
        .firstMatch(rules);
    expect(m, isNotNull, reason: 'userKeys() not found in firestore.rules');
    final allowed = RegExp(r"'(\w+)'")
        .allMatches(m!.group(1)!)
        .map((x) => x.group(1))
        .toSet();
    expect(allowed.containsAll(doc().keys), isTrue,
        reason: 'rules allow $allowed, doc has ${doc().keys}');
    expect(allowed.contains('phone'), isFalse);
  });

  test('"turn off all notifications" switches every category off', () {
    const p = NotificationPrefs(showDetailsOnLockScreen: true);
    expect(p.allOff, isFalse);
    final off = p.withAll(false);
    expect(off.allOff, isTrue);
    expect(off.showDetailsOnLockScreen, isTrue);
    expect(off.withAll(true).allOff, isFalse);
  });
}
