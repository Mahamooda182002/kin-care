import 'package:flutter_test/flutter_test.dart';
import 'package:kin_care_connect/core/utils/validators.dart';

void main() {
  group('email', () {
    test('accepts valid addresses', () {
      expect(Validators.email('maha@example.com'), isNull);
      expect(Validators.email(' a.b+c@sub.example.co.in '), isNull);
    });
    test('rejects invalid addresses', () {
      expect(Validators.email(''), isNotNull);
      expect(Validators.email('no-at-sign'), isNotNull);
      expect(Validators.email('a@b'), isNotNull);
    });
  });

  group('password', () {
    test('requires 8+ chars with letter and number', () {
      expect(Validators.password('short1'), isNotNull);
      expect(Validators.password('onlyletters'), isNotNull);
      expect(Validators.password('12345678'), isNotNull);
      expect(Validators.password('goodpass1'), isNull);
    });
    test('confirm must match', () {
      expect(
          Validators.confirmPassword('abc', 'abd'), 'Passwords do not match.');
      expect(Validators.confirmPassword('abc', 'abc'), isNull);
    });
  });

  group('phone', () {
    test('optional phone allows empty',
        () => expect(Validators.optionalPhone(''), isNull));
    test('validates digits', () {
      expect(Validators.phone('+91 98765 43210'), isNull);
      expect(Validators.phone('12'), isNotNull);
      expect(Validators.phone('call me'), isNotNull);
    });
  });

  test('full name', () {
    expect(Validators.fullName('M'), isNotNull);
    expect(Validators.fullName('Mahamooda Zahra'), isNull);
  });
}
