import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:kin_care_connect/core/theme/app_theme.dart';
import 'package:kin_care_connect/core/theme/contrast.dart';

/// WCAG 2.x contrast checks for the text colour pairs the theme actually
/// uses, in the light, dark and both high-contrast variants. Normal text
/// needs ≥ 4.5:1 (AA); the high-contrast variants are held to ≥ 7:1 (AAA)
/// for body text.
void main() {
  test('contrast ratio maths matches WCAG reference values', () {
    expect(contrastRatio(Colors.black, Colors.white), closeTo(21, 0.01));
    expect(contrastRatio(Colors.white, Colors.white), closeTo(1, 0.001));
    // #767676 on white is the classic 4.54:1 reference.
    expect(contrastRatio(const Color(0xFF767676), Colors.white),
        closeTo(4.54, 0.01));
  });

  final variants = <String, (Brightness, bool)>{
    'light': (Brightness.light, false),
    'dark': (Brightness.dark, false),
    'high-contrast light': (Brightness.light, true),
    'high-contrast dark': (Brightness.dark, true),
  };

  for (final MapEntry(key: name, value: (b, hc)) in variants.entries) {
    group('$name theme', () {
      final s = AppTheme.scheme(b, highContrast: hc);
      final scaffold = AppTheme.scaffoldColor(b, highContrast: hc);
      final ink = AppTheme.textColor(b, highContrast: hc);
      final pairs = <String, (Color, Color)>{
        'body text on scaffold': (ink, scaffold),
        'body text on cards (surface)': (ink, s.surface),
        'onSurface / surface': (s.onSurface, s.surface),
        'onSurfaceVariant / surface (subtitles)': (
          s.onSurfaceVariant,
          s.surface
        ),
        'onPrimary / primary (filled buttons)': (s.onPrimary, s.primary),
        'primary / surface (text buttons, links)': (s.primary, s.surface),
        'primary / scaffold (text buttons on page)': (s.primary, scaffold),
        'onSecondaryContainer / secondaryContainer (tonal buttons)': (
          s.onSecondaryContainer,
          s.secondaryContainer
        ),
        'onPrimaryContainer / primaryContainer (info notice)': (
          s.onPrimaryContainer,
          s.primaryContainer
        ),
        'onTertiaryContainer / tertiaryContainer (warning notice)': (
          s.onTertiaryContainer,
          s.tertiaryContainer
        ),
        'onErrorContainer / errorContainer (error notice)': (
          s.onErrorContainer,
          s.errorContainer
        ),
        'onError / error (danger button)': (s.onError, s.error),
        'error / surface (field errors)': (s.error, s.surface),
      };
      final min = hc ? 7.0 : 4.5;
      for (final MapEntry(key: label, value: (fg, bg)) in pairs.entries) {
        test('$label ≥ ${min.toStringAsFixed(1)}:1', () {
          final r = contrastRatio(fg, bg);
          expect(r, greaterThanOrEqualTo(min),
              reason: '$label is ${r.toStringAsFixed(2)}:1');
        });
      }

      test('risk colours on chips stay ≥ 4.5:1 after ensureContrast', () {
        final dark = b == Brightness.dark;
        final colours = dark
            ? [
                KcColors.riskLowOnDark,
                KcColors.riskMediumOnDark,
                KcColors.riskHighOnDark
              ]
            : [KcColors.riskLow, KcColors.riskMedium, KcColors.riskHigh];
        for (final c in colours) {
          final bg = Color.alphaBlend(c.withValues(alpha: 0.12), s.surface);
          expect(contrastRatio(ensureContrast(c, bg), bg),
              greaterThanOrEqualTo(4.5));
        }
      });
    });
  }

  test('raw risk colours meet 4.5:1 on their intended backgrounds', () {
    for (final c in [KcColors.riskLow, KcColors.riskHigh]) {
      expect(contrastRatio(c, Colors.white), greaterThanOrEqualTo(4.5));
    }
    const darkSurface = Color(0xFF121A22);
    for (final c in [
      KcColors.riskLowOnDark,
      KcColors.riskMediumOnDark,
      KcColors.riskHighOnDark
    ]) {
      expect(contrastRatio(c, darkSurface), greaterThanOrEqualTo(4.5));
    }
  });

  test('splash: white text on both ends of the blue→teal gradient', () {
    expect(
        contrastRatio(Colors.white, KcColors.blue), greaterThanOrEqualTo(4.5));
    expect(contrastRatio(Colors.white, KcColors.tealDeep),
        greaterThanOrEqualTo(4.5));
  });
}
