import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:kin_care_connect/core/config/business_info.dart';
import 'package:kin_care_connect/features/legal/legal_texts.dart';

void main() {
  test('docs/legal/*.md match the in-app texts (run tool/export_legal.dart)',
      () {
    for (final d in allLegalDocs) {
      final f = File('docs/legal/${d.fileName}');
      expect(f.existsSync(), isTrue, reason: '${f.path} missing');
      expect(f.readAsStringSync(), d.toMarkdown(),
          reason:
              '${f.path} is out of date: run `dart run tool/export_legal.dart`');
    }
  });

  test('every legal text is marked as a template needing lawyer review', () {
    for (final d in allLegalDocs) {
      expect(d.toMarkdown(), contains('Template — needs lawyer review'));
    }
  });

  test('privacy policy has the DPDP essentials', () {
    final md = privacyPolicy.toMarkdown();
    for (final heading in [
      'Grievance Officer',
      'Your rights',
      'Children',
      'Requesting deletion without the app',
      'How long we keep data',
      'Cookies and local storage',
    ]) {
      expect(md, contains('## $heading'));
    }
    expect(md, contains('section 9'));
    expect(md, contains(BusinessInfo.grievanceOfficerEmail));
    expect(md, contains('Data Protection Board of India'));
  });

  test('terms state the app is free with no in-app purchases or fees', () {
    final md = termsOfService.toMarkdown();
    expect(md, contains('no in-app purchases'));
    expect(md, contains('hidden fees'));
    expect(md, contains('AI features are paid for by us, the operator'));
  });

  test('business details come from business_info.dart (placeholders shown)',
      () {
    final all = allLegalDocs.map((d) => d.toMarkdown()).join();
    for (final v in [
      BusinessInfo.companyName,
      BusinessInfo.supportEmail,
      BusinessInfo.postalAddress,
      BusinessInfo.grievanceOfficerName,
    ]) {
      expect(all, contains(v));
    }
  });

  test('no overclaims in legal texts', () {
    final all = allLegalDocs.map((d) => d.toMarkdown()).join().toLowerCase();
    for (final banned in [
      '100%',
      'guaranteed',
      'completely secure',
      'fully secure',
      'detects falls',
      'prevents scams',
      'clinically',
      'certified',
    ]) {
      expect(all.contains(banned), isFalse, reason: 'found "$banned"');
    }
  });
}
