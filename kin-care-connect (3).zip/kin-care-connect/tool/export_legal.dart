// Regenerates docs/legal/*.md from lib/features/legal/legal_texts.dart so the
// public copies always match the in-app texts.
//
//   dart run tool/export_legal.dart
//
// Run it after editing the legal texts or lib/core/config/business_info.dart.
import 'dart:io';

import 'package:kin_care_connect/features/legal/legal_texts.dart';

void main() {
  for (final doc in allLegalDocs) {
    final name = doc.fileName;
    if (name == null) continue;
    File('docs/legal/$name').writeAsStringSync(doc.toMarkdown());
    stdout.writeln('wrote docs/legal/$name');
  }
}
