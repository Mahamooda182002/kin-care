package com.kincareconnect.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
